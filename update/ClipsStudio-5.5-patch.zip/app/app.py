import os
import re
import sys
import json
import time
import wave
import uuid
import hashlib
import shutil
import subprocess
import threading
import queue
from concurrent.futures import ThreadPoolExecutor
import textwrap
import tkinter as tk
from io import BytesIO
from pathlib import Path
from contextlib import suppress
from functools import lru_cache
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import customtkinter as ctk
from tkinter import filedialog, messagebox, colorchooser

NO_WINDOW_FLAG = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
LOCALAPPDATA = Path(os.environ.get("LOCALAPPDATA", "C:/"))
# Установленная программа: <папка>/ClipsStudio.exe, код в <папка>/app, FFmpeg и yt-dlp в <папка>/tools, модели в <папка>/models
INSTALL_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else None
LEGACY_ROOT = Path("C:/ClipsStudio_Build")  # данные старых сборок (до v3.6)
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(LOCALAPPDATA / "ms-playwright")
os.environ["PATH"] = os.pathsep.join(
    [str(d / "tools") for d in (INSTALL_DIR, LEGACY_ROOT) if d] + [os.environ.get("PATH", "")])

# Быстрая инициализация путей CUDA только в папке site-packages
for _root in sys.path:
    if "site-packages" in _root:
        _nv = Path(_root) / "nvidia"
        if _nv.exists():
            for _bin in _nv.rglob("bin"):
                os.environ["PATH"] = str(_bin) + os.pathsep + os.environ.get("PATH", "")
                if hasattr(os, "add_dll_directory"):
                    with suppress(Exception):
                        os.add_dll_directory(str(_bin))
        break

ctk.set_appearance_mode("Dark")

WHEEL_STEP = 44          # пикселей на один щелчок колёсика
WHEEL_GLIDE = 0.38       # доля оставшегося пути за кадр анимации — плавный, но короткий доезд


def _smooth_mouse_wheel(self, event):
    """Плавная прокрутка CTkScrollableFrame: шаг крупнее, движение доезжает за ~0.1 с, без мгновенных скачков."""
    if not self._check_if_valid_scroll(event.widget):
        return
    if sys.platform.startswith("win") or sys.platform == "darwin":
        notches = -event.delta / (120.0 if sys.platform.startswith("win") else 1.0)
    else:
        notches = -1.0 if getattr(event, "num", 5) == 4 else 1.0
    horizontal = getattr(self, "_shift_pressed", False)
    view = self._parent_canvas.xview() if horizontal else self._parent_canvas.yview()
    if view == (0.0, 1.0):
        return
    try:
        scale = float(self._get_widget_scaling())
    except Exception:
        scale = 1.0
    self._parent_canvas.configure(xscrollincrement=1, yscrollincrement=1)
    self._wheel_left = getattr(self, "_wheel_left", 0.0) + notches * WHEEL_STEP * scale
    if getattr(self, "_wheel_job", None) is None:
        self._wheel_step(horizontal)


def _smooth_wheel_step(self, horizontal):
    self._wheel_job = None
    left = getattr(self, "_wheel_left", 0.0)
    move = left * WHEEL_GLIDE
    move = (1 if left > 0 else -1) * max(1.0, abs(move)) if abs(left) >= 1 else 0
    if not move:
        self._wheel_left = 0.0
        return
    try:
        (self._parent_canvas.xview_scroll if horizontal else self._parent_canvas.yview_scroll)(int(round(move)), "units")
    except Exception:
        self._wheel_left = 0.0
        return
    self._wheel_left = left - int(round(move))
    self._wheel_job = self.after(12, lambda: self._wheel_step(horizontal))


with suppress(Exception):
    ctk.CTkScrollableFrame._mouse_wheel_all = _smooth_mouse_wheel
    ctk.CTkScrollableFrame._wheel_step = _smooth_wheel_step

APP_VERSION = "5.5"
MD3 = {
    "bg": "#141218", "surface": "#1D1B20", "surface_container": "#211F26", "surface_high": "#2B2930",
    "surface_highest": "#36343B", "primary": "#D0BCFF", "primary_hover": "#E8DEF8", "on_primary": "#381E72",
    "secondary_container": "#4A4458", "on_secondary": "#E8DEF8", "tertiary": "#EFB8C8", "on_surface": "#E6E0E9",
    "on_surface_var": "#CAC4D0", "outline": "#49454F", "error": "#F2B8B5", "error_container": "#8C1D18",
    "success_container": "#1E3A2F", "on_success": "#A6F4C5", "selected_card": "#3F3459", "selected_border": "#D0BCFF",
}

DATA_ROOT = LOCALAPPDATA / "ClipsStudio"  # настройки, галерея, аккаунты — не затрагиваются обновлениями и переустановкой
CONFIG_FILE = DATA_ROOT / "config_sk.json"
GALLERY_DB_FILE = DATA_ROOT / "clips_gallery_db.json"
HIDDEN_CLIPS_FILE = DATA_ROOT / "hidden_clips.json"
THUMBS_CACHE_DIR = DATA_ROOT / "thumbs_cache"
YT_PROFILES_ROOT = DATA_ROOT / "yt_profiles"
YT_ACCOUNTS_FILE = DATA_ROOT / "yt_accounts.json"
THUMB_SIZE = (120, 213)        # превью в галерее (9:16), логические пиксели
THUMB_RENDER = (240, 426)      # рисуется вдвое крупнее — чётко на экранах с масштабом 125–200%
TILE_W, TILE_H = 136, 278
LEGACY_DATA_FILES = ("config_sk.json", "clips_gallery_db.json", "hidden_clips.json", "yt_accounts.json",
                     "gdrive_auth.json", "google_client.json", "gdrive_avatar.png")


def migrate_legacy_data():
    """Однократный перенос настроек из C:\\ClipsStudio_Build (старые сборки) в папку данных пользователя."""
    if (DATA_ROOT / "config_sk.json").exists() or not (LEGACY_ROOT / "config_sk.json").exists():
        return
    DATA_ROOT.mkdir(parents=True, exist_ok=True)
    for name in LEGACY_DATA_FILES:
        with suppress(Exception):
            if (LEGACY_ROOT / name).exists():
                shutil.copy2(LEGACY_ROOT / name, DATA_ROOT / name)


def load_wav_for_whisper(wav_path: Path):
    """WAV 16 кГц моно → массив для Whisper напрямую (без PyAV: его новые версии ломают чтение файлов в faster-whisper)."""
    with suppress(Exception):
        with wave.open(str(wav_path), "rb") as wf:
            if wf.getframerate() == 16000 and wf.getnchannels() == 1 and wf.getsampwidth() == 2:
                return np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    return str(wav_path)


# ---------------------------- GigaAM-v3 (Сбер, MIT): распознавание русской речи ----------------------------
# e2e RNN-T: сразу с пунктуацией и заглавными буквами. Файлы — в <установка>/nn/gigaam (кодер INT8 из gigastt, MIT).
GIGAAM = "GigaAM"                    # пункт в списке моделей речи (рядом с размерами Whisper)
GIGAAM_FILES = ("v3_e2e_rnnt_encoder_int8.onnx", "v3_e2e_rnnt_decoder.onnx", "v3_e2e_rnnt_joint.onnx", "v3_e2e_rnnt_vocab.txt")
GIGAAM_FRAME = 0.04                  # шаг кодера: 4 кадра по 10 мс
GIGAAM_MAX_CHUNK = 20.0              # кусок речи для кодера (длиннее — режется по паузам)


def gigaam_available() -> bool:
    return all((NN_DIR / "gigaam" / f).exists() for f in GIGAAM_FILES)


class GigaAMRecognizer:
    """Распознаёт 16 кГц моно → слова [{word, start, end}]. Признаки — log-mel как в GigaAM (64 полосы, окно 20 мс)."""
    _inst = None
    _lock = threading.Lock()

    @classmethod
    def get(cls):
        with cls._lock:
            if cls._inst is None:
                cls._inst = cls()
            return cls._inst

    def __init__(self):
        import onnxruntime as ort
        d = NN_DIR / "gigaam"
        opts = ort.SessionOptions()
        opts.intra_op_num_threads = max(2, (os.cpu_count() or 4) - 1)
        opts.log_severity_level = 3
        mk = lambda f: ort.InferenceSession(str(d / f), opts, providers=["CPUExecutionProvider"])  # noqa: E731
        self.enc, self.dec, self.joint = mk(GIGAAM_FILES[0]), mk(GIGAAM_FILES[1]), mk(GIGAAM_FILES[2])
        self.vocab = [ln.rsplit(" ", 1)[0] for ln in (d / GIGAAM_FILES[3]).read_text(encoding="utf-8").splitlines() if ln.strip()]
        self.blank = len(self.vocab) - 1
        hz2mel = lambda f: 2595.0 * np.log10(1.0 + f / 700.0)  # noqa: E731
        f_pts = 700.0 * (10 ** (np.linspace(0.0, hz2mel(8000.0), 66) / 2595.0) - 1.0)
        slopes = f_pts[None, :] - np.linspace(0, 8000, 161)[:, None]
        fd = f_pts[1:] - f_pts[:-1]
        self.bank = np.maximum(0, np.minimum(-slopes[:, :-2] / fd[:-1], slopes[:, 2:] / fd[1:]))
        self.win = 0.5 - 0.5 * np.cos(2 * np.pi * np.arange(320) / 320)

    def _feats(self, x: np.ndarray) -> np.ndarray:
        x = np.asarray(x, np.float64)
        if len(x) < 320:
            x = np.pad(x, (0, 320 - len(x)))
        n = 1 + (len(x) - 320) // 160
        fr = x[np.arange(320)[None, :] + 160 * np.arange(n)[:, None]] * self.win
        return np.log(np.clip((np.abs(np.fft.rfft(fr, axis=1)) ** 2) @ self.bank, 1e-9, 1e9)).T.astype(np.float32)

    def _tokens(self, audio: np.ndarray) -> list:
        f = self._feats(audio)
        e, el = self.enc.run(None, {"audio_signal": f[None], "length": np.array([f.shape[1]], np.int64)})
        e = e[0][:, :int(el[0])]
        h = np.zeros((1, 1, 320), np.float32)
        c = np.zeros_like(h)
        d, h2, c2 = self.dec.run(None, {"x": np.array([[self.blank]], np.int64), "h.1": h, "c.1": c})
        toks = []
        for t in range(e.shape[1]):
            ef = np.ascontiguousarray(e[:, t].reshape(1, 768, 1))
            for _ in range(10):  # не больше 10 знаков на кадр (как в эталонном декодере)
                k = int(self.joint.run(None, {"enc": ef, "dec": d.reshape(1, 320, 1)})[0].reshape(-1).argmax())
                if k == self.blank:
                    break
                toks.append((k, t))
                h, c = h2, c2
                d, h2, c2 = self.dec.run(None, {"x": np.array([[k]], np.int64), "h.1": h, "c.1": c})
        return toks

    def words(self, audio: np.ndarray, offset: float = 0.0) -> list:
        """Слова куска речи с таймкодами (начало — по первому знаку слова, конец — до следующего слова)."""
        out, cur = [], None
        for k, t in self._tokens(audio):
            p, ts = self.vocab[k], offset + t * GIGAAM_FRAME
            if p.startswith("\u2581") or cur is None:
                if cur and cur["word"]:
                    out.append(cur)
                cur = {"word": p.lstrip("\u2581"), "start": ts, "last": ts}
            else:
                cur["word"] += p
                cur["last"] = ts
        if cur and cur["word"]:
            out.append(cur)
        tail = offset + len(audio) / 16000.0
        for i, w in enumerate(out):
            nxt = out[i + 1]["start"] if i + 1 < len(out) else tail
            w["end"] = round(max(w["start"] + 0.12, min(nxt - 0.02, w.pop("last") + 0.32)), 3)
            w["start"] = round(w["start"], 3)
        return [w for w in out if w["word"].strip()]


def speech_chunks(audio: np.ndarray, max_sec: float = GIGAAM_MAX_CHUNK) -> list:
    """Куски речи [(начало, конец) в отсчётах] — детектор речи Silero из faster-whisper."""
    try:
        from faster_whisper.vad import VadOptions, get_speech_timestamps
        ts = get_speech_timestamps(audio, VadOptions(min_silence_duration_ms=400, speech_pad_ms=200,
                                                     max_speech_duration_s=max_sec))
        spans = [(int(t["start"]), int(t["end"])) for t in ts]
    except Exception:  # без детектора — ровными кусками
        step = int(max_sec * 16000)
        spans = [(i, min(len(audio), i + step)) for i in range(0, len(audio), step)]
    merged = []  # соседние фразы с короткой паузой — одним куском: модель видит контекст (точнее пунктуация и окончания)
    for a, b in spans:
        if merged and a - merged[-1][1] <= 1.2 * 16000 and b - merged[-1][0] <= max_sec * 16000:
            merged[-1] = (merged[-1][0], b)
        else:
            merged.append((a, b))
    return [(a, b) for a, b in merged if b - a >= 1600]


_CUDA_STATE = {"ok": None, "why": ""}   # проверяется один раз за запуск программы
_WHISPER_CACHE = {}                       # (модель, устройство) → загруженная модель: повторная нарезка стартует сразу


def cuda_usable() -> bool:
    """Можно ли пробовать видеокарту. Проверка не трогает ctranslate2: после неудачной попытки CUDA
    библиотека в том же процессе может зависнуть при следующей, поэтому неудача запоминается до перезапуска."""
    if _CUDA_STATE["ok"] is not None:
        return _CUDA_STATE["ok"]
    ok, why = True, ""
    try:
        import ctranslate2
        if ctranslate2.get_cuda_device_count() <= 0:
            ok, why = False, "видеокарта NVIDIA не найдена"
    except Exception as e:
        ok, why = False, str(e)
    if ok and sys.platform == "win32":
        import ctypes
        for dll in ("cublas64_12.dll", "cudnn64_9.dll"):
            try:
                ctypes.WinDLL(dll)
            except OSError:
                ok, why = False, f"нет библиотеки {dll}"
                break
    _CUDA_STATE.update(ok=ok, why=why)
    return ok


def whisper_model(size: str) -> str:
    """Модель Whisper из папки установки (работает без скачивания); иначе — имя для загрузки из интернета."""
    for base in (INSTALL_DIR, LEGACY_ROOT / "vendor"):
        if base and (base / "models" / f"faster-whisper-{size}" / "model.bin").exists():
            return str(base / "models" / f"faster-whisper-{size}")
    return size
STARTUP_BALANCE_DELAY_MS = 4000

TOKIFY_MODELS = [
    "claude-opus-5.5", "claude-opus-5", "claude-opus-5-thinking", "claude-fable-5.1", "claude-fable-5",
    "claude-opus-4.8", "claude-opus-4.7", "gpt-6-astra", "gpt-6-reasoning-pro", "gpt-6-sol", "gpt-5.6-sol",
    "gpt-5.6-luna",
]
DEFAULT_SPEAKER_HEX = ["#ebb521", "#eb7c21", "#e8e523", "#66d124", "#38a8e0", "#8938e0"]
FEMALE_SPEAKER_HEX = ["#f252c0", "#f5e23b", "#ed6461", "#ade85f"]
FONT_MAP = {
    "Arial": ["arialbd.ttf", "arial.ttf"], "Segoe UI": ["segoeuib.ttf", "segoeui.ttf"],
    "Impact": ["impact.ttf", "arialbd.ttf"], "Verdana": ["verdanab.ttf", "verdana.ttf"],
    "Tahoma": ["tahomabd.ttf", "tahoma.ttf"], "Trebuchet MS": ["trebucbd.ttf", "trebuc.ttf"],
    "Comic Sans MS": ["comicbd.ttf", "comic.ttf"], "Courier New": ["courbd.ttf", "cour.ttf"],
}
DEFAULT_CONFIG = {
    "api_key": "", "base_url": "https://tokify.sale/v1", "model": "claude-opus-5.5", "whisper_size": "GigaAM", "sub_fix": False, "yt_bypass": True, "proxy": "", "asr_gigaam_default": True,
    "max_clips": "5", "boost_audio": True, "face_track": True, "smart_track": False, "parallel_render": False, "banner": "", "banner_pos": "middle", "banner_sound": {}, "banner_over_subs": False, "banner_xy": {}, "nn_voice": True, "nn_face": True, "mode": "clips", "cs2_crop": True, "cs2_boost": True, "cs2_cam": False, "cs2_subtitles": False, "cs2_sub_advanced": False, "subtitles": False, "sub_advanced": False,
    "sub_font": "Arial", "sub_size": 70, "sub_bg": False, "sub_word_by_word": False, "sub_mirror": False,
    "sub_female_colors": False, "min_clip_sec": 5, "max_clip_sec": 60, "last_tokens_balance": "—",
    "storage_mode": "local", "local_dir": "", "gdrive_folder": "Клипы",
}
NOT_FOUND_MSG = ("Файл не найден", "Этот клип был удален из папки на диске.")


class Cancelled(Exception):
    def __init__(self, msg="Остановлено пользователем."):
        super().__init__(msg)


# ---------------------------- ОБЩИЕ ХЕЛПЕРЫ ----------------------------
def run_bg(fn, *args):
    threading.Thread(target=fn, args=args, daemon=True).start()


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, data):
    with suppress(Exception):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def clean_api_key(raw: str) -> str:
    key = str(raw or "").strip()
    if key.lower().startswith("bearer "):
        key = key[7:].strip()
    return re.sub(r"\d{1,2}:\d{2}$", "", key).strip("\"' ")


def strip_num_prefix(name) -> str:
    name = str(name).strip()
    return re.sub(r"^\d+[\s_\-]+", "", name) or name


def safe_filename(name: str) -> str:
    return re.sub(r'[\\/*?:"<>|]', "", name).strip()


def with_shorts(title: str) -> str:
    return title if "#shorts" in title.lower() else f"{title} #Shorts"


# ---------------------------- SEO ----------------------------
SEO_TITLE_MAX, SEO_TAGS_MAX, SEO_HASHTAGS_MAX = 100, 450, 5
_GENERIC_TAGS = {"#рек", "#рекомендации", "#fyp", "#foryou", "#viral", "#вирусное", "#тренды", "#trending", "#хочуврек"}


def seo_hashtags(raw, keep_generic=False) -> list:
    """3–5 хэштегов: тематические первыми (YouTube показывает первые три над названием), #shorts последним,
    без дублей, пробелов и пустых «#рек»-спамов (их слишком много у всех — они не помогают поиску)."""
    out, seen = [], set()
    for tok in re.findall(r"#?[^\s#,;]+", str(raw or "")):
        word = re.sub(r"[^\w]", "", tok, flags=re.UNICODE)
        if not word or word.isdigit():
            continue
        tag = "#" + word
        low = tag.lower()
        if low in seen or low == "#shorts" or (low in _GENERIC_TAGS and not keep_generic):
            continue
        seen.add(low)
        out.append(tag)
    return out[:SEO_HASHTAGS_MAX - 1] + ["#shorts"]


def seo_tags(raw) -> list:
    """Теги YouTube: поисковые фразы через запятую, без «#», без дублей, суммарно до ~450 символов (лимит 500)."""
    items = raw if isinstance(raw, (list, tuple)) else re.split(r"[,;\n]", str(raw or ""))
    out, seen, total = [], set(), 0
    for t in items:
        t = re.sub(r"\s+", " ", str(t).replace("#", " ")).strip(" .\"'«»")[:60]
        if not t or t.lower() in seen:
            continue
        cost = len(t) + 2 + (2 if " " in t else 0)  # YouTube считает кавычки у фраз с пробелами
        if total + cost > SEO_TAGS_MAX:
            break
        seen.add(t.lower())
        out.append(t)
        total += cost
    return out


def seo_title(raw) -> str:
    t = re.sub(r"\s+", " ", strip_num_prefix(str(raw or "")).replace("<", "").replace(">", "")).strip()
    t = re.sub(r"\s*#\w+", "", t).strip() or t  # хэштеги — в описании, название остаётся чистым
    if len(t) > SEO_TITLE_MAX:
        t = t[:SEO_TITLE_MAX].rsplit(" ", 1)[0].rstrip(" ,.:;-—")
    return t


def seo_description(desc, hashtags: list) -> str:
    desc = re.sub(r"(?<!\S)#\w+", "", str(desc or "")).strip()
    desc = re.sub(r"[ \t]+", " ", desc).replace("<", "").replace(">", "")
    tags = " ".join(hashtags)
    return f"{desc}\n\n{tags}".strip()[:4900] if desc else tags


def hex_to_rgb(hex_str):
    h = str(hex_str).lstrip("#")
    with suppress(Exception):
        if len(h) == 6:
            return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    return (235, 181, 33)


def speaker_hex(idx: int) -> str:
    return DEFAULT_SPEAKER_HEX[idx % len(DEFAULT_SPEAKER_HEX)]


def format_token_number(val) -> str:
    try:
        num = float(val)
        if num >= 1e9:
            return f"{num / 1e9:.2f} млрд"
        if num >= 1e6:
            return f"{num / 1e6:.2f} млн"
        return f"{int(num):,}".replace(",", " ")
    except Exception:
        return str(val)


@lru_cache(maxsize=1)
def find_system_browser_exe() -> str:
    pf = Path(os.environ.get("ProgramFiles", "C:/Program Files"))
    pf86 = Path(os.environ.get("ProgramFiles(x86)", "C:/Program Files (x86)"))
    chrome = "Google/Chrome/Application/chrome.exe"
    edge = "Microsoft/Edge/Application/msedge.exe"
    for c in (pf / chrome, pf86 / chrome, LOCALAPPDATA / chrome, pf86 / edge, pf / edge):
        if c.exists():
            return str(c)
    pw_dir = LOCALAPPDATA / "ms-playwright"
    if pw_dir.exists():
        for exe in pw_dir.rglob("chrome.exe"):
            return str(exe)
    return ""


def launch_browser_context(pw, user_data_dir: str, headless: bool, width: int, height: int):
    kwargs = {
        "user_data_dir": user_data_dir, "headless": headless, "viewport": {"width": width, "height": height},
        "args": [f"--window-size={width + 20},{height + 40}", "--disable-blink-features=AutomationControlled",
                 "--no-first-run", "--no-default-browser-check"],
        "ignore_default_args": ["--enable-automation"],
    }
    exe_path = find_system_browser_exe()
    if exe_path:
        return pw.chromium.launch_persistent_context(executable_path=exe_path, **kwargs)
    for ch in ("msedge", "chrome"):
        with suppress(Exception):
            return pw.chromium.launch_persistent_context(channel=ch, **kwargs)
    return pw.chromium.launch_persistent_context(**kwargs)


ASSETS_DIR = Path(__file__).resolve().parent / "assets"   # app/assets — обновляется вместе с кодом
PLATFORM_STYLE = {"youtube": ("Y", (229, 57, 53)), "tiktok": ("T", (24, 24, 28))}


@lru_cache(maxsize=16)
def platform_badge(platform: str, size: int) -> Image.Image:
    """Значок платформы: официальная иконка из app/assets/<platform>.png, если она есть; иначе кружок с буквой."""
    icon = ASSETS_DIR / f"{platform}.png"
    if icon.exists():
        with suppress(Exception):
            return circle_avatar(str(icon), size)
    letter, color = PLATFORM_STYLE.get(platform, ("?", (74, 68, 88)))
    s = size * 4
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.ellipse((0, 0, s - 1, s - 1), fill=(*color, 255), outline=(255, 255, 255, 255), width=max(2, s // 14))
    font = load_pil_font("Segoe UI", int(s * 0.62))
    bb = d.textbbox((0, 0), letter, font=font)
    d.text(((s - bb[2] - bb[0]) / 2, (s - bb[3] - bb[1]) / 2), letter, font=font, fill=(255, 255, 255, 255))
    return im.resize((size, size), Image.Resampling.LANCZOS)


def make_avatar_with_platform_badge(avatar_path: str, platform: str, size: int = 28) -> Image.Image:
    base = circle_avatar(avatar_path, size)
    b = max(12, int(size * 0.48))
    badge = platform_badge(platform, b)
    if badge is not None:
        base.alpha_composite(badge, (size - b, size - b))
    return base


def get_cached_thumbnail(video_path: Path, size=THUMB_RENDER, force_refresh: bool = False) -> Image.Image:
    """Превью 1-й секунды клипа с дисковым кэшем (thumbs_cache) — видео не открывается повторно при старте."""
    try:
        THUMBS_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        st = video_path.stat()
        key = hashlib.md5(f"{video_path.resolve()}_{st.st_size}_{int(st.st_mtime)}_{size}".encode("utf-8")).hexdigest()
        cache_file = THUMBS_CACHE_DIR / f"{key}.jpg"
        if not force_refresh and cache_file.exists():
            return Image.open(cache_file).convert("RGB")

        cap = cv2.VideoCapture(str(video_path))
        if cap.isOpened():
            frames = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 30
            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            cap.set(cv2.CAP_PROP_POS_MSEC, 1000.0 if frames / max(1.0, fps) >= 1.1 else 200.0)
            ret, frame = cap.read()
            if not ret or frame is None:
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                ret, frame = cap.read()
            cap.release()
            if ret and frame is not None:
                im = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                im.thumbnail(size, Image.Resampling.LANCZOS)
                canvas = Image.new("RGB", size, (20, 18, 24))
                canvas.paste(im, ((size[0] - im.width) // 2, (size[1] - im.height) // 2))
                with suppress(Exception):
                    canvas.save(cache_file, "JPEG", quality=85)
                return canvas
    except Exception:
        pass
    return Image.new("RGB", size, (33, 31, 38))


PUBLISH_PLATFORMS = ("youtube", "tiktok")
PUB_BADGE, PUB_GAP, PUB_MARGIN = 22, 4, 7   # значки «выложено» слева вверху превью (в px плитки)


def publish_badge_rects(platforms: list) -> list:
    """[(платформа, (x0, y0, x1, y1))] — где на превью (в координатах THUMB_SIZE) стоят значки «выложено»."""
    return [(p, (PUB_MARGIN + i * (PUB_BADGE + PUB_GAP), PUB_MARGIN,
                 PUB_MARGIN + i * (PUB_BADGE + PUB_GAP) + PUB_BADGE, PUB_MARGIN + PUB_BADGE))
            for i, p in enumerate(platforms)]


def decorate_thumb(img: Image.Image, seconds: float, mirror=False, cloud=False, published=()) -> Image.Image:
    """Плашки поверх превью: длительность (справа внизу), ⇄ отзеркалено и ☁ Google Drive (слева внизу),
    значки платформ, куда клип выложен (слева вверху)."""
    im = img.convert("RGBA")
    d = ImageDraw.Draw(im)
    s = im.width / THUMB_SIZE[0]
    font = load_pil_font("Segoe UI", max(10, int(11 * s)))

    sym = load_pil_font("Segoe UI Symbol", max(10, int(12 * s)))

    def chip(text, right):
        f = font if right else sym
        bb = d.textbbox((0, 0), text, font=f)
        w, h = bb[2] - bb[0] + int(12 * s), bb[3] - bb[1] + int(8 * s)
        y = im.height - h - int(6 * s)
        x = im.width - w - int(6 * s) if right else chip.left
        d.rounded_rectangle((x, y, x + w, y + h), radius=int(h / 2), fill=(10, 10, 14, 200))
        d.text((x + int(6 * s) - bb[0], y + int(4 * s) - bb[1]), text, font=f, fill=(255, 255, 255, 255))
        if not right:
            chip.left = x + w + int(4 * s)
    chip.left = int(6 * s)
    m, sec = divmod(int(round(seconds)), 60)
    chip(f"{m}:{sec:02d}", True)
    if mirror:
        chip("⇄", False)
    if cloud:
        chip("☁", False)
    for plat, (x0, y0, x1, _) in publish_badge_rects(list(published)):
        size = max(8, int(round((x1 - x0) * s)))
        b = platform_badge(plat, size)
        if b is not None:
            ring = Image.new("RGBA", (size + 4, size + 4), (0, 0, 0, 0))   # тёмная обводка — виден на любом кадре
            ImageDraw.Draw(ring).ellipse((0, 0, size + 3, size + 3), fill=(10, 10, 14, 170))
            im.alpha_composite(ring, (int(x0 * s) - 2, int(y0 * s) - 2))
            im.alpha_composite(b.convert("RGBA"), (int(x0 * s), int(y0 * s)))
    mask = Image.new("L", im.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, im.width - 1, im.height - 1), radius=int(12 * s), fill=255)
    im.putalpha(mask)
    return im


@lru_cache(maxsize=1)
def physical_cores() -> int:
    """Число физических ядер (os.cpu_count считает потоки: 4 ядра / 8 потоков — это 4)."""
    with suppress(Exception):
        if sys.platform == "win32":
            import ctypes
            from ctypes import wintypes

            class _Info(ctypes.Structure):
                _fields_ = [("mask", ctypes.c_size_t), ("rel", ctypes.c_int), ("_u", ctypes.c_ulonglong * 2)]
            k32, size = ctypes.windll.kernel32, wintypes.DWORD(0)
            k32.GetLogicalProcessorInformation(None, ctypes.byref(size))
            buf = (_Info * (size.value // ctypes.sizeof(_Info)))()
            if k32.GetLogicalProcessorInformation(buf, ctypes.byref(size)):
                n = sum(1 for x in buf if x.rel == 0)  # RelationProcessorCore
                if n:
                    return n
        else:
            cores = set()
            phys = core = None
            for line in Path("/proc/cpuinfo").read_text().splitlines() + [""]:
                k, _, v = line.partition(":")
                k = k.strip()
                if k == "physical id":
                    phys = v.strip()
                elif k == "core id":
                    core = v.strip()
                elif not k and core is not None:
                    cores.add((phys, core))
                    phys = core = None
            if cores:
                return len(cores)
    return os.cpu_count() or 1


PARALLEL_MIN_CORES = 6


def parallel_render_available() -> bool:
    return physical_cores() >= PARALLEL_MIN_CORES


def get_video_duration_sec(fpath: Path) -> float:
    with suppress(Exception):
        cap = cv2.VideoCapture(str(fpath))
        if cap.isOpened():
            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            cnt = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
            cap.release()
            if cnt > 0 and fps > 0:
                return float(cnt / fps)
    return 30.0


# ---------------------------- КТО ГОВОРИТ (ДИАРИЗАЦИЯ) И ПОЛ ПО ГОЛОСУ ----------------------------
# Персонаж определяется для целой ФРАЗЫ (а не для каждого куска субтитра из 6 слов), поэтому внутри
# одной реплики цвет больше не «прыгает». Голоса группируются статистически (MFCC + критерий BIC):
# две фразы сливаются в одного персонажа, если одна общая модель голоса описывает их лучше, чем две.
# Пол — по «базовой» высоте голоса (устойчивый трекер без октавных ошибок).
VOICE_MIN_FRAMES = 60        # ≥0.6 с речи — фраза годится для построения модели голоса
PITCH_VETO_OCT = 0.55        # голоса, отличающиеся по высоте больше чем на ~46%, не сливаются
MIN_SPEAKER_SPEECH = 1.2     # «персонаж» с речью короче 1.2 с считается ошибкой и сливается с ближайшим
FEMALE_F0_HZ = 165.0         # порог «базовой» высоты голоса (35-й перцентиль): выше — женский голос
BIC_LAMBDA = 2.0             # штраф за «нового персонажа»: больше — осторожнее с разделением голосов


def read_wav_mono(wav_path: Path, start_t: float, end_t: float):
    with wave.open(str(wav_path), "rb") as wf:
        sr, n, ch = wf.getframerate(), wf.getnframes(), wf.getnchannels()
        s = max(0, min(n, int(start_t * sr)))
        wf.setpos(s)
        raw = wf.readframes(max(0, min(n, int(end_t * sr)) - s))
    audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    return (audio.reshape(-1, ch).mean(axis=1) if ch > 1 else audio), sr


@lru_cache(maxsize=4)
def _mel_dct(sr: int, n_fft: int, n_mels: int = 26, n_ceps: int = 13):
    mel = lambda f: 2595.0 * np.log10(1.0 + f / 700.0)
    pts = 700.0 * (10 ** (np.linspace(mel(80.0), mel(min(7600.0, sr / 2 - 1)), n_mels + 2) / 2595.0) - 1.0)
    freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)
    fb = np.zeros((n_mels, len(freqs)), dtype=np.float32)
    for m in range(n_mels):
        lo, c, hi = pts[m], pts[m + 1], pts[m + 2]
        fb[m] = np.clip(np.minimum((freqs - lo) / (c - lo), (hi - freqs) / (hi - c)), 0, None)
    dct = np.cos(np.pi / n_mels * (np.arange(n_mels) + 0.5)[None, :] * np.arange(n_ceps)[:, None]).astype(np.float32)
    return fb, dct


def _frames(x: np.ndarray, win: int, hop: int) -> np.ndarray:
    return np.lib.stride_tricks.sliding_window_view(x, win)[::hop] if len(x) >= win else np.zeros((0, win), np.float32)


def estimate_background(audio: np.ndarray, sr: int):
    """Спектр фона (музыка игры, шум, гул) по паузам между репликами — потом вычитается из речи."""
    if len(audio) < int(0.3 * sr):
        return None
    x = (audio - np.mean(audio)).astype(np.float32)
    hop = int(0.010 * sr)
    pre = np.append(x[0], x[1:] - 0.97 * x[:-1])
    out = {}
    for key, sig, win, nf in (("mel", pre, int(0.025 * sr), 512), ("pitch", x, int(0.040 * sr), None)):
        fr = _frames(sig, win, hop)
        if key == "mel":
            fr = fr * np.hamming(win).astype(np.float32)
        else:
            fr = fr - fr.mean(axis=1, keepdims=True)
            nf = 1 << int(np.ceil(np.log2(2 * win)))
        out[key] = np.mean(np.abs(np.fft.rfft(fr, nf)) ** 2, axis=0)
    return out


def _denoise(power: np.ndarray, noise) -> np.ndarray:
    return power if noise is None else np.maximum(power - 1.5 * noise, 0.05 * power)


def _drop_flat_pitch(f0: np.ndarray, frame_idx: np.ndarray) -> np.ndarray:
    """Убирает «слишком ровные» участки тона (ноты музыки/синтезатора): живой голос всё время плавает."""
    if len(f0) < 12:
        return f0
    keep = np.ones(len(f0), dtype=bool)
    run = 0
    for i in range(1, len(f0) + 1):
        steady = i < len(f0) and frame_idx[i] == frame_idx[i - 1] + 1 and abs(np.log2(f0[i] / f0[i - 1])) < 0.004
        if steady:
            run += 1
            continue
        if run >= 9:  # ≥ 0.1 с почти идеально постоянного тона
            keep[i - run - 1:i] = False
        run = 0
    return f0[keep]


def analyze_voice(audio: np.ndarray, sr: int, background=None) -> dict:
    """MFCC речевых кадров и высота голоса (Гц) по кадрам; фон (если известен) вычитается из спектра."""
    res = {"mfcc": np.zeros((0, 12), np.float32), "f0": np.zeros(0, np.float32), "speech_sec": 0.0}
    if len(audio) < int(0.3 * sr):
        return res
    x = (audio - np.mean(audio)).astype(np.float32)
    hop, win, n_fft = int(0.010 * sr), int(0.025 * sr), 512
    pre = np.append(x[0], x[1:] - 0.97 * x[:-1])
    fr = _frames(pre, win, hop) * np.hamming(win).astype(np.float32)
    e_db = 10 * np.log10(np.mean(fr ** 2, axis=1) + 1e-10)
    speech = e_db > max(float(np.max(e_db)) - 30.0, -60.0)
    fb, dct = _mel_dct(sr, n_fft)
    spec = _denoise(np.abs(np.fft.rfft(fr[speech], n_fft)) ** 2, background and background.get("mel"))
    res["mfcc"] = (np.log(spec @ fb.T + 1e-10) @ dct.T)[:, 1:13].astype(np.float32)
    res["speech_sec"] = float(speech.sum()) * hop / sr

    # Высота голоса: нормированная автокорреляция; из близких к максимуму пиков берётся ПЕРВЫЙ
    # (самый высокий тон) — это убирает типичную ошибку «женский голос услышан на октаву ниже».
    pw = int(0.040 * sr)
    p = _frames(x, pw, hop)
    p = p - p.mean(axis=1, keepdims=True)
    p_db = 10 * np.log10(np.mean(p ** 2, axis=1) + 1e-10)
    loud_idx = np.nonzero(p_db > max(float(np.max(p_db)) - 25.0, -55.0))[0] if len(p) else np.zeros(0, int)
    p = p[loud_idx]
    if len(p):
        nf = 1 << int(np.ceil(np.log2(2 * pw)))
        power = _denoise(np.abs(np.fft.rfft(p, nf)) ** 2, background and background.get("pitch"))
        r = np.fft.irfft(power, nf)[:, :pw]
        cs = np.cumsum(p ** 2, axis=1)
        lags = np.arange(int(sr / 420.0), int(sr / 65.0) + 1)
        ncc = r[:, lags] / np.sqrt(cs[:, pw - 1 - lags] * (cs[:, -1:] - cs[:, lags - 1]) + 1e-12)
        best = ncc.max(axis=1)
        peak = np.zeros_like(ncc, dtype=bool)
        peak[:, 1:-1] = (ncc[:, 1:-1] >= ncc[:, :-2]) & (ncc[:, 1:-1] >= ncc[:, 2:])
        cand = peak & (ncc >= 0.86 * best[:, None])
        ok = cand.any(axis=1) & (best > 0.55 if background else best > 0.62)
        f0 = _drop_flat_pitch(sr / lags[np.argmax(cand, axis=1)][ok].astype(np.float32), loud_idx[ok])
        if len(f0) >= 5:  # отбрасываем одиночные выбросы (полуоктавные скачки)
            f0 = f0[np.abs(np.log2(f0 / np.median(f0))) < 0.6]
        res["f0"] = f0
    return res


def voice_gender(f0_all: np.ndarray):
    """True — женский, False — мужской, None — мало данных. Берётся 35-й перцентиль высоты голоса:
    в эмоциональной речи (крик, смех) верхние значения у мужчин сильно растут, а «база» почти нет."""
    if len(f0_all) < 25:
        return None
    return bool(np.percentile(f0_all, 35) >= FEMALE_F0_HZ)


class _VoiceCluster:
    def __init__(self, mfcc, f0, speech_sec, phrases):
        self.n, self.s, self.ss = len(mfcc), mfcc.sum(0, dtype=np.float64), mfcc.T.astype(np.float64) @ mfcc
        self.f0, self.speech_sec, self.phrases = f0, speech_sec, phrases

    def merged(self, o):
        c = _VoiceCluster.__new__(_VoiceCluster)
        c.n, c.s, c.ss = self.n + o.n, self.s + o.s, self.ss + o.ss
        c.f0, c.speech_sec, c.phrases = np.concatenate([self.f0, o.f0]), self.speech_sec + o.speech_sec, self.phrases + o.phrases
        return c

    def gauss(self):
        mu = self.s / self.n
        cov = self.ss / self.n - np.outer(mu, mu)
        cov += np.eye(len(mu)) * (1e-3 + 0.01 * np.trace(cov) / len(mu))
        return mu, cov

    def logdet(self):
        return np.linalg.slogdet(self.gauss()[1])[1]

    def pitch(self):
        return float(np.median(self.f0)) if len(self.f0) >= 20 else None


def _merge_cost(a: _VoiceCluster, b: _VoiceCluster) -> float:
    d = len(a.s)
    m = a.merged(b)
    cost = 0.5 * (m.n * m.logdet() - a.n * a.logdet() - b.n * b.logdet()) - BIC_LAMBDA * 0.5 * (d + d * (d + 1) / 2) * np.log(m.n)
    pa, pb = a.pitch(), b.pitch()
    if pa and pb and abs(np.log2(pa / pb)) > PITCH_VETO_OCT:
        cost += 1e6
    return cost


def _avg_loglik(mfcc: np.ndarray, cl: _VoiceCluster) -> float:
    mu, cov = cl.gauss()
    diff = mfcc - mu
    return float(-0.5 * (np.mean(np.sum(diff @ np.linalg.inv(cov) * diff, axis=1)) + np.linalg.slogdet(cov)[1]))


def cluster_voices(feats: list, max_speakers: int) -> list:
    """feats — признаки фраз по времени. Возвращает номер персонажа для каждой фразы (0 — кто заговорил первым)."""
    n = len(feats)
    if n == 0:
        return []
    strong = [i for i, f in enumerate(feats) if len(f["mfcc"]) >= VOICE_MIN_FRAMES]
    if max_speakers <= 1 or not strong:
        return [0] * n
    cls = [_VoiceCluster(feats[i]["mfcc"], feats[i]["f0"], feats[i]["speech_sec"], [i]) for i in strong]

    def _merge_best(force=False, only=None):
        best = None
        for i in range(len(cls)):
            for j in range(i + 1, len(cls)):
                if only is not None and only not in (i, j):
                    continue
                c = _merge_cost(cls[i], cls[j])
                if best is None or c < best[0]:
                    best = (c, i, j)
        if best is None or (not force and best[0] >= 0):
            return False
        _, i, j = best
        cls[i] = cls[i].merged(cls[j])
        del cls[j]
        return True

    while len(cls) > 1 and _merge_best(force=len(cls) > max_speakers):
        pass
    while len(cls) > 1:  # слишком «короткие» персонажи — почти всегда ошибка
        tiny = min(range(len(cls)), key=lambda k: cls[k].speech_sec)
        if cls[tiny].speech_sec >= MIN_SPEAKER_SPEECH:
            break
        _merge_best(force=True, only=tiny)

    labels = [-1] * n
    for k, c in enumerate(cls):
        for i in c.phrases:
            labels[i] = k
    for i, f in enumerate(feats):  # короткие фразы — к самому похожему голосу
        if labels[i] == -1 and len(f["mfcc"]) >= 10:
            scores = []
            for c in cls:
                s = _avg_loglik(f["mfcc"], c)
                pc, pf = c.pitch(), (float(np.median(f["f0"])) if len(f["f0"]) >= 8 else None)
                if pc and pf and abs(np.log2(pc / pf)) > PITCH_VETO_OCT:
                    s -= 50.0
                scores.append(s)
            labels[i] = int(np.argmax(scores))
    for i in range(n):  # совсем без речи — как соседняя фраза
        if labels[i] == -1:
            labels[i] = next((labels[j] for j in list(range(i - 1, -1, -1)) + list(range(i + 1, n)) if labels[j] != -1), 0)
    for i in range(1, n - 1):  # короткая вставка между репликами одного голоса — тот же голос
        if feats[i]["speech_sec"] < 0.8 and labels[i - 1] == labels[i + 1] != labels[i]:
            labels[i] = labels[i - 1]
    order = {}
    return [order.setdefault(l, len(order)) for l in labels]


def diarize_segments(sub_segments: list, wav_path: Path, max_speakers: int, detect_gender: bool,
                     face_evidence: list = None) -> tuple:
    """Назначает speaker_id всем кускам субтитров (одинаковый внутри фразы). Возвращает (subs, кол-во, {id: женский?}).
    Голоса различает нейросеть (отпечатки голоса), без неё — MFCC + BIC. face_evidence — [(сек, p_жен[, вес])] по лицам и фигурам."""
    subs = [dict(s) for s in (sub_segments or [])]
    if not subs:
        return subs, 1, {0: False}
    groups = {}
    for i, s in enumerate(subs):
        groups.setdefault(s.get("phrase", f"_{i}"), []).append(i)
    phrases = sorted(groups.values(), key=lambda idx: subs[idx[0]]["start"])
    have_wav = bool(wav_path) and Path(wav_path).exists()
    background = None
    if have_wav:  # фон — из пауз между фразами (и до/после них) в пределах клипа
        with suppress(Exception):
            spans = sorted((min(subs[i]["start"] for i in idx), max(subs[i]["end"] for i in idx)) for idx in phrases)
            t0, gaps = spans[0][0] - 1.5, []
            for s, e in spans + [(spans[-1][1] + 1.5, None)]:
                if s - t0 > 0.15:
                    gaps.append(read_wav_mono(Path(wav_path), max(0.0, t0 + 0.05), s - 0.05))
                t0 = max(t0, e) if e is not None else t0
            if gaps and sum(len(g[0]) for g in gaps) >= 0.4 * gaps[0][1]:
                background = estimate_background(np.concatenate([g[0] for g in gaps]), gaps[0][1])
    feats, embs = [], []
    for idx in phrases:
        f = {"mfcc": np.zeros((0, 12), np.float32), "f0": np.zeros(0, np.float32), "speech_sec": 0.0, "vg": None}
        e = None
        if have_wav:
            with suppress(Exception):
                audio, sr = read_wav_mono(Path(wav_path), min(subs[i]["start"] for i in idx) - 0.05,
                                          max(subs[i]["end"] for i in idx) + 0.05)
                f = analyze_voice(audio, sr, background)
                e = speaker_embedding(audio, sr)
                if detect_gender:
                    f["vg"] = voice_gender_logit(audio, sr)
        feats.append(f)
        embs.append(e)

    cap = max(1, min(6, int(max_speakers)))
    # отпечатки голоса надёжны и при монтаже «восьмёркой» (в кадре по одному лицу) — потолок не ниже 4 персонажей
    bases = [float(np.percentile(f["f0"], 35)) if len(f["f0"]) >= 15 else 0.0 for f in feats]
    labels = (cluster_embeddings(embs, max(cap, 4), bases)
              if sum(e is not None for e in embs) >= max(1, len(embs) // 3) else None)
    if labels is None:
        labels = cluster_voices(feats, cap)
    for idx, lab in zip(phrases, labels):
        for i in idx:
            subs[i]["speaker_id"] = lab
    count = max(labels) + 1 if labels else 1
    genders = {}
    for sp in range(count):
        g = None
        if detect_gender:
            mine = [f for f, l in zip(feats, labels) if l == sp]
            f0 = np.concatenate([f["f0"] for f in mine]) if mine else np.zeros(0)
            spans = [(min(subs[i]["start"] for i in idx), max(subs[i]["end"] for i in idx))
                     for idx, l in zip(phrases, labels) if l == sp]
            ps = [(e[1], e[2] if len(e) > 2 else 1.0) for e in (face_evidence or []) if any(a <= e[0] <= b for a, b in spans)]
            vl = [(f["vg"], f["speech_sec"] or 0.5) for f in mine if f.get("vg") is not None]
            g = fused_gender(f0, ps, vl) if (ps or vl) else voice_gender(f0)
        genders[sp] = bool(g)
    return subs, count, genders


# ---------------------------- НЕЙРОСЕТИ: ГОЛОС И ПОЛ ПО ЛИЦУ ----------------------------
# Модели лежат в <установка>/nn (ставятся установщиком и полным обновлением). Нет модели — работает прежний метод.
#  • speaker.onnx      — CAM++ (3D-Speaker, Apache 2.0): «отпечаток голоса» фразы → кто говорит;
#  • mivolo.onnx       — MiVOLO (Apache 2.0): пол по лицу и фигуре вместе (видна только фигура — по фигуре);
#  • yolox.onnx        — YOLOX-S (OpenCV Zoo, Apache 2.0): где в кадре люди (фигуры для MiVOLO);
#  • voice_gender.onnx — ECAPA voice-gender-classifier (MIT): пол по голосу;
#  • gender.onnx       — EfficientNet-B2 (FaceONNX, MIT): прежняя модель лица, запасная.
NN_DIR = ((INSTALL_DIR / "nn") if INSTALL_DIR else (DATA_ROOT / "nn"))  # не в models: её не трогает полное обновление
SPEAKER_MODEL, GENDER_MODEL = "speaker.onnx", "gender.onnx"
MIVOLO_MODEL, PERSON_MODEL, VOICE_GENDER_MODEL = "mivolo.onnx", "yolox.onnx", "voice_gender.onnx"
NN_ENABLED = {"voice": True, "face": True, "vgender": True}   # переключатели в Настройках → «Нейросети анализа»
SPK_MIN_SEC = 0.6        # короче — отпечаток голоса ненадёжен, фраза присоединяется к соседней
SPK_SAME = 0.25          # средняя косинусная близость, выше которой фразы — один человек
SPK_SINGLE = 0.12        # одиночная фраза присоединяется к самому похожему голосу, если близость не ниже этой


@lru_cache(maxsize=8)
def _onnx_session(name: str):
    path = NN_DIR / name
    if not path.exists():
        return None
    try:
        import onnxruntime as ort
        opts = ort.SessionOptions()
        opts.intra_op_num_threads = max(1, min(4, (os.cpu_count() or 2) // 2))
        opts.log_severity_level = 3
        return ort.InferenceSession(str(path), opts, providers=["CPUExecutionProvider"])
    except Exception:
        return None


@lru_cache(maxsize=2)
def _fbank_bank(sr: int, nfft: int, n_mels: int):
    mel = lambda f: 1127.0 * np.log(1 + f / 700.0)
    centers = np.linspace(mel(20.0), mel(sr / 2), n_mels + 2)
    fm = mel(np.arange(nfft // 2 + 1) * sr / nfft)
    bank = np.zeros((n_mels, nfft // 2 + 1))
    for m in range(n_mels):
        l, c, r = centers[m], centers[m + 1], centers[m + 2]
        bank[m] = np.maximum(0, np.minimum((fm - l) / (c - l), (r - fm) / (r - c)))
    flen = int(0.025 * sr)
    win = (0.5 - 0.5 * np.cos(2 * np.pi * np.arange(flen) / (flen - 1))) ** 0.85  # окно Povey (как в Kaldi)
    return bank.T, win


def kaldi_fbank(x: np.ndarray, sr: int = 16000, n_mels: int = 80) -> np.ndarray:
    """Log-mel fbank как в Kaldi (25 мс / 10 мс, pre-emphasis 0.97) — такие признаки ждёт модель голоса."""
    x = np.asarray(x, np.float32)
    flen, shift, nfft = int(0.025 * sr), int(0.010 * sr), 512
    if len(x) < flen:
        x = np.pad(x, (0, flen - len(x)))
    n = 1 + (len(x) - flen) // shift
    fr = x[np.arange(flen)[None, :] + shift * np.arange(n)[:, None]].astype(np.float64)
    fr -= fr.mean(axis=1, keepdims=True)
    fr[:, 1:] -= 0.97 * fr[:, :-1].copy()
    fr[:, 0] *= 0.03
    bank, win = _fbank_bank(sr, nfft, n_mels)
    spec = np.abs(np.fft.rfft(fr * win, nfft)) ** 2
    return np.log(np.maximum(spec @ bank, 1.2e-7)).astype(np.float32)


def speaker_embedding(audio: np.ndarray, sr: int):
    """Нормированный «отпечаток голоса» (512 чисел) или None."""
    sess = _onnx_session(SPEAKER_MODEL) if NN_ENABLED["voice"] else None
    if sess is None or sr != 16000 or len(audio) < SPK_MIN_SEC * sr:
        return None
    with suppress(Exception):
        f = kaldi_fbank(audio, sr)
        f -= f.mean(axis=0)
        e = sess.run(None, {sess.get_inputs()[0].name: f[None]})[0][0].astype(np.float64)
        nrm = np.linalg.norm(e)
        return e / nrm if nrm > 0 else None
    return None


@lru_cache(maxsize=1)
def _vg_bank():
    """Мел-фильтры и окно как в torchaudio.MelSpectrogram (HTK, 20–7600 Гц, 80 полос, Хэмминг 400 в FFT 512)."""
    hz2mel = lambda f: 2595.0 * np.log10(1.0 + f / 700.0)  # noqa: E731
    f_pts = 700.0 * (10 ** (np.linspace(hz2mel(20.0), hz2mel(7600.0), 82) / 2595.0) - 1.0)
    slopes = f_pts[None, :] - np.linspace(0, 8000, 257)[:, None]
    f_diff = f_pts[1:] - f_pts[:-1]
    bank = np.maximum(0, np.minimum(-slopes[:, :-2] / f_diff[:-1], slopes[:, 2:] / f_diff[1:]))
    win = np.zeros(512)
    win[56:456] = 0.54 - 0.46 * np.cos(2 * np.pi * np.arange(400) / 400)
    return bank, win


def voice_gender_fbank(x: np.ndarray) -> np.ndarray:
    """Признаки для модели пола по голосу (80 × кадры): pre-emphasis 0.97, log-mel, вычитание среднего."""
    x = np.asarray(x, np.float64)
    x = np.concatenate([x[1:2], x])
    x = np.pad(x[1:] - 0.97 * x[:-1], (256, 256), mode="reflect")
    n = 1 + (len(x) - 512) // 160
    bank, win = _vg_bank()
    spec = np.abs(np.fft.rfft(x[np.arange(512)[None, :] + 160 * np.arange(n)[:, None]] * win, axis=1)) ** 2
    mel = np.log(spec @ bank + 1e-6).T
    return (mel - mel.mean(axis=1, keepdims=True)).astype(np.float32)


VG_MIN_SEC = 0.8  # короче — пол по голосу ненадёжен


def voice_gender_logit(audio: np.ndarray, sr: int):
    """Уверенность «женский голос» (логит: >0 — женский, <0 — мужской; |4| и больше — уверенно) или None."""
    sess = _onnx_session(VOICE_GENDER_MODEL) if NN_ENABLED.get("vgender", True) else None
    if sess is None or sr != 16000 or len(audio) < VG_MIN_SEC * sr:
        return None
    with suppress(Exception):
        out = sess.run(None, {"fbank": voice_gender_fbank(audio)[None]})[0][0]
        return float(out[1] - out[0])
    return None


def cluster_embeddings(embs: list, max_speakers: int, f0_bases: list = None) -> list:
    """Средняя связь (average linkage) по косинусной близости. None — фраза без отпечатка (присоединяется к ближайшей
    по времени). Номера — по порядку первого появления."""
    idx = [i for i, e in enumerate(embs) if e is not None]
    if not idx:
        return None
    E = np.array([embs[i] for i in idx])
    S = E @ E.T
    if f0_bases:  # заметно разная «база» высоты голоса (в 1.4+ раза) — почти наверняка разные люди
        f = np.array([f0_bases[i] or 0.0 for i in idx], np.float64)
        ok = f > 0
        with np.errstate(divide="ignore", invalid="ignore"):
            d = np.abs(np.log2(np.where(ok, f, 1)[:, None] / np.where(ok, f, 1)[None, :]))
        pen = 0.35 * np.clip((d - 0.4) / 0.3, 0, 1) * (ok[:, None] & ok[None, :])
        S = S - pen
    groups = [[k] for k in range(len(idx))]
    while len(groups) > 1:
        best, pair = -2.0, None
        for a in range(len(groups)):
            for b in range(a + 1, len(groups)):
                v = float(S[np.ix_(groups[a], groups[b])].mean())
                if v > best:
                    best, pair = v, (a, b)
        if best < SPK_SAME and len(groups) <= max(1, max_speakers):
            break
        a, b = pair
        groups[a] += groups.pop(b)
    # одиночная фраза с «непохожим» голосом — чаще всего смесь двух голосов или шум, а не новый персонаж
    for g in sorted([g for g in groups if len(g) == 1], key=lambda g: g[0]):
        others = [o for o in groups if o is not g]
        if len(groups) > 1 and others:
            best = max(others, key=lambda o: float(S[np.ix_(g, o)].mean()))
            if float(S[np.ix_(g, best)].mean()) >= SPK_SINGLE:
                best += g
                groups.remove(g)
    lab_of = {}
    for g, members in enumerate(groups):
        for k in members:
            lab_of[idx[k]] = g
    labels = []
    for i in range(len(embs)):
        if i in lab_of:
            labels.append(lab_of[i])
        else:
            near = min(idx, key=lambda j: abs(j - i))
            labels.append(lab_of[near])
    order = {}
    for l in labels:
        order.setdefault(l, len(order))
    return [order[l] for l in labels]


class FaceGender:
    """Вероятность «женский» для человека в кадре. Основной способ — MiVOLO: лицо + фигура вместе (фигуры находит
    YOLOX); без модели MiVOLO — прежняя модель лица."""
    MEAN, STD = np.array([0.485, 0.456, 0.406], np.float32), np.array([0.229, 0.224, 0.225], np.float32)
    YOLO_SIZE, PERSON_CONF = 640, 0.45

    @staticmethod
    def available() -> bool:
        return NN_ENABLED["face"] and (_onnx_session(MIVOLO_MODEL) is not None or _onnx_session(GENDER_MODEL) is not None)

    @classmethod
    def p_female(cls, frame: np.ndarray, box, faces: list = None):
        if _onnx_session(MIVOLO_MODEL) is not None:
            return cls._mivolo(frame, box, faces or ([box] if box else []))
        return cls._face_only(frame, box) if box else None

    # ---------- MiVOLO ----------
    @classmethod
    def persons(cls, frame: np.ndarray) -> list:
        """Фигуры людей: [(x0, y0, x1, y1)]."""
        sess = _onnx_session(PERSON_MODEL)
        if sess is None:
            return []
        with suppress(Exception):
            H, W = frame.shape[:2]
            S = cls.YOLO_SIZE
            r = min(S / H, S / W)
            img = np.full((S, S, 3), 114, np.uint8)
            rs = cv2.resize(frame, (max(1, int(W * r)), max(1, int(H * r))), interpolation=cv2.INTER_LINEAR)
            img[:rs.shape[0], :rs.shape[1]] = rs
            out = sess.run(None, {sess.get_inputs()[0].name: img.transpose(2, 0, 1)[None].astype(np.float32)})[0][0]
            grid, stride = cls._yolo_grid(S)
            score = out[:, 4] * out[:, 5]  # «есть объект» × «это человек» (класс 0 в COCO)
            keep = score > cls.PERSON_CONF
            if not keep.any():
                return []
            xy = (out[keep, :2] + grid[keep]) * stride[keep] / r
            wh = np.exp(out[keep, 2:4]) * stride[keep] / r
            boxes = np.concatenate([xy - wh / 2, wh], 1)
            idx = np.array(cv2.dnn.NMSBoxes(boxes.tolist(), score[keep].tolist(), cls.PERSON_CONF, 0.45)).reshape(-1)
            res = []
            for i in idx:
                x, y, w, h = boxes[i]
                res.append((int(max(0, x)), int(max(0, y)), int(min(W, x + w)), int(min(H, y + h))))
            return res
        return []

    @staticmethod
    @lru_cache(maxsize=1)
    def _yolo_grid(S: int):
        grids, strides = [], []
        for st in (8, 16, 32):
            n = S // st
            yv, xv = np.meshgrid(np.arange(n), np.arange(n), indexing="ij")
            grids.append(np.stack([xv, yv], -1).reshape(-1, 2))
            strides.append(np.full((n * n, 1), st))
        return np.concatenate(grids).astype(np.float32), np.concatenate(strides).astype(np.float32)

    @classmethod
    def _prep(cls, crop):
        if crop is None:  # нет лица / фигуры — чёрная картинка, как при обучении MiVOLO
            return np.broadcast_to((-cls.MEAN / cls.STD)[:, None, None], (3, 224, 224))
        h, w = crop.shape[:2]
        r = min(224 / h, 224 / w)
        nw, nh = int(round(w * r)), int(round(h * r))
        if (nw, nh) != (w, h):
            crop = cv2.resize(crop, (nw, nh), interpolation=cv2.INTER_LINEAR)
        dw, dh = (224 - nw) / 2, (224 - nh) / 2
        crop = cv2.copyMakeBorder(crop, int(round(dh - 0.1)), int(round(dh + 0.1)), int(round(dw - 0.1)),
                                  int(round(dw + 0.1)), cv2.BORDER_CONSTANT, value=(0, 0, 0))
        im = cv2.cvtColor(crop, cv2.COLOR_BGR2RGB).astype(np.float32) / 255.0
        return ((im - cls.MEAN) / cls.STD).transpose(2, 0, 1)

    @staticmethod
    def _body_crop(frame, persons, pi, faces_xyxy):
        """Фигура без лиц и без соседей (как при обучении MiVOLO): лицо модель получает отдельно."""
        x1, y1, x2, y2 = persons[pi]
        if x2 - x1 < 50 or y2 - y1 < 50:
            return None
        crop = frame[y1:y2, x1:x2].copy()
        ch, cw = crop.shape[:2]
        others = [(True, f) for f in faces_xyxy] + [(False, p) for j, p in enumerate(persons) if j != pi]
        for is_face, (a, b, c, d) in others:
            ox1, oy1, ox2, oy2 = max(a - x1, 0), max(b - y1, 0), min(c - x1, cw), min(d - y1, ch)
            if ox2 <= ox1 or oy2 <= oy1:
                continue
            if not is_face:  # сосед у края — закрываем до края
                oy1 = 0 if oy1 / ch < 0.3 else oy1
                oy2 = ch if (ch - oy2) / ch < 0.3 else oy2
                ox1 = 0 if ox1 / cw < 0.3 else ox1
                ox2 = cw if (cw - ox2) / cw < 0.3 else ox2
            crop[oy1:oy2, ox1:ox2] = 0
        return crop if np.count_nonzero(crop) / crop.size >= 0.4 else None

    @classmethod
    def _mivolo(cls, frame, box, faces):
        sess = _onnx_session(MIVOLO_MODEL)
        H, W = frame.shape[:2]
        xyxy = lambda b: (int(max(0, b[0])), int(max(0, b[1])), int(min(W, b[0] + b[2])), int(min(H, b[1] + b[3])))  # noqa: E731
        persons = cls.persons(frame)
        fcrop, pi = None, None
        if box is not None:
            fx1, fy1, fx2, fy2 = xyxy(box)
            if fx2 - fx1 >= 8 and fy2 - fy1 >= 8:
                fcrop = frame[fy1:fy2, fx1:fx2].copy()
            fa, best = max(1, (fx2 - fx1) * (fy2 - fy1)), 1e-4
            for i, (a, b, c, d) in enumerate(persons):  # фигура, в которой это лицо
                ov = max(0, min(c, fx2) - max(a, fx1)) * max(0, min(d, fy2) - max(b, fy1)) / fa
                if ov > best:
                    best, pi = ov, i
        elif persons:  # лица не видно — крупнейшая фигура
            pi = max(range(len(persons)), key=lambda i: (persons[i][2] - persons[i][0]) * (persons[i][3] - persons[i][1]))
        bcrop = cls._body_crop(frame, persons, pi, [xyxy(f) for f in faces]) if pi is not None else None
        if fcrop is None and bcrop is None:
            return None
        with suppress(Exception):
            x = np.concatenate([cls._prep(fcrop), cls._prep(bcrop)], 0)[None].astype(np.float32)
            o = sess.run(None, {sess.get_inputs()[0].name: x})[0][0][:2].astype(np.float64)
            e = np.exp(o - o.max())
            return float(e[1] / e.sum())  # 0 — мужской, 1 — женский
        return None

    # ---------- прежняя модель (только лицо) ----------
    @classmethod
    def _face_only(cls, frame: np.ndarray, box, margin: float = 0.25):
        sess = _onnx_session(GENDER_MODEL)
        if sess is None:
            return None
        x, y, w, h = box
        H, W = frame.shape[:2]
        x0, y0 = int(max(0, x - w * margin)), int(max(0, y - h * margin))
        x1, y1 = int(min(W, x + w * (1 + margin))), int(min(H, y + h * (1 + margin)))
        if x1 - x0 < 24 or y1 - y0 < 24:
            return None
        with suppress(Exception):
            crop = cv2.cvtColor(cv2.resize(frame[y0:y1, x0:x1], (224, 224), interpolation=cv2.INTER_LINEAR), cv2.COLOR_BGR2RGB)
            t = ((crop.astype(np.float32) / 255.0 - cls.MEAN) / cls.STD).transpose(2, 0, 1)[None]
            out = sess.run(None, {sess.get_inputs()[0].name: np.ascontiguousarray(t)})[-1][0].astype(np.float64)
            if out.min() < 0 or abs(out.sum() - 1) > 0.02:  # логиты → вероятности
                out = np.exp(out - out.max())
                out /= out.sum()
            return float(out[1])
        return None


def fused_gender(f0_all: np.ndarray, face_ps: list, voice_logits: list = None):
    """Пол персонажа по всем признакам сразу. None — данных нет.
    • голос: нейросеть (логиты фраз, взвешенные по длительности), без неё — «база» высоты голоса;
    • лицо и фигура: [(p_жен, вес)] — вес выше, когда у человека в кадре двигаются губы (говорит именно он).
    Уверенный голос важнее (в кадре может быть слушатель, а говорит человек за кадром); при «пограничном» голосе
    (низкий женский, высокий мужской) решают лицо и фигура."""
    score, have = 0.0, False
    vl = [(float(np.clip(l, -8.0, 8.0)), max(0.1, d)) for l, d in (voice_logits or []) if l is not None]
    if vl:
        score += float(sum(l * d for l, d in vl) / sum(d for _, d in vl)) * min(1.0, 0.5 + 0.25 * len(vl))
        have = True
    elif len(f0_all) >= 25:
        base = float(np.percentile(f0_all, 35))
        score += float(np.clip((base - FEMALE_F0_HZ) / 15.0, -4.0, 4.0))
        have = True
    ev = [(p, 1.0) if not isinstance(p, (tuple, list)) else (p[0], p[1]) for p in (face_ps or [])]
    ev = [(p, w) for p, w in ev if p is not None and w > 0]
    if ev:
        ps = np.clip(np.array([p for p, _ in ev], np.float64), 0.02, 0.98)
        ws = np.array([w for _, w in ev], np.float64)
        face = float(np.clip(np.sum(np.log(ps / (1 - ps)) * ws) / ws.sum(), -3.0, 3.0))
        score += face * (0.5 if vl else 0.6) * min(1.0, ws.sum() / 4.0)
        have = True
    return (score > 0) if have else None


def assign_speaker_colors(speakers_count, speaker_genders, default_mode, enable_female_colors=False) -> dict:
    styles, fem_i, def_i = {}, 0, 0
    for sp in range(speakers_count):
        is_fem = bool(speaker_genders.get(sp, False))
        if is_fem and enable_female_colors:
            col, fem_i = FEMALE_SPEAKER_HEX[fem_i % len(FEMALE_SPEAKER_HEX)], fem_i + 1
        else:
            col, def_i = DEFAULT_SPEAKER_HEX[def_i % len(DEFAULT_SPEAKER_HEX)], def_i + 1
        styles[str(sp)] = {"color": col, "mode": default_mode, "is_female": is_fem}
    return styles


# ---------------------------- БАЛАНС ТОКЕНОВ ----------------------------
class TokifyBalanceChecker:
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Origin": "https://tokify.sale",
        "Referer": "https://tokify.sale/#dashboard",
    }
    PRIORITY_KEYS = (
        "remaining_tokens", "tokens_remaining", "tokens_left", "left_tokens", "available_tokens", "token_balance",
        "tokens_balance", "balance_tokens", "remaining", "quota_remaining", "remain_quota", "tokens", "balance", "quota",
    )

    @classmethod
    def _extract_tokens_from_json(cls, data) -> str:
        if not isinstance(data, dict):
            return ""
        candidates = [data] + [data[k] for k in ("data", "key", "quota", "usage", "balance", "account", "info", "result", "user")
                               if isinstance(data.get(k), dict)]
        for obj in candidates:
            total = obj.get("total_tokens") or obj.get("max_tokens") or obj.get("quota_limit") or obj.get("limit")
            used = obj.get("used_tokens") or obj.get("tokens_used") or obj.get("used_quota") or obj.get("used")
            if isinstance(total, (int, float)) and isinstance(used, (int, float)) and total >= used:
                return format_token_number(total - used)
            for pk in cls.PRIORITY_KEYS:
                val = obj.get(pk)
                if val is None or isinstance(val, (dict, list)):
                    continue
                if isinstance(val, (int, float)) or (isinstance(val, str) and any(ch.isdigit() for ch in val)):
                    return format_token_number(val)
        return ""

    @classmethod
    def _check_via_headless_dashboard(cls, key: str) -> str:
        try:
            from playwright.sync_api import sync_playwright
            exe_path = find_system_browser_exe()
            if not exe_path:
                return ""
            captured = []
            with sync_playwright() as p:
                browser = p.chromium.launch(executable_path=exe_path, headless=True,
                                            args=["--disable-blink-features=AutomationControlled"])
                page = browser.new_page()

                def _on_response(resp):
                    with suppress(Exception):
                        if "application/json" in resp.headers.get("content-type", "").lower():
                            t = cls._extract_tokens_from_json(resp.json())
                            if t:
                                captured.append(t)

                page.on("response", _on_response)
                page.goto("https://tokify.sale/#dashboard", wait_until="domcontentloaded", timeout=15000)
                page.wait_for_timeout(1200)
                inp = page.locator("input[type='password'], input[placeholder*='sk-'], input[placeholder*='ключ'], "
                                   "input[placeholder*='key'], #dashboard input").first
                if inp.count() > 0:
                    inp.fill(key)
                    page.wait_for_timeout(300)
                    btn = page.locator("button:has-text('Проверить ключ'), button:has-text('Проверить'), #dashboard button").first
                    btn.click() if btn.count() > 0 else inp.press("Enter")
                    page.wait_for_timeout(2500)
                body_text = "" if captured else page.locator("body").inner_text()
                browser.close()
            if captured:
                return captured[-1]
            for pat in (r"(?:остаток|осталось|доступно|баланс|remaining)[^\d\n]{0,25}([\d][\d\s.,]*\s*(?:млн|млрд|тыс|k|m|b)?)",
                        r"([\d][\d\s.,]+\s*(?:млн|млрд|тыс)?)\s*(?:токен|tokens)"):
                for m in re.finditer(pat, body_text, re.IGNORECASE):
                    cand = m.group(1).strip()
                    if "372" not in cand and "383" not in cand and cand:
                        return cand
        except Exception:
            pass
        return ""

    @classmethod
    def fetch_remaining_tokens(cls, api_key: str, base_url: str, allow_browser: bool = True) -> str:
        import requests  # ленивый импорт — не замедляет старт окна
        key = clean_api_key(api_key)
        if not key:
            return "ключ не указан"

        if "openrouter.ai" in base_url:
            with suppress(Exception):
                r = requests.get("https://openrouter.ai/api/v1/auth/key", headers={"Authorization": f"Bearer {key}"}, timeout=8)
                if r.status_code == 200:
                    d = r.json().get("data", {})
                    usage = float(d.get("usage", 0))
                    if d.get("limit") is not None:
                        return f"${max(0.0, float(d['limit']) - usage):.3f}"
                    return f"Исп.: ${usage:.3f}"

        m = re.match(r"^(https?://[^/]+)", base_url.strip())
        base_host = m.group(1) if m else "https://tokify.sale"
        headers = {**cls.HEADERS, "Authorization": f"Bearer {key}", "X-API-Key": key}
        for path in ("/api/key", "/v1/key", "/api/quota", "/api/balance", "/v1/usage"):
            with suppress(Exception):
                resp = requests.get(f"{base_host.rstrip('/')}{path}", headers=headers, timeout=4)
                if resp.status_code == 200 and "application/json" in resp.headers.get("Content-Type", ""):
                    tok = cls._extract_tokens_from_json(resp.json())
                    if tok:
                        return tok
        if allow_browser:
            tok = cls._check_via_headless_dashboard(key)
            if tok:
                return tok
        return "активен"


# ---------------------------- СУБТИТРЫ ----------------------------
@lru_cache(maxsize=32)
def load_pil_font(font_name: str, font_size: int):
    win_fonts = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
    for fname in FONT_MAP.get(font_name, ["seguisym.ttf"] if font_name == "Segoe UI Symbol" else []) + ["arialbd.ttf", "arial.ttf", "segoeui.ttf"]:
        with suppress(Exception):
            if (win_fonts / fname).exists():
                return ImageFont.truetype(str(win_fonts / fname), font_size)
    return ImageFont.load_default()


class SubtitleRenderer:
    """
    Рендерер субтитров v3.3: текст фразы (или фразы с подсвеченным словом) рисуется в PIL ОДИН раз
    и кэшируется как прозрачный оверлей. На каждом кадре он лишь смешивается с кадром в пределах
    области текста — вместо полной отрисовки PIL на каждом кадре.
    """

    def __init__(self, font_name="Arial", font_size=70, bg_box=False, word_by_word=False,
                 enable_female_colors=False, speaker_styles=None):
        self.font_name, self.font_size = font_name, font_size
        self.bg_box, self.word_by_word = bg_box, word_by_word
        self.enable_female_colors = enable_female_colors
        self.speaker_styles = speaker_styles or {}
        self._cache = {}

    @property
    def default_mode(self) -> str:
        return "word" if self.word_by_word else ("bg" if self.bg_box else "text")

    def _style(self, sp_id: int):
        st = self.speaker_styles.get(sp_id) or self.speaker_styles.get(str(sp_id))
        if st:
            c = st.get("color", speaker_hex(sp_id))
            color, mode = (hex_to_rgb(c) if isinstance(c, str) else tuple(c)), st.get("mode", self.default_mode)
        else:
            color, mode = hex_to_rgb(speaker_hex(sp_id)), self.default_mode
        return color, ("word" if self.word_by_word else mode)

    @staticmethod
    def _active_word(seg: dict, tokens: list, t: float) -> int:
        words = seg.get("words") or []
        if words and len(words) == len(tokens):
            for i, w in enumerate(words):
                if float(w["start"]) <= t <= float(w["end"]):
                    return i
            return max([-1] + [i for i, w in enumerate(words) if t >= float(w["start"])])
        s = float(seg.get("start", 0.0))
        e = max(s + 0.1, float(seg.get("end", s + 1.0)))
        return int(max(0.0, min(0.999, (t - s) / (e - s))) * len(tokens))

    def _build_overlay(self, text, w, h, color, mode, active_idx):
        scale = h / 1920.0 if h > w else h / 1080.0
        fs = max(18, int(round(self.font_size * scale)))
        font = load_pil_font(self.font_name, fs)
        roi_y1, roi_y2 = int(h * 0.58), int(h * 0.96)
        roi_h = roi_y2 - roi_y1
        img = Image.new("RGBA", (w, roi_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        max_chars = max(12, int((w * 0.88) / max(1, fs * 0.56)))
        spacing = int(fs * 0.20)
        stroke = dict(stroke_width=max(2, int(fs * 0.09)), stroke_fill=(0, 0, 0))
        bbox_wh = lambda s: (lambda b: (b[2] - b[0], b[3] - b[1]))(draw.textbbox((0, 0), s, font=font))

        if mode == "word":
            lines, cur, cur_len = [], [], 0
            for i, tok in enumerate(text.split()):
                if cur and cur_len + 1 + len(tok) > max_chars:
                    lines.append(cur)
                    cur, cur_len = [(i, tok)], len(tok)
                else:
                    cur.append((i, tok))
                    cur_len += (1 if cur_len > 0 else 0) + len(tok)
            if cur:
                lines.append(cur)
            space_w = draw.textbbox((0, 0), " ", font=font)[2]
            metrics = []
            for ln in lines[:3]:
                sizes = [bbox_wh(t) for _, t in ln]
                metrics.append((ln, [s[0] for s in sizes], sum(s[0] for s in sizes) + space_w * max(0, len(ln) - 1),
                                max(s[1] for s in sizes)))
            total_h = sum(m[3] for m in metrics) + spacing * max(0, len(metrics) - 1)
            y = max(10, int(h * 0.85) - roi_y1 - total_h)
            for ln, widths, tot_w, max_h in metrics:
                x = int((w - tot_w) * 0.5)
                for (ti, tok), ww in zip(ln, widths):
                    draw.text((x, y), tok, font=font, fill=color if ti == active_idx else (255, 255, 255), **stroke)
                    x += ww + space_w
                y += max_h + spacing
        else:
            lines = [(ln, *bbox_wh(ln)) for ln in textwrap.wrap(text, width=max_chars)[:3]]
            total_h = sum(l[2] for l in lines) + spacing * max(0, len(lines) - 1)
            max_w = max([l[1] for l in lines] or [0])
            y = max(12, int(h * 0.85) - roi_y1 - total_h)
            if mode == "bg":
                px, py, rad = int(fs * 0.42), int(fs * 0.25), max(8, int(fs * 0.28))
                bx1, by1 = max(8, int((w - max_w) * 0.5) - px), max(4, y - py)
                bx2, by2 = min(w - 8, int((w + max_w) * 0.5) + px), min(roi_h - 4, y + total_h + py)
                draw.rounded_rectangle([bx1 - 2, by1 - 2, bx2 + 2, by2 + 2], radius=rad, fill=(15, 15, 15))
                draw.rounded_rectangle([bx1, by1, bx2, by2], radius=rad, fill=color)
            for ln, lw, lh in lines:
                lx = int((w - lw) * 0.5)
                if mode == "bg":
                    draw.text((lx + 2, y + 2), ln, font=font, fill=(20, 20, 20))
                    draw.text((lx, y), ln, font=font, fill=(255, 255, 255))
                else:
                    draw.text((lx, y), ln, font=font, fill=color, **stroke)
                y += lh + spacing

        arr = np.asarray(img)
        ys, xs = np.nonzero(arr[:, :, 3])
        if len(ys) == 0:
            return None
        y1, y2, x1, x2 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        crop = arr[y1:y2, x1:x2].astype(np.float32)
        alpha = crop[:, :, 3:4] / 255.0
        premul = crop[:, :, 2::-1] * alpha + 0.5  # RGB -> BGR, +0.5 для округления
        return roi_y1 + y1, roi_y1 + y2, x1, x2, premul, 1.0 - alpha

    def draw_subtitle(self, frame_bgr: np.ndarray, seg: dict, speaker_id: int, abs_time: float) -> np.ndarray:
        text = seg.get("text", "").strip()
        if not text:
            return frame_bgr
        h, w = frame_bgr.shape[:2]
        color, mode = self._style(int(speaker_id))
        active = self._active_word(seg, text.split(), abs_time) if mode == "word" else -1
        key = (seg.get("start"), seg.get("end"), text, w, h, color, mode, active)
        if key not in self._cache:
            if len(self._cache) >= 8:
                self._cache.clear()
            self._cache[key] = self._build_overlay(text, w, h, color, mode, active)
        ov = self._cache[key]
        if ov is not None:
            y1, y2, x1, x2, premul, inv_a = ov
            roi = frame_bgr[y1:y2, x1:x2]
            roi[:] = (roi * inv_a + premul).astype(np.uint8)
        return frame_bgr


# ---------------------------- ТРЕКЕР ГОВОРЯЩЕГО + РЕНДЕР ----------------------------
# ---------------------------- БАННЕРЫ ----------------------------
BANNERS_DIR = (INSTALL_DIR or DATA_ROOT) / "banners"   # создаётся установщиком; при необходимости — программой
BANNER_EXTS = {".mp4", ".webm", ".mov", ".jpeg", ".jpg", ".png", ".gif"}
BANNER_IMAGE_SEC = 5.0          # сколько показывается картинка (у видео и анимированного GIF — их длительность)
BANNER_NONE = "<Пусто>"
BANNER_POSITIONS = {"start": "В начале", "middle": "В середине", "end": "В конце"}


def list_banners() -> list:
    with suppress(Exception):
        BANNERS_DIR.mkdir(parents=True, exist_ok=True)
        return sorted((p.name for p in BANNERS_DIR.iterdir() if p.is_file() and p.suffix.lower() in BANNER_EXTS),
                      key=str.lower)
    return []


@lru_cache(maxsize=64)
def _probe_banner_cached(path: str, mtime: float, size: int) -> dict:
    info = {"w": 0, "h": 0, "dur": BANNER_IMAGE_SEC, "audio": False, "alpha": False, "still": True, "vp": ""}
    ext = Path(path).suffix.lower()
    with suppress(Exception):
        res = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                              "stream=codec_type,codec_name,width,height,pix_fmt,nb_frames,duration:stream_tags=alpha_mode"
                              ":format=duration", "-of", "json", path],
                             capture_output=True, text=True, timeout=20, creationflags=NO_WINDOW_FLAG)
        data = json.loads(res.stdout or "{}")
        fmt_dur = float((data.get("format") or {}).get("duration") or 0)
        for st in data.get("streams", []):
            if st.get("codec_type") == "audio":
                info["audio"] = True
            elif st.get("codec_type") == "video" and not info["w"]:
                info["w"], info["h"] = int(st.get("width") or 0), int(st.get("height") or 0)
                pix, codec = str(st.get("pix_fmt", "")), str(st.get("codec_name", ""))
                alpha_tag = str((st.get("tags") or {}).get("alpha_mode", "")) == "1"
                info["alpha"] = alpha_tag or pix == "pal8" or pix.startswith(("yuva", "rgba", "bgra", "argb", "abgr", "gbrap", "ya"))
                if codec in ("vp8", "vp9") and alpha_tag:
                    info["vp"] = "libvpx-vp9" if codec == "vp9" else "libvpx"  # встроенный декодер VP9 теряет прозрачность
                frames = int(st.get("nb_frames") or 0) if str(st.get("nb_frames", "")).isdigit() else 0
                dur = float(st.get("duration") or 0) or fmt_dur
                info["still"] = ext in (".png", ".jpg", ".jpeg") or (ext == ".gif" and frames <= 1 and dur <= 0.11)
                if not info["still"] and dur > 0:
                    info["dur"] = dur
    if ext in (".png", ".jpg", ".jpeg", ".gif"):
        info["audio"] = False
    return info


def probe_banner(name: str) -> dict:
    p = BANNERS_DIR / name
    try:
        st = p.stat()
    except OSError:
        return {}
    return dict(_probe_banner_cached(str(p), st.st_mtime, st.st_size), path=str(p), name=name)


def banner_auto_start(clip_dur: float, banner_dur: float, pos: str) -> float:
    """Клип делится на 3 равные части; баннер встаёт серединой в середину выбранной части."""
    k = {"start": 0, "middle": 1, "end": 2}.get(pos, 1)
    mid = clip_dur * (2 * k + 1) / 6
    return round(max(0.0, min(mid - banner_dur / 2, clip_dur - banner_dur)), 2)


BANNER_REF_W, BANNER_REF_H, BANNER_BOTTOM = 1080, 1920, 30   # макет 9:16; по умолчанию — 30 px от низа


BANNER_SCALE_MIN, BANNER_SCALE_MAX = 0.15, 3.0   # размер, который можно задать в «Положении» (1 — стандартный)


def banner_scale(xy) -> float:
    """Масштаб баннера: третий элемент положения [x, y, масштаб] (нет — стандартный размер)."""
    with suppress(Exception):
        if xy and len(xy) > 2:
            return float(min(BANNER_SCALE_MAX, max(BANNER_SCALE_MIN, float(xy[2]))))
    return 1.0


def banner_xy_value(xy):
    """Положение для сохранения: [x, y] или [x, y, масштаб], если размер изменён."""
    if not xy:
        return None
    sc = banner_scale(xy)
    return [int(xy[0]), int(xy[1])] + ([round(sc, 3)] if abs(sc - 1.0) > 1e-3 else [])


def banner_size(info: dict, out_w: int, out_h: int, scale: float = 1.0) -> tuple:
    """Родной размер видимой части относительно кадра 1080×1920 (стандартно — не больше кадра) × масштаб."""
    bw, bh = max(1, info.get("w") or out_w), max(1, info.get("h") or out_h)
    k = min(out_w / bw, out_h / bh, out_w / float(BANNER_REF_W)) * scale
    return max(2, int(round(bw * k / 2)) * 2), max(2, int(round(bh * k / 2)) * 2)


BANNER_KEEP = 60   # px макета: столько баннера всегда остаётся в кадре (за рамку его можно вытащить обратно)


def clamp_banner_xy(x, y, w, h, fw=BANNER_REF_W, fh=BANNER_REF_H, keep=BANNER_KEEP) -> tuple:
    """Баннер можно частично вынести за край кадра (невидимая часть не попадёт в клип), но не целиком."""
    kx, ky = min(keep, w), min(keep, h)
    return int(max(kx - w, min(fw - kx, x))), int(max(ky - h, min(fh - ky, y)))


def banner_box(info: dict, out_w: int, out_h: int, xy=None) -> tuple:
    """Место баннера: xy — левый верхний угол в координатах макета 1080×1920 (None — по центру, 30 px от низа).
    Координаты могут выходить за кадр — тогда видна только часть баннера."""
    w, h = banner_size(info, out_w, out_h, banner_scale(xy))
    if xy:
        x = int(round(float(xy[0]) / BANNER_REF_W * out_w))
        y = int(round(float(xy[1]) / BANNER_REF_H * out_h))
        return (*clamp_banner_xy(x, y, w, h, out_w, out_h, int(BANNER_KEEP * out_w / BANNER_REF_W)), w, h)
    x, y = (out_w - w) // 2, out_h - h - int(round(BANNER_BOTTOM * out_h / BANNER_REF_H))
    return max(0, min(out_w - w, x)), max(0, min(out_h - h, y)), w, h


def banner_preview(info: dict):
    """Один кадр баннера (для видео — из середины) как RGBA-картинка в родном размере."""
    w, h = max(2, info.get("w") or 2), max(2, info.get("h") or 2)
    cmd = ["ffmpeg", "-v", "error"]
    if not info.get("still"):
        cmd += ["-ss", f"{max(0.0, info.get('dur', 0) / 2):.3f}"]
    if info.get("vp"):
        cmd += ["-c:v", info["vp"]]
    cmd += ["-i", info["path"], "-frames:v", "1", "-f", "rawvideo", "-pix_fmt", "rgba", "-"]
    with suppress(Exception):
        raw = subprocess.run(cmd, capture_output=True, timeout=20, creationflags=NO_WINDOW_FLAG).stdout
        if len(raw) < w * h * 4 and info.get("vp"):
            raw = subprocess.run([c for c in cmd if c not in ("-c:v", info["vp"])], capture_output=True, timeout=20,
                                 creationflags=NO_WINDOW_FLAG).stdout
        if len(raw) >= w * h * 4:
            return Image.frombuffer("RGBA", (w, h), raw[:w * h * 4], "raw", "RGBA", 0, 1).copy()
    return None


class BannerStream:
    """Кадры баннера (BGRA, уже нужного размера и fps клипа) из отдельного ffmpeg — читаются по мере рендера."""

    def __init__(self, info: dict, fps: float, w: int, h: int):
        self.w, self.h, self.size = w, h, w * h * 4
        self.n = max(1, int(round(min(info["dur"], 600) * fps)))
        self.info, self.fps, self.got = info, fps, 0
        self._start(info.get("vp"))

    def _start(self, vp_decoder):
        info, fps, w, h = self.info, self.fps, self.w, self.h
        self.vp = vp_decoder
        cmd = ["ffmpeg", "-v", "error"]
        if info.get("still"):
            cmd += ["-loop", "1", "-t", f"{info['dur']:.3f}"]
        if vp_decoder:
            cmd += ["-c:v", vp_decoder]
        cmd += ["-i", info["path"], "-an", "-vf", f"fps={fps:.3f},scale={w}:{h}:flags=lanczos,format=bgra",
                "-frames:v", str(self.n), "-f", "rawvideo", "-pix_fmt", "bgra", "-"]
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                                     creationflags=NO_WINDOW_FLAG)
        self.last = None

    def next(self):
        if self.proc is not None:
            buf = self.proc.stdout.read(self.size)
            if len(buf) == self.size:
                self.last, self.got = np.frombuffer(buf, np.uint8).reshape(self.h, self.w, 4), self.got + 1
            else:
                self.close()
                if not self.got and self.vp:  # в сборке ffmpeg нет libvpx — читаем встроенным декодером
                    self._start(None)
                    return self.next()
        return self.last

    def close(self):
        if self.proc is not None:
            with suppress(Exception):
                self.proc.stdout.close()
            with suppress(Exception):
                self.proc.kill()
                self.proc.wait(timeout=3)
            self.proc = None


def blend_bgra(dst: np.ndarray, src: np.ndarray, x: int, y: int) -> np.ndarray:
    """Накладывает BGRA поверх BGR с учётом прозрачности (без фона под баннером). Часть за краем кадра отбрасывается."""
    H, W = dst.shape[:2]
    x0, y0, x1, y1 = max(0, x), max(0, y), min(W, x + src.shape[1]), min(H, y + src.shape[0])
    if x1 <= x0 or y1 <= y0:
        return dst
    src = src[y0 - y:y1 - y, x0 - x:x1 - x]
    roi = dst[y0:y1, x0:x1]
    a = src[:, :, 3:4]
    if a.min() == 255:
        roi[:] = src[:, :, :3]
        return dst
    if a.max() == 0:
        return dst
    af = a.astype(np.uint16)
    roi[:] = ((src[:, :, :3].astype(np.uint16) * af + roi.astype(np.uint16) * (255 - af) + 127) // 255).astype(np.uint8)
    return dst


def build_ffmpeg_render_cmd(out_w, out_h, fps, start_t, duration, video_path, num_tracks, boost_audio, out_path,
                            banner_audio=None):
    """banner_audio = (путь, начало в клипе, сек) — звук баннера подмешивается к звуку клипа, не заглушая его."""
    a_norm = "dynaudnorm=f=150:g=15,loudnorm=I=-14:TP=-1.5:LRA=11,volume=1.5" if boost_audio else "volume=1.0"
    cmd = ["ffmpeg", "-y", "-f", "rawvideo", "-vcodec", "rawvideo", "-s", f"{out_w}x{out_h}", "-pix_fmt", "bgr24",
           "-r", f"{fps:.3f}", "-i", "-", "-ss", str(start_t), "-t", str(duration), "-i", str(video_path)]
    if banner_audio:
        b_path, b_start, b_dur = banner_audio
        ms = int(round(max(0.0, b_start) * 1000))
        cmd += ["-i", str(b_path)]
        main = ("".join(f"[1:a:{i}]" for i in range(num_tracks)) +
                f"amix=inputs={num_tracks}:duration=longest:dropout_transition=0,{a_norm}[m]") if num_tracks > 1 \
            else f"[1:a:0]{a_norm}[m]"
        cmd += ["-filter_complex",
                f"{main};[2:a:0]atrim=0:{b_dur:.3f},aresample=48000,adelay={ms}:all=1[b];"
                f"[m][b]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[aout]",
                "-map", "0:v:0", "-map", "[aout]"]
    elif num_tracks > 1:
        a_in = "".join(f"[1:a:{i}]" for i in range(num_tracks))
        cmd += ["-filter_complex", f"{a_in}amix=inputs={num_tracks}:duration=longest:dropout_transition=0,{a_norm}[aout]",
                "-map", "0:v:0", "-map", "[aout]"]
    else:
        cmd += ["-af", a_norm, "-map", "0:v:0", "-map", "1:a:0?"]
    return cmd + ["-c:v", "libx264", "-preset", "fast", "-crf", "22", "-c:a", "aac", "-ac", "2", "-ar", "48000",
                  "-b:a", "192k", "-shortest", str(out_path)]


YUNET_MODEL = "face_detection_yunet_2023mar.onnx"   # нейросетевой детектор лиц OpenCV (app/assets), 232 КБ


class ActiveSpeakerTracker:
    """
    Кого держать в кадре 9:16. Лица ищет нейросеть YuNet (уверенно находит лица на тёмных вебках и в профиль);
    старые каскады Хаара — только запасной вариант. Силуэты тела используются, лишь если в клипе нет ни одного лица,
    иначе они дают ложные цели (микрофонная стойка, кресло, игрушки). Детекторы загружаются при первом рендере.
    """
    CASCADES = {"frontal": "haarcascade_frontalface_default.xml", "profile": "haarcascade_profileface.xml",
                "upperbody": "haarcascade_upperbody.xml", "fullbody": "haarcascade_fullbody.xml"}

    def __init__(self):
        self._initialized = False
        self.det = {}
        self.hog = self.yunet = None

    def _ensure_initialized(self):
        if self._initialized:
            return
        self._initialized = True
        with suppress(Exception):
            haar = getattr(getattr(cv2, "data", None), "haarcascades", "")
            if not haar or not os.path.exists(haar):
                haar = os.path.join(os.path.dirname(cv2.__file__), "data")
            for name, fname in self.CASCADES.items():
                if os.path.exists(os.path.join(haar, fname)):
                    self.det[name] = cv2.CascadeClassifier(os.path.join(haar, fname))
            self.hog = cv2.HOGDescriptor()
            self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())
        with suppress(Exception):
            if (ASSETS_DIR / YUNET_MODEL).exists() and hasattr(cv2, "FaceDetectorYN"):
                self.yunet = cv2.FaceDetectorYN.create(str(ASSETS_DIR / YUNET_MODEL), "", (320, 320), 0.7, 0.3, 50)

    def _detect_faces_dnn(self, small_bgr, scale):
        """Лица нейросетью; мелкие «лица» (эмоуты и аватарки в чате, фото на стене) отбрасываются."""
        h, w = small_bgr.shape[:2]
        try:
            self.yunet.setInputSize((w, h))
            _, found = self.yunet.detect(small_bgr)
        except Exception:
            return []
        if found is None or not len(found):
            return []
        boxes = [(int(x / scale), int(y / scale), int(bw / scale), int(bh / scale)) for x, y, bw, bh in found[:, :4]]
        big = max(b[3] for b in boxes)
        return self._dedupe([b for b in boxes if b[3] >= big * 0.45], True)

    @staticmethod
    def _upscale(rects, scale, flip_w=None):
        return [(int((flip_w - x - w if flip_w else x) / scale), int(y / scale), int(w / scale), int(h / scale))
                for (x, y, w, h) in rects]

    @staticmethod
    def _dedupe(boxes, check_y: bool):
        uniq = []
        for b in sorted(boxes, key=lambda b: b[2] * b[3], reverse=True):
            cx, cy = b[0] + b[2] * 0.5, b[1] + b[3] * 0.5
            if not any(abs(cx - (u[0] + u[2] * 0.5)) < u[2] * 0.65 and
                       (not check_y or abs(cy - (u[1] + u[3] * 0.5)) < u[3] * 0.65) for u in uniq):
                uniq.append(b)
        return sorted(uniq, key=lambda b: b[0])

    def _detect_faces(self, g, scale):
        self._ensure_initialized()
        frontal, profile = self.det.get("frontal"), self.det.get("profile")
        if frontal is None:
            return []
        kw = dict(scaleFactor=1.12, minNeighbors=4, minSize=(24, 24))
        try:
            faces = self._upscale(frontal.detectMultiScale(g, **kw), scale)
            if profile is not None:
                faces += self._upscale(profile.detectMultiScale(g, **kw), scale)
                faces += self._upscale(profile.detectMultiScale(cv2.flip(g, 1), **kw), scale, flip_w=g.shape[1])
        except Exception:
            return []
        return self._dedupe(faces, True)

    def _detect_silhouettes(self, g, scale):
        self._ensure_initialized()
        found = []
        with suppress(Exception):
            for name, min_size in (("upperbody", (36, 36)), ("fullbody", (36, 60))):
                det = self.det.get(name)
                if not found and det is not None:
                    found = self._upscale(det.detectMultiScale(g, scaleFactor=1.12, minNeighbors=3, minSize=min_size), scale)
            if not found and self.hog is not None:
                found = self._upscale(self.hog.detectMultiScale(g, winStride=(8, 8), padding=(16, 16), scale=1.08)[0], scale)
        return self._dedupe(found, False)

    @staticmethod
    def _mouth_activity(prev_gray, curr_gray, box) -> float:
        x, y, w, h = box
        H, W = curr_gray.shape[:2]
        mx1, mx2 = max(0, int(x + w * 0.20)), min(W, int(x + w * 0.80))
        my1, my2 = max(0, int(y + h * 0.60)), min(H, int(y + h * 0.96))
        if mx2 - mx1 < 6 or my2 - my1 < 6:
            return 0.0
        return float(np.mean(cv2.absdiff(curr_gray[my1:my2, mx1:mx2], prev_gray[my1:my2, mx1:mx2])))

    @staticmethod
    def _is_partially_in_frame(px, pw, cam_x, crop_w) -> bool:
        if abs(px - cam_x) <= crop_w * 0.44:
            return True
        overlap = min(cam_x + crop_w * 0.5, px + pw * 0.45) - max(cam_x - crop_w * 0.5, px - pw * 0.45)
        return pw > 0 and overlap >= pw * 0.25

    def _analyze_pass(self, cap, fps, total_frames, orig_w, orig_h, crop_w, mirror, cancelled):
        """Проход 1: быстрый последовательный проход (cap.grab без тяжёлых seek), ~5 замеров в секунду."""
        scale = min(1.0, (640.0 if self.yunet is not None else 480.0) / max(1, orig_w))
        step = max(3, int(fps // 5))
        prev_small, last_people, last_src = None, [], "none"
        counts, targets, srcs, mouth_ema = [], {}, {}, {}
        active_slot = slot_hold = 0
        seen_face = False
        self.face_gender = []  # [(сек от начала клипа, p_женского, вес)] — для пола персонажей
        want_gender = FaceGender.available()
        body_gender = want_gender and _onnx_session(MIVOLO_MODEL) is not None and _onnx_session(PERSON_MODEL) is not None
        g_every = max(1, int(round(fps / step)))  # замер пола ~1 раз в секунду (каждый ~5-й замер прохода)

        for f_idx in range(total_frames):
            if cancelled():
                raise Cancelled()
            if f_idx % step:
                if not cap.grab():
                    break
                continue
            ret, frm = cap.read()  # read = grab + retrieve: замер ровно на кадре f_idx (без отставания от видео)
            if not ret or frm is None:
                break
            if mirror:
                frm = cv2.flip(frm, 1)
            small_bgr = cv2.resize(frm, (0, 0), fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
            gray = cv2.cvtColor(frm, cv2.COLOR_BGR2GRAY)
            small = cv2.cvtColor(small_bgr, cv2.COLOR_BGR2GRAY)

            is_cut = prev_small is not None and float(np.mean(cv2.absdiff(small, prev_small))) > 33.0
            if is_cut:
                last_people, last_src, slot_hold = [], "none", 0
                mouth_ema.clear()

            faces = self._detect_faces_dnn(small_bgr, scale) if self.yunet is not None else self._detect_faces(small, scale)
            fresh_faces = bool(faces)
            if faces:
                people, src, seen_face = faces, "face", True
            elif last_people:
                people, src = last_people, last_src  # лицо на миг пропало — держим прежнюю цель
            else:
                people = [] if seen_face else self._detect_silhouettes(small, scale)
                src = "body" if people else "none"
            if people and people is not last_people:
                last_people, last_src = people, src
                counts.append(len(people))

            if people:
                if len(people) == 1:
                    active_slot = 0
                else:
                    best_sl = active_slot if 0 <= active_slot < len(people) else 0
                    best_sc = -1.0
                    if prev_small is not None:
                        prev_full = cv2.resize(prev_small, (orig_w, orig_h))
                        for sl, bx in enumerate(people):
                            sc = mouth_ema.get(sl, 0.0) * 0.65 + self._mouth_activity(prev_full, gray, bx) * 0.35
                            mouth_ema[sl] = sc
                            if sc > best_sc:
                                best_sl, best_sc = sl, sc
                    if slot_hold <= 0:
                        if best_sl != active_slot and best_sc > 1.9:
                            active_slot, slot_hold = best_sl, 3
                    else:
                        slot_hold -= 1
                    active_slot = max(0, min(len(people) - 1, active_slot))
                box = people[active_slot]
                targets[f_idx] = (box[0] + box[2] * 0.5, float(box[2]), is_cut, active_slot)
                g_turn = want_gender and (f_idx // step) % g_every == 0 and len(self.face_gender) < 90
                if fresh_faces and g_turn and prev_small is not None:
                    # пол — у того, на ком камера; вес выше, если у него двигаются губы (говорит именно он):
                    # в кадре может быть слушатель, а голос — за кадром
                    mouth = self._mouth_activity(cv2.resize(prev_small, (orig_w, orig_h)), gray, box)
                    p = FaceGender.p_female(frm, box, people)
                    if p is not None:
                        self.face_gender.append((f_idx / fps, p, float(np.clip(mouth / 2.0, 0.25, 1.0))))
                elif not fresh_faces and g_turn and body_gender:
                    p = FaceGender.p_female(frm, None, [])  # лица не видно (спиной, в профиль) — по фигуре
                    if p is not None:
                        self.face_gender.append((f_idx / fps, p, 0.3))
            else:
                targets[f_idx] = (orig_w * 0.5, crop_w * 0.4, is_cut, 0)
            srcs[f_idx] = src
            prev_small = small

        self._prefer_faces(targets, srcs, orig_w, crop_w)
        if counts:
            max_people = int(np.percentile(counts, 90))
            if max(counts) >= 2 and max_people < 2 and sum(c >= 2 for c in counts) >= 2:
                max_people = 2
            max_people = max(1, min(4, max_people))
        else:
            max_people = 1
        return targets, max_people

    @staticmethod
    def _prefer_faces(targets: dict, srcs: dict, orig_w: int, crop_w: int):
        """В сценах, где есть лица, замеры «по силуэту / без цели» заменяются ближайшим лицом той же сцены
        (сначала предыдущим), а в сценах без лиц при наличии лиц в клипе — центром кадра."""
        idx = sorted(targets)
        if not any(srcs.get(i) == "face" for i in idx):
            return
        scenes, cur = [], []
        for i in idx:
            if targets[i][2] and cur:
                scenes.append(cur)
                cur = []
            cur.append(i)
        if cur:
            scenes.append(cur)
        for sc in scenes:
            face_idx = [i for i in sc if srcs.get(i) == "face"]
            for i in sc:
                if srcs.get(i) == "face":
                    continue
                cut = targets[i][2]
                if face_idx:
                    prev = [j for j in face_idx if j < i]
                    j = prev[-1] if prev else face_idx[0]
                    targets[i] = (targets[j][0], targets[j][1], cut, targets[j][3])
                elif srcs.get(i) == "body":
                    targets[i] = (orig_w * 0.5, crop_w * 0.4, cut, 0)

    def render_clip(self, video_path: Path, start_t: float, duration: float, out_file: Path, num_tracks: int,
                    boost_audio: bool, vertical: bool, use_tracker: bool, mirror_video: bool, enable_female_colors: bool,
                    sub_segments: list, sub_renderer: SubtitleRenderer = None, voice_wav: Path = None,
                    cancel_check=None, register_proc=None, keep_speakers: bool = False, smart_tracking: bool = False,
                    banner: dict = None, layout: str = "", log=None):
        """keep_speakers=True — персонажи берутся из субтитров как есть (ручные правки из редактора не затираются).
        banner = {"file": имя в папке баннеров, "start": сек от начала клипа, "sound": bool} — баннер поверх видео."""
        self._ensure_initialized()
        cancelled = lambda: bool(cancel_check and cancel_check())
        cap = cv2.VideoCapture(str(video_path))
        if not cap.isOpened():
            raise RuntimeError(f"Не удалось открыть видео: {video_path}")

        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        orig_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 1920)
        orig_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 1080)
        if vertical:
            out_w, out_h = 1080, 1920
            crop_w = int(orig_h * 9 / 16)
            crop_w = min(orig_w, max(64, crop_w - crop_w % 2))
        else:
            out_w, out_h = orig_w - orig_w % 2, orig_h - orig_h % 2
            crop_w = out_w
        total_frames = int(duration * fps)

        try:
            cap.set(cv2.CAP_PROP_POS_MSEC, start_t * 1000.0)
            targets, max_people = self._analyze_pass(cap, fps, total_frames, orig_w, orig_h, crop_w, mirror_video, cancelled)
        except BaseException:
            cap.release()
            raise

        if keep_speakers:
            subs = [dict(s) for s in (sub_segments or [])]
            sp_count = max([1] + [int(s.get("speaker_id", 0)) + 1 for s in subs])
            genders = {}
        else:
            subs, sp_count, genders = diarize_segments(sub_segments, voice_wav, max_people, enable_female_colors,
                                                       face_evidence=[(start_t + t, p, w) for t, p, w in
                                                                      getattr(self, "face_gender", [])])
        if sub_renderer is not None and not sub_renderer.speaker_styles:
            sub_renderer.speaker_styles = assign_speaker_colors(sp_count, genders, sub_renderer.default_mode, enable_female_colors)

        # --- ПРОХОД 2: ФИНАЛЬНЫЙ РЕНДЕР С ЧИСТЫМ МОНТАЖНЫМ CUT ---
        cap.set(cv2.CAP_PROP_POS_MSEC, start_t * 1000.0)
        temp_out = out_file.with_name(f".tmp_{int(time.time() * 1000)}_{out_file.name}")
        b_info = probe_banner(banner["file"]) if banner and banner.get("file") else {}
        b_stream, b_f0, b_xy, b_audio = None, 0, (0, 0), None
        if b_info:
            bx, by, bw, bh = banner_box(b_info, out_w, out_h, banner.get("xy"))
            b_start = max(0.0, min(float(banner.get("start") or 0), max(0.0, duration - 0.5)))
            b_stream, b_f0, b_xy = BannerStream(b_info, fps, bw, bh), int(round(b_start * fps)), (bx, by)
            if banner.get("sound", True) and b_info.get("audio"):
                b_audio = (b_info["path"], b_start, min(b_info["dur"], duration - b_start))
        proc = subprocess.Popen(build_ffmpeg_render_cmd(out_w, out_h, fps, start_t, duration, video_path, num_tracks,
                                                        boost_audio, temp_out, banner_audio=b_audio),
                                stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                creationflags=NO_WINDOW_FLAG)
        if register_proc:
            register_proc(proc)

        cam_layout = None
        if vertical:
            if layout == "cam_top":  # CS2 «Стример/Каст»: веб-камера сверху, матч снизу
                self._ensure_initialized()
                cam = find_streamer_cam(video_path, start_t, duration, self.yunet, cancelled)
                if cam:
                    cam_layout = cam_top_crops(cam, orig_w, orig_h, out_w)
                    self.last_cam = cam
                elif log:
                    log("    [!] Веб-камера стримера/каста не найдена — клип отрисован по центру.")
            if not use_tracker:  # трекинг выключен — всегда ровно центр кадра
                cam_path = np.full(max(1, total_frames), orig_w * 0.5, dtype=np.float32)
            elif smart_tracking:
                cam_path = SmartCamera(targets, total_frames, fps, orig_w, crop_w).path()
            else:
                cam_path = legacy_camera_path(targets, total_frames, orig_w, crop_w, use_tracker)
        # Склейка найдена по замерам раз в несколько кадров; точный кадр склейки уточняется при рендере,
        # чтобы камера переключалась ровно на склейке, а не на 1–4 кадра позже (заметный «дёрг»).
        cut_win = {}
        if vertical and use_tracker:
            step = max(3, int(fps // 5))
            for c in (i for i in targets if targets[i][2] and i < total_frames):
                for f in range(max(0, c - step), c):
                    cut_win[f] = c
        cut_state = {"prev": None, "c": None}

        def cam_at(fi, frame):
            if fi in cut_win or cut_state["prev"] is not None:
                tiny = cv2.cvtColor(cv2.resize(frame, (36, 64), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2GRAY)
                prev, cut_state["prev"] = cut_state["prev"], (tiny if fi in cut_win else None)
                c = cut_win.get(fi)
                if c is not None and prev is not None and float(cv2.absdiff(tiny, prev).mean()) > 20.0:
                    cut_state["c"] = c
                if cut_state["c"] is not None and fi < cut_state["c"]:
                    return float(cam_path[cut_state["c"]])
                cut_state["c"] = None
            return float(cam_path[fi])
        finished = False
        # Конвейер из трёх потоков: чтение кадров | кадрирование + субтитры | отправка в кодировщик.
        # OpenCV и запись в ffmpeg отпускают GIL, поэтому этапы реально идут параллельно; кадры те же.
        import queue
        q_in, q_out, stop, errors = queue.Queue(maxsize=6), queue.Queue(maxsize=6), threading.Event(), []

        def _put(q, item):
            while not stop.is_set():
                try:
                    return q.put(item, timeout=0.2)
                except queue.Full:
                    continue

        b_top = bool(banner and banner.get("over_subs"))

        def _banner(fi, frame):
            if b_f0 <= fi < b_f0 + b_stream.n:
                bf = b_stream.next()
                if bf is not None:
                    return blend_bgra(frame, bf, *b_xy)
            elif fi >= b_f0 + b_stream.n:
                b_stream.close()
            return frame

        def _reader():
            try:
                for fi in range(total_frames):
                    if stop.is_set():
                        break
                    ret, frame = cap.read()
                    if not ret or frame is None:
                        break
                    _put(q_in, (fi, frame))
            except Exception as e:
                errors.append(e)
            finally:
                _put(q_in, None)

        def _writer():
            try:
                while True:
                    item = q_out.get()
                    if item is None:
                        break
                    proc.stdin.write(memoryview(item))  # без лишней копии кадра
            except Exception as e:
                if not cancelled():
                    errors.append(e)
                stop.set()

        threads = [threading.Thread(target=_reader, daemon=True), threading.Thread(target=_writer, daemon=True)]
        for th in threads:
            th.start()
        try:
            while not stop.is_set():
                if cancelled():
                    break
                try:
                    item = q_in.get(timeout=0.2)
                except queue.Empty:
                    continue
                if item is None:
                    break
                fi, frame = item
                if mirror_video:
                    frame = cv2.flip(frame, 1)
                abs_time = start_t + fi / fps
                if cam_layout is not None:
                    (cx, cy, cw, ch), (mx, my, mw, mh), hide = cam_layout
                    out_frame = np.empty((out_h, out_w, 3), np.uint8)
                    out_frame[:CAM_TOP_H] = cv2.resize(frame[cy:cy + ch, cx:cx + cw], (out_w, CAM_TOP_H),
                                                       interpolation=cv2.INTER_AREA if cw > out_w else cv2.INTER_LINEAR)
                    match = frame[my:my + mh, mx:mx + mw]
                    if hide is not None:
                        hx, hy, hw, hh = hide
                        match = match.copy()
                        roi = match[hy:hy + hh, hx:hx + hw]
                        small = cv2.resize(roi, (max(1, hw // 16), max(1, hh // 16)), interpolation=cv2.INTER_AREA)
                        match[hy:hy + hh, hx:hx + hw] = cv2.GaussianBlur(cv2.resize(small, (hw, hh)), (0, 0), 6)
                    out_frame[CAM_TOP_H:] = cv2.resize(match, (out_w, out_h - CAM_TOP_H), interpolation=cv2.INTER_LINEAR)
                elif vertical:
                    x1 = max(0, min(orig_w - crop_w, int(round(cam_at(fi, frame) - crop_w * 0.5))))
                    out_frame = cv2.resize(frame[:, x1:x1 + crop_w], (out_w, out_h), interpolation=cv2.INTER_LINEAR)
                else:
                    out_frame = np.ascontiguousarray(frame[:out_h, :out_w])
                if b_stream is not None and not b_top:
                    out_frame = _banner(fi, out_frame)
                if sub_renderer is not None and subs:
                    seg = next((s for s in subs if s["start"] <= abs_time <= s["end"]), None)
                    if seg is not None:
                        out_frame = sub_renderer.draw_subtitle(out_frame, seg, int(seg.get("speaker_id", 0)), abs_time)
                if b_stream is not None and b_top:  # «Поверх субтитров»
                    out_frame = _banner(fi, out_frame)
                _put(q_out, out_frame)
            _put(q_out, None)
            threads[1].join()
            if errors and not cancelled():
                raise errors[0]
            finished = not cancelled()
        finally:
            stop.set()
            for th in threads:
                th.join(timeout=5)
            cap.release()
            if b_stream is not None:
                b_stream.close()
            with suppress(Exception):
                proc.stdin.close()
            proc.wait()  # сначала дожидаемся ffmpeg (иначе Windows не даст удалить файл)
            if not finished:
                with suppress(Exception):
                    temp_out.unlink(missing_ok=True)

        if cancelled():
            raise Cancelled()
        if temp_out.exists():
            shutil.move(str(temp_out), str(out_file))
        return subs, sp_count, genders


# ---------------------------- CS2: «СТРИМЕР/КАСТ» ----------------------------
CAM_TOP_H, CAM_BOTTOM_H = 576, 1344      # 30 / 70: веб-камера сверху, матч снизу (кадр 1080×1920)


def find_streamer_cam(video_path: Path, start_t: float, duration: float, yunet, cancelled=lambda: False):
    """
    Ищет веб-камеру стримера или кастеров поверх игры. Отличие от камер игроков в трансляции:
      • камера стримера/каста почти всё время на одном месте (камеры игроков появляются на секунды);
      • лицо в ней сравнительно небольшое (не студийный план во весь экран);
      • вокруг неё неподвижная рамка — края ищутся по «постоянным» линиям на среднем по времени контуре кадра.
    Возвращает {"rect": (x, y, w, h), "faces": (x, y, w, h)} в пикселях исходника или None.
    """
    if yunet is None:
        return None
    cap = cv2.VideoCapture(str(video_path))
    try:
        W, H = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 0), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 0)
        if not W or not H:
            return None
        n = int(max(8, min(48, duration / 0.6)))
        scale = min(1.0, 960.0 / W)
        sw, sh = int(W * scale), int(H * scale)
        dets, edges_sum, used = [], np.zeros((sh, sw), np.float32), 0
        diff_sum, prev_g, diffs = np.zeros((sh, sw), np.float32), None, 0
        for k in range(n):
            if cancelled():
                return None
            cap.set(cv2.CAP_PROP_POS_MSEC, (start_t + duration * (k + 0.5) / n) * 1000.0)
            ok, fr = cap.read()
            if not ok or fr is None:
                continue
            small = cv2.resize(fr, (sw, sh), interpolation=cv2.INTER_AREA)
            g = cv2.cvtColor(small, cv2.COLOR_BGR2GRAY)
            edges_sum += np.abs(cv2.Sobel(g, cv2.CV_32F, 1, 0, ksize=3)) + np.abs(cv2.Sobel(g, cv2.CV_32F, 0, 1, ksize=3))
            used += 1
            if prev_g is not None:  # насколько меняется картинка: игра — постоянно, комната в веб-камере — мало
                diff_sum += cv2.absdiff(g, prev_g).astype(np.float32)
                diffs += 1
            prev_g = g
            try:
                yunet.setInputSize((sw, sh))
                _, found = yunet.detect(small)
            except Exception:
                found = None
            for f in (found if found is not None else []):
                x, y, w, h, score = float(f[0]), float(f[1]), float(f[2]), float(f[3]), float(f[-1])
                if score >= 0.75 and w >= 10:
                    dets.append((k, x + w / 2, y + h / 2, w, h))
        if used < 4 or not dets:
            return None
        # группы лиц по месту на экране
        groups = []
        for d in dets:
            for gr in groups:
                if abs(d[1] - gr["cx"]) < gr["w"] * 0.8 and abs(d[2] - gr["cy"]) < gr["w"] * 0.8 and abs(d[3] - gr["w"]) < gr["w"] * 0.6:
                    gr["items"].append(d)
                    m = gr["items"]
                    gr["cx"], gr["cy"], gr["w"] = (float(np.median([i[1] for i in m])), float(np.median([i[2] for i in m])),
                                                   float(np.median([i[3] for i in m])))
                    break
            else:
                groups.append({"cx": d[1], "cy": d[2], "w": d[3], "items": [d]})
        keep = []
        for gr in groups:
            presence = len({i[0] for i in gr["items"]}) / used
            if presence >= 0.45 and gr["w"] < sw * 0.20:  # постоянно на месте и не план во весь экран
                gr["h"] = float(np.median([i[4] for i in gr["items"]]))
                gr["presence"] = presence
                keep.append(gr)
        if not keep:
            return None
        best = max(keep, key=lambda g: (g["presence"], g["w"]))
        # соседи в той же камере (два-три кастера в ряд)
        crew = [g for g in keep if abs(g["cy"] - best["cy"]) < best["h"] * 0.7 and abs(g["cx"] - best["cx"]) < best["w"] * 5]
        fx0 = min(g["cx"] - g["w"] / 2 for g in crew)
        fx1 = max(g["cx"] + g["w"] / 2 for g in crew)
        fy0 = min(g["cy"] - g["h"] / 2 for g in crew)
        fy1 = max(g["cy"] + g["h"] / 2 for g in crew)
        fw = best["w"]
        fh_pad = best["h"] * 0.8
        E = edges_sum / used
        on = E > max(float(np.median(E)) * 4.0, float(np.percentile(E, 90)))  # «постоянные» края (рамка камеры)

        def covers(line: np.ndarray, lo: float, hi: float, min_run: float = 0) -> bool:
            """Край тянется вдоль всей полосы лиц и дальше (сплошной отрезок не короче min_run) — это рамка."""
            lo, hi = int(max(0, lo)), int(min(len(line), hi))
            if hi - lo < 4 or float(line[lo:hi].mean()) < 0.85:
                return False
            if min_run <= 0:
                return True
            a = b = (lo + hi) // 2   # сплошной отрезок через середину полосы (с пропусками до 2 px)
            gap = 0
            while a > 0 and gap <= 2:
                a -= 1
                gap = 0 if line[a] else gap + 1
            gap = 0
            while b < len(line) - 1 and gap <= 2:
                b += 1
                gap = 0 if line[b] else gap + 1
            return b - a >= min_run

        Dm = cv2.GaussianBlur(diff_sum / max(1, diffs), (0, 0), 1.2) if diffs else None

        def outside_busier(axis, p, step, lo, hi) -> bool:
            """За рамкой — игра, перед ней — веб-камера: по разные стороны картинка меняется по-разному.
            Линия внутри камеры (дверь, шкаф) так не выглядит: по обе стороны одно и то же."""
            if Dm is None:
                return True
            lo, hi, w = int(max(0, lo)), int(hi), 8
            if axis == "x":
                out = Dm[lo:hi, max(0, p + step * 3):max(0, p + step * 3) + w] if step > 0 else Dm[lo:hi, max(0, p - 3 - w):max(0, p - 3)]
                inn = Dm[lo:hi, max(0, p - 3 - w):max(0, p - 3)] if step > 0 else Dm[lo:hi, p + 3:p + 3 + w]
            else:
                out = Dm[max(0, p + step * 3):max(0, p + step * 3) + w, lo:hi] if step > 0 else Dm[max(0, p - 3 - w):max(0, p - 3), lo:hi]
                inn = Dm[max(0, p - 3 - w):max(0, p - 3), lo:hi] if step > 0 else Dm[p + 3:p + 3 + w, lo:hi]
            if out.size == 0:
                return True   # дальше край кадра
            if inn.size == 0:
                return False
            a, b = float(out.mean()) + 0.3, float(inn.mean()) + 0.3
            return max(a, b) / min(a, b) > 1.6   # по разные стороны линии картинка меняется по-разному

        def line_at(axis, lo, hi, start, stop, step):
            """Ближайшая к лицам длинная неподвижная линия (±1 px), за которой начинается игра."""
            for p in range(int(start), int(stop), step):
                if not (0 <= p < (sw if axis == "x" else sh)):
                    return None
                strip = on[:, max(0, p - 1):p + 2].any(axis=1) if axis == "x" else on[max(0, p - 1):p + 2, :].any(axis=0)
                if covers(strip, lo, hi, run_min[axis]) and outside_busier(axis, p, step, lo, hi):
                    return p
            return None
        # рамка длиннее контура головы: вертикальные края идут и над лицом, и далеко ниже (плечи), горизонтальные —
        # шире лиц с обеих сторон
        span_y = (fy0 - fh_pad * 0.6, fy1 + fh_pad * 0.6)
        span_x = (fx0 - fw * 0.8, fx1 + fw * 0.8)
        run_min = {"x": best["h"] * 3.2, "y": (fx1 - fx0) + fw * 3.0}  # рамка намного длиннее контура головы
        reach = max(fw * 8, sw * 0.35)  # камера бывает намного шире лица
        left = line_at("x", *span_y, fx0 - fw * 1.0, fx0 - reach, -1)
        right = line_at("x", *span_y, fx1 + fw * 1.0, fx1 + reach, 1)
        top = line_at("y", *span_x, fy0 - best["h"] * 0.3, fy0 - reach, -1)
        bottom = line_at("y", *span_x, fy1 + best["h"] * 0.15, fy1 + reach, 1)
        # Главный способ: веб-камера — «спокойная» область вокруг лиц посреди постоянно меняющейся игры.
        # Берём связную спокойную область, в которой лица, и уточняем её края по рамке.
        calm = None
        if diffs >= 3:
            D = cv2.GaussianBlur(diff_sum / diffs, (0, 0), 1.2)
            thr = max(4.0, float(np.percentile(D, 50)) * 0.5)
            mask = (D < thr).astype(np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((int(max(3, fw * 0.8)),) * 2, np.uint8))
            num, lab, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
            cxs, cys = int(min(sw - 1, (fx0 + fx1) / 2)), int(min(sh - 1, (fy0 + fy1) / 2))
            comp = lab[cys, cxs]
            if comp > 0:
                bx, by, bw_, bh_, area = stats[comp]
                if (bw_ * bh_ < sw * sh * 0.5 and bx <= fx0 and by <= fy0 and bx + bw_ >= fx1 and by + bh_ >= fy1
                        and 0.6 <= bw_ / max(1, bh_) <= 3.5):
                    calm = [bx, by, bx + bw_, by + bh_]

        def snap(axis, p, lo, hi):
            """Подтянуть край к рамке рядом (±6 px), если она есть."""
            for d in sorted(range(-6, 7), key=abs):
                q = p + d
                if 0 <= q < (sw if axis == "x" else sh):
                    strip = on[:, max(0, q - 1):q + 2].any(axis=1) if axis == "x" else on[max(0, q - 1):q + 2, :].any(axis=0)
                    if covers(strip, lo, hi):
                        return q
            return p
        if calm is not None:
            x0, y0, x1, y1 = calm
            x0, x1 = snap("x", x0, y0, y1), snap("x", x1, y0, y1)
            y0, y1 = snap("y", y0, x0, x1), snap("y", y1, x0, x1)
            left, top, right, bottom = x0, y0, x1, y1
        # сама линия рамки в кадр не попадает
        left = None if left is None else left + 2
        top = None if top is None else top + 2
        right = None if right is None else right - 1
        bottom = None if bottom is None else bottom - 1
        # чего не нашли — по пропорциям обычной веб-камеры 16:9 вокруг лиц, до края кадра
        cx, cy = (fx0 + fx1) / 2, (fy0 + fy1) / 2
        half_w = max(fx1 - fx0, fw) / 2 + fw * 1.6
        x0 = left if left is not None else max(0.0, cx - half_w)
        x1 = right if right is not None else min(float(sw), cx + half_w)
        if left is None and x0 <= fw * 0.5:
            x0 = 0.0
        if right is None and x1 >= sw - fw * 0.5:
            x1 = float(sw)
        h_guess = (x1 - x0) * 9 / 16
        y0 = top if top is not None else max(0.0, cy - h_guess * 0.45)
        y1 = bottom if bottom is not None else min(float(sh), y0 + h_guess)
        rect = tuple(int(round(v / scale)) for v in (x0, y0, x1 - x0, y1 - y0))
        faces = tuple(int(round(v / scale)) for v in (fx0, fy0, fx1 - fx0, fy1 - fy0))
        if rect[2] < 32 or rect[3] < 32:
            return None
        return {"rect": rect, "faces": faces}
    finally:
        cap.release()


def cam_top_crops(cam: dict, W: int, H: int, out_w: int = 1080) -> tuple:
    """Кадрирование для раскладки 30/70: (камера x, y, w, h), (матч x, y, w, h) в пикселях исходника."""
    rx, ry, rw, rh = cam["rect"]
    fx, fy, fw, fh = cam["faces"]
    k = out_w / CAM_TOP_H  # 1.875
    if rw / max(1, rh) > k:          # камера шире — берём всю высоту, по ширине — вокруг лиц
        ch, cw = rh, int(rh * k)
        cx = min(max(fx + fw / 2 - cw / 2, rx), rx + rw - cw)
        cy = ry
    else:                             # выше — вся ширина, по высоте лица чуть выше центра
        cw, ch = rw, int(rw / k)
        cx = rx
        cy = min(max(fy + fh * 0.5 - ch * 0.42, ry), ry + rh - ch)
    mk = out_w / CAM_BOTTOM_H        # матч — центр кадра (прицел и перестрелка)
    mw = min(W, int(H * mk))
    mh = min(H, int(mw / mk))
    mx, my = (W - mw) // 2, (H - mh) // 2
    # веб-камера попадает и в нижнюю часть (например, кастеры сверху по центру) — там её размываем, чтобы не было двух
    ox0, oy0 = max(rx, mx), max(ry, my)
    ox1, oy1 = min(rx + rw, mx + mw), min(ry + rh, my + mh)
    hide = (ox0 - mx, oy0 - my, ox1 - ox0, oy1 - oy0) if ox1 - ox0 > 8 and oy1 - oy0 > 8 else None
    return (int(cx), int(cy), max(2, int(cw)), max(2, int(ch))), (mx, my, mw, mh), hide


# ---------------------------- ТРАЕКТОРИЯ КАМЕРЫ 9:16 ----------------------------
def legacy_camera_path(targets: dict, total_frames: int, orig_w: int, crop_w: int, use_tracker: bool) -> np.ndarray:
    """«Трекинг»: статичные планы; камера перескакивает (cut) на сцене, смене говорящего вне кадра
    или когда человек ушёл из кадра и остановился."""
    lo, hi = crop_w * 0.5, orig_w - crop_w * 0.5
    first = targets.get(0, (orig_w * 0.5, crop_w * 0.4, False, 0))
    cam = max(lo, min(hi, first[0]))
    path = np.empty(max(1, total_frames), dtype=np.float32)
    cur_slot, prev_tx, stationary = first[3], first[0], 0
    for fi in range(total_frames):
        if use_tracker and fi in targets:
            tx, tw, is_cut, t_slot = targets[fi]
            ctx_x = max(lo, min(hi, tx))
            stationary = stationary + 1 if abs(tx - prev_tx) < orig_w * 0.018 else 0
            prev_tx = tx
            if is_cut:
                cam, cur_slot, stationary = ctx_x, t_slot, 0
            elif t_slot != cur_slot:
                if not ActiveSpeakerTracker._is_partially_in_frame(ctx_x, tw, cam, crop_w):
                    cam = ctx_x
                cur_slot = t_slot
            elif not ActiveSpeakerTracker._is_partially_in_frame(ctx_x, tw, cam, crop_w) and stationary >= 2:
                cam, stationary = ctx_x, 0
        path[fi] = cam
    return path


class SmartCamera:
    """
    «Умный трекинг»: путь камеры планируется заранее для всего клипа (будущее уже известно после анализа),
    как это делает оператор, а не «догоняющий» трекер:
      • мёртвая зона — камера стоит, пока лицо (или оба собеседника) помещается в кадр с полями;
        покачивания, повороты головы и переключения между говорящими рядом камеру не двигают;
      • коротких планов нет: отклонение короче ~1.6 с камера пропускает — человек скоро вернётся;
      • если человек ушёл — плавный переезд (smootherstep: мягкий старт и мягкая остановка);
        переезды в одну сторону сливаются в один непрерывный проезд, без «стоп-старт»;
      • быстрое движение или скорая смена ракурса — монтажный cut вместо панорамы.
    """
    MIN_SHOT = 1.6        # с — минимальная длительность статичного плана
    MARGIN = 0.08         # доля кадра — поля вокруг лица
    MIN_MOVE = 0.10       # доля кадра — меньшие сдвиги не делаются вовсе
    PAN_SPEED = 0.45      # доля кадра в секунду — средняя скорость переезда
    PAN_MIN, PAN_MAX = 0.7, 1.8   # с — длительность переезда
    FAST = 0.75           # доля кадра в секунду — цель движется слишком быстро → cut
    CUT_SOON = 1.0        # с — до смены ракурса меньше этого → cut
    CHAIN_GAP = 2.0       # с — паузы короче этого между переездами в одну сторону сливаются
    MEDIAN = 3            # замеров в каждую сторону (~0.6 с) — сглаживание выбросов детектора

    def __init__(self, targets: dict, total_frames: int, fps: float, orig_w: int, crop_w: int):
        self.t, self.n, self.fps, self.W, self.cw = targets, max(1, total_frames), fps, orig_w, crop_w
        self.lo, self.hi = crop_w * 0.5, orig_w - crop_w * 0.5

    @staticmethod
    def smootherstep(u):
        u = np.clip(u, 0.0, 1.0)
        return u * u * u * (u * (u * 6 - 15) + 10)

    def _fit(self, w):
        """Насколько может разойтись цель внутри одного плана, оставаясь целиком в кадре с полями."""
        return max(self.cw * 0.2, self.cw * (1 - 2 * self.MARGIN) - w * 1.1)

    def _shots(self, frames, xs, ws, scene_end):
        n = len(frames)
        shots, i = [], 0
        while i < n:  # жадно: план тянется, пока все положения цели помещаются в кадр
            j, mn, mx, mw = i, xs[i], xs[i], ws[i]
            while j + 1 < n:
                nmn, nmx, nmw = min(mn, xs[j + 1]), max(mx, xs[j + 1]), max(mw, ws[j + 1])
                if nmx - nmn > self._fit(nmw):
                    break
                mn, mx, mw, j = nmn, nmx, nmw, j + 1
            shots.append([i, j, mn, mx])
            i = j + 1

        def dur(k):
            end = frames[shots[k + 1][0]] if k + 1 < len(shots) else scene_end
            return (end - frames[shots[k][0]]) / self.fps

        def center(s):
            return (s[2] + s[3]) / 2

        while len(shots) > 1:  # короткие отклонения поглощаются соседним планом
            k = min(range(len(shots)), key=dur)
            if dur(k) >= self.MIN_SHOT:
                break
            if k == 0:
                nb = 1
            elif k == len(shots) - 1:
                nb = k - 1
            else:
                nb = k - 1 if abs(center(shots[k - 1]) - center(shots[k])) <= abs(center(shots[k + 1]) - center(shots[k])) else k + 1
            a, b = sorted((k, nb))
            keep = shots[b] if nb > k else shots[a]  # положение длинного соседа сохраняется
            shots[a:b + 1] = [[shots[a][0], shots[b][1], keep[2], keep[3]]]
        out = []
        for s in shots:
            pos = float(np.clip(center(s), self.lo, self.hi))
            if out and abs(pos - out[-1][2]) < self.cw * self.MIN_MOVE:
                out[-1][1] = s[1]  # почти тот же ракурс — не двигаемся
            else:
                out.append([s[0], s[1], pos])
        return out

    def path(self) -> np.ndarray:
        idx = sorted(i for i in self.t if i < self.n)
        if not idx:
            return np.full(self.n, np.clip(self.W * 0.5, self.lo, self.hi), dtype=np.float32)
        path = np.empty(self.n, dtype=np.float32)
        scenes, cur = [], []
        for i in idx:  # сцены — только между монтажными склейками; смена говорящего решается кадрированием
            if cur and self.t[i][2]:
                scenes.append(cur)
                cur = []
            cur.append(i)
        scenes.append(cur)
        pans, m = [], self.MEDIAN
        for si, sc in enumerate(scenes):
            frames = np.array(sc)
            raw = np.array([self.t[i][0] for i in sc], dtype=np.float64)
            ws = np.array([self.t[i][1] for i in sc], dtype=np.float64)
            xs = np.array([np.median(raw[max(0, k - m):k + m + 1]) for k in range(len(raw))])
            start = 0 if si == 0 else sc[0]
            end = scenes[si + 1][0] if si + 1 < len(scenes) else self.n
            shots = self._shots(frames, xs, ws, end)
            for k, (a, b, pos) in enumerate(shots):
                f0 = start if k == 0 else int(frames[a])
                f1 = end if k == len(shots) - 1 else int(frames[shots[k + 1][0]])
                path[f0:f1] = pos
                if k == 0:
                    continue
                prev, fb = shots[k - 1][2], int(frames[a])
                d = float(np.clip(abs(pos - prev) / (self.cw * self.PAN_SPEED), self.PAN_MIN, self.PAN_MAX))
                lo_i, hi_i = max(0, a - 2), min(len(frames) - 1, a + 2)
                speed = abs(xs[hi_i] - xs[lo_i]) / max(1e-3, (frames[hi_i] - frames[lo_i]) / self.fps)
                room = min(fb - (start if k == 1 else int(frames[shots[k - 1][0]])), f1 - fb) / self.fps
                cut_soon = si + 1 < len(scenes) and (end - fb) / self.fps < self.CUT_SOON + d / 2  # конец клипа — не склейка
                if speed > self.cw * self.FAST or cut_soon or room < d / 2:
                    continue  # монтажный cut: камера просто встаёт в новую точку
                pans.append((fb, d, prev, pos))
        spans = []
        for fb, d, a, b in pans:
            half = int(round(d * self.fps / 2))
            f0, f1 = max(0, fb - half), min(self.n, fb + half)
            if spans and (b - a) * (spans[-1][3] - spans[-1][2]) > 0 and f0 - spans[-1][1] < self.fps * self.CHAIN_GAP:
                spans[-1][1], spans[-1][3] = f1, b
            else:
                spans.append([f0, f1, a, b])
        for f0, f1, a, b in spans:
            if f1 - f0 >= 2:
                u = (np.arange(f0, f1) - f0) / (f1 - f0 - 1)
                path[f0:f1] = a + (b - a) * self.smootherstep(u)
        return np.clip(path, self.lo, self.hi).astype(np.float32)


# ---------------------------- GOOGLE DRIVE ----------------------------
# Отдельный от YouTube/TikTok вход: свой токен, временный профиль браузера, ничего общего с аккаунтами загрузки.
# Права drive.file — программа видит и меняет ТОЛЬКО файлы и папки, которые создала сама.
GOOGLE_CLIENT_FILE = DATA_ROOT / "google_client.json"   # OAuth-клиент «Desktop app» из Google Cloud Console
GDRIVE_AUTH_FILE = DATA_ROOT / "gdrive_auth.json"
GDRIVE_AVATAR_FILE = DATA_ROOT / "gdrive_avatar.png"
CLOUD_CACHE_DIR = DATA_ROOT / "cloud_cache"             # рабочие копии клипов при облачном хранении
GDRIVE_SCOPES = "openid email profile https://www.googleapis.com/auth/drive.file"
GDRIVE_FOLDER_MIME = "application/vnd.google-apps.folder"


class DriveError(RuntimeError):
    def __init__(self, msg, status=0):
        super().__init__(msg)
        self.status = status


class GoogleDrive:
    API = "https://www.googleapis.com/drive/v3/files"
    UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"
    TOKEN_URL = "https://oauth2.googleapis.com/token"
    CHUNK = 8 * 1024 * 1024  # кратно 256 КиБ, как требует Drive

    def __init__(self):
        auth = read_json(GDRIVE_AUTH_FILE, {})
        self.auth = auth if isinstance(auth, dict) else {}
        self._lock = threading.Lock()
        self._folders = {}

    # --- состояние ---
    @property
    def connected(self) -> bool:
        return bool(self.auth.get("refresh_token"))

    @property
    def user(self) -> dict:
        return self.auth.get("user", {})

    @staticmethod
    def has_client() -> bool:
        return bool(GoogleDrive._client())

    @staticmethod
    def _client() -> dict:
        d = read_json(GOOGLE_CLIENT_FILE, {})
        c = (d.get("installed") or d.get("web") or d) if isinstance(d, dict) else {}
        return c if c.get("client_id") and c.get("client_secret") else {}

    @staticmethod
    def import_client(path: str):
        d = read_json(Path(path), None)
        c = (d.get("installed") or d.get("web") or d) if isinstance(d, dict) else {}
        if not (c.get("client_id") and c.get("client_secret")):
            raise ValueError("В файле нет client_id / client_secret. Нужен JSON OAuth-клиента типа «Desktop app».")
        write_json(GOOGLE_CLIENT_FILE, {"installed": {"client_id": c["client_id"], "client_secret": c["client_secret"]}})

    # --- вход / выход ---
    def login(self, timeout_sec: int = 360, profile_dir: Path = None) -> dict:
        """Окно браузера со входом Google → локальный redirect с кодом → токены. Блокирующий вызов (в потоке)."""
        import base64, secrets, tempfile, webbrowser
        import requests
        from http.server import BaseHTTPRequestHandler, HTTPServer
        from urllib.parse import urlencode, urlparse, parse_qs
        client = self._client()
        if not client:
            raise DriveError("Не настроен OAuth-клиент Google (файл google_client.json).")
        verifier = secrets.token_urlsafe(64)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
        state, result = secrets.token_urlsafe(16), {}

        class _Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                q = {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}
                if q.get("state") == state:
                    result.update(q)
                body = ("<html><body style='background:#141218;color:#E6E0E9;font-family:Segoe UI;text-align:center;"
                        "padding-top:80px'><h2>Готово! Окно можно закрыть.</h2><script>window.close()</script></body></html>")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(body.encode("utf-8"))

            def log_message(self, *a):
                pass

        server = HTTPServer(("127.0.0.1", 0), _Handler)
        server.timeout = 0.5
        redirect = f"http://127.0.0.1:{server.server_port}/"
        url = "https://accounts.google.com/o/oauth2/v2/auth?" + urlencode({
            "client_id": client["client_id"], "redirect_uri": redirect, "response_type": "code", "scope": GDRIVE_SCOPES,
            "code_challenge": challenge, "code_challenge_method": "S256", "state": state,
            "access_type": "offline", "prompt": "consent select_account"})
        stop = threading.Event()

        def _serve():
            while not stop.is_set() and not result:
                server.handle_request()
        threading.Thread(target=_serve, daemon=True).start()

        deadline = time.time() + timeout_sec
        profile = str(profile_dir) if profile_dir else tempfile.mkdtemp(prefix="gdrive_login_")
        try:
            try:
                from playwright.sync_api import sync_playwright
                with sync_playwright() as p:
                    ctx = launch_browser_context(p, profile, headless=False, width=520, height=680)
                    page = ctx.pages[0] if ctx.pages else ctx.new_page()
                    page.goto(url)
                    while not result and time.time() < deadline and not page.is_closed():
                        page.wait_for_timeout(400)
                    with suppress(Exception):
                        ctx.close()
            except Exception:
                webbrowser.open(url)  # запасной вариант — обычный браузер (вкладку закроет страница «Готово»)
                while not result and time.time() < deadline:
                    time.sleep(0.4)
        finally:
            stop.set()
            with suppress(Exception):
                server.server_close()
            if not profile_dir:
                shutil.rmtree(profile, ignore_errors=True)

        if "code" not in result:
            raise DriveError("Вход отменён." if "error" not in result else f"Google отклонил вход: {result['error']}")
        tok = requests.post(self.TOKEN_URL, timeout=20, data={
            "code": result["code"], "client_id": client["client_id"], "client_secret": client["client_secret"],
            "redirect_uri": redirect, "code_verifier": verifier, "grant_type": "authorization_code"}).json()
        if "refresh_token" not in tok:
            raise DriveError(f"Не удалось получить токен: {tok.get('error_description') or tok.get('error') or tok}")
        info = requests.get("https://openidconnect.googleapis.com/v1/userinfo", timeout=15,
                            headers={"Authorization": f"Bearer {tok['access_token']}"}).json()
        avatar = ""
        with suppress(Exception):
            r = requests.get(info["picture"], timeout=10)
            Image.open(BytesIO(r.content)).convert("RGBA").save(GDRIVE_AVATAR_FILE)
            avatar = str(GDRIVE_AVATAR_FILE)
        self.auth = {"refresh_token": tok["refresh_token"], "access_token": tok["access_token"],
                     "expires_at": time.time() + float(tok.get("expires_in", 3600)),
                     "user": {"name": info.get("name") or info.get("email", "Google"), "email": info.get("email", ""),
                              "avatar": avatar}}
        self._folders.clear()
        write_json(GDRIVE_AUTH_FILE, self.auth)
        return self.user

    def logout(self):
        token = self.auth.get("refresh_token")
        self.auth, self._folders = {}, {}
        for f in (GDRIVE_AUTH_FILE, GDRIVE_AVATAR_FILE):
            with suppress(Exception):
                f.unlink(missing_ok=True)
        if token:  # отзыв доступа у Google — в фоне, результат не важен
            def _revoke():
                import requests
                with suppress(Exception):
                    requests.post("https://oauth2.googleapis.com/revoke", data={"token": token}, timeout=10)
            run_bg(_revoke)

    # --- HTTP ---
    def _access_token(self) -> str:
        import requests
        with self._lock:
            if not self.connected:
                raise DriveError("Google Drive не подключён.")
            if time.time() < float(self.auth.get("expires_at", 0)) - 60:
                return self.auth["access_token"]
            c = self._client()
            r = requests.post(self.TOKEN_URL, timeout=20, data={
                "client_id": c.get("client_id"), "client_secret": c.get("client_secret"),
                "refresh_token": self.auth["refresh_token"], "grant_type": "refresh_token"})
            d = r.json()
            if "access_token" not in d:
                raise DriveError(f"Сессия Google Drive истекла — подключите аккаунт заново ({d.get('error', r.status_code)}).", 401)
            self.auth.update(access_token=d["access_token"], expires_at=time.time() + float(d.get("expires_in", 3600)))
            write_json(GDRIVE_AUTH_FILE, self.auth)
            return d["access_token"]

    def _req(self, method: str, url: str, ok=(200, 201, 204), **kw):
        import requests
        for attempt in range(2):
            headers = {**kw.pop("headers", {}), "Authorization": f"Bearer {self._access_token()}"}
            r = requests.request(method, url, headers=headers, timeout=kw.pop("timeout", 30), **kw)
            if r.status_code == 401 and attempt == 0:
                self.auth["expires_at"] = 0
                kw["headers"] = {k: v for k, v in headers.items() if k != "Authorization"}
                continue
            if r.status_code not in ok:
                with suppress(Exception):
                    msg = r.json()["error"]["message"]
                    raise DriveError(f"Google Drive: {msg}", r.status_code)
                raise DriveError(f"Google Drive: ошибка HTTP {r.status_code}", r.status_code)
            return r

    # --- папки и файлы ---
    @staticmethod
    def normalize_folder(path: str) -> str:
        return "/".join(p.strip() for p in str(path or "").replace("\\", "/").split("/") if p.strip()) or "Клипы"

    def ensure_folder(self, path: str) -> str:
        """id папки по пути вида «Клипы/Shorts» (от корня «Мой диск»); недостающие папки создаются."""
        path = self.normalize_folder(path)
        if path in self._folders:
            return self._folders[path]
        parent = "root"
        for part in path.split("/"):
            esc = part.replace("\\", "\\\\").replace("'", "\\'")
            q = f"name = '{esc}' and mimeType = '{GDRIVE_FOLDER_MIME}' and '{parent}' in parents and trashed = false"
            found = self._req("GET", self.API, params={"q": q, "fields": "files(id)", "pageSize": 1}).json().get("files", [])
            parent = found[0]["id"] if found else self._req(
                "POST", self.API, params={"fields": "id"}, json={"name": part, "mimeType": GDRIVE_FOLDER_MIME, "parents": [parent]}).json()["id"]
        self._folders[path] = parent
        return parent

    def upload(self, local: Path, name: str = None, folder: str = "Клипы", file_id: str = None, progress=None, cancelled=None) -> dict:
        """Возобновляемая загрузка по частям. file_id — заменить содержимое существующего файла (перерендер)."""
        import requests
        size = local.stat().st_size
        hdr = {"X-Upload-Content-Type": "video/mp4", "X-Upload-Content-Length": str(size)}
        params = {"uploadType": "resumable", "fields": "id,webViewLink"}
        try:
            if file_id:
                r = self._req("PATCH", f"{self.UPLOAD}/{file_id}", params=params, json={}, headers=hdr)
            else:
                r = self._req("POST", self.UPLOAD, params=params, headers=hdr,
                              json={"name": name or local.name, "parents": [self.ensure_folder(folder)]})
        except DriveError as e:
            if e.status == 404 and not file_id:  # папку удалили вручную — создаём заново
                self._folders.clear()
                r = self._req("POST", self.UPLOAD, params=params, headers=hdr,
                              json={"name": name or local.name, "parents": [self.ensure_folder(folder)]})
            else:
                raise
        session, pos, fails = r.headers["Location"], 0, 0
        with open(local, "rb") as f:
            while True:
                if cancelled and cancelled():
                    raise Cancelled()
                f.seek(pos)
                data = f.read(self.CHUNK)
                try:
                    resp = requests.put(session, data=data, timeout=120,
                                        headers={"Content-Range": f"bytes {pos}-{pos + len(data) - 1}/{size}"})
                except requests.RequestException:
                    fails += 1
                    if fails > 4:
                        raise
                    time.sleep(2 * fails)
                    resp = requests.put(session, headers={"Content-Range": f"bytes */{size}"}, timeout=30)
                if resp.status_code in (200, 201):
                    if progress:
                        progress(1.0)
                    d = resp.json()
                    return {"id": d["id"], "link": d.get("webViewLink", f"https://drive.google.com/file/d/{d['id']}/view")}
                if resp.status_code != 308:
                    raise DriveError(f"Google Drive: загрузка прервана (HTTP {resp.status_code})", resp.status_code)
                rng = resp.headers.get("Range")
                pos = int(rng.rsplit("-", 1)[1]) + 1 if rng else 0
                if progress:
                    progress(pos / max(1, size))

    def rename(self, file_id: str, name: str):
        self._req("PATCH", f"{self.API}/{file_id}", params={"fields": "id"}, json={"name": name})

    def trash(self, file_id: str) -> bool:
        """В корзину Google Drive (восстановима 30 дней). False — файла уже нет."""
        try:
            self._req("PATCH", f"{self.API}/{file_id}", params={"fields": "id"}, json={"trashed": True})
            return True
        except DriveError as e:
            if e.status == 404:
                return False
            raise


def circle_avatar(path: str, size: int) -> Image.Image:
    base = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, size - 1, size - 1), fill=255)
    try:
        base.paste(Image.open(path).convert("RGBA").resize((size, size), Image.Resampling.LANCZOS), (0, 0), mask)
    except Exception:
        ImageDraw.Draw(base).ellipse((0, 0, size - 1, size - 1), fill=(74, 68, 88, 255))
    return base


@lru_cache(maxsize=4)
def make_logout_icon(size: int = 20, color=(242, 84, 84, 255)) -> Image.Image:
    """Красная «дверь со стрелкой» (рисуется в 4× и уменьшается — края гладкие)."""
    s = size * 4
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    w = max(2, s // 11)
    d.rounded_rectangle((s * 0.10, s * 0.08, s * 0.56, s * 0.92), radius=s * 0.06, outline=color, width=w)
    d.rectangle((s * 0.50, s * 0.38, s * 0.62, s * 0.62), fill=(0, 0, 0, 0))   # проём для стрелки
    d.line((s * 0.30, s * 0.50, s * 0.80, s * 0.50), fill=color, width=w)
    d.polygon([(s * 0.96, s * 0.50), (s * 0.74, s * 0.33), (s * 0.74, s * 0.67)], fill=color)
    return im.resize((size, size), Image.Resampling.LANCZOS)


# ---------------------------- ОБНОВЛЕНИЯ «ПО ВОЗДУХУ» (GITHUB RELEASES) ----------------------------
# В каждом выпуске на GitHub лежит manifest.json: версия, «отпечаток» библиотек (runtime), список изменений
# и два пакета: patch — только код программы (сотни КБ), full — программа целиком без моделей (нужен, если
# изменились библиотеки). Программа берёт patch, если её runtime совпадает с новым, иначе full.
UPDATE_REPO = "Quiltonn/clips-studio"           # «владелец/репозиторий» — подставляет сборщик
UPDATE_FIRST_CHECK_MS = 10_000
UPDATE_INTERVAL_MS = 15 * 60_000
UPDATES_DIR = DATA_ROOT / "updates"


def parse_version(v) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:4]) or (0,)


def fmt_mb(n: float) -> str:
    return f"{n / 1048576:.1f} МБ" if n >= 1048576 else f"{max(1, round(n / 1024))} КБ"


class Updater:
    STATES = ("idle", "downloading", "paused", "ready", "installing", "error")

    def __init__(self, notify):
        self.notify = notify                      # notify() — вызывается (из любого потока) при смене состояния/прогресса
        self.runtime = read_json(INSTALL_DIR / "runtime.json", {}).get("runtime", "") if INSTALL_DIR else ""
        self.manifest = None
        self.state, self.error, self.done, self.total, self.speed = "idle", "", 0, 0, 0.0
        self.checking = False
        self.last_check = None                    # None | "latest" | "available" | "error"
        self._resume, self._cancel = threading.Event(), threading.Event()
        self._thread = None
        self.zip_path = None

    # --- состояние ---
    @property
    def enabled(self) -> bool:
        return bool(INSTALL_DIR and self.runtime and re.fullmatch(r"[\w.-]+/[\w.-]+", UPDATE_REPO))

    @property
    def disabled_reason(self) -> str:
        if not INSTALL_DIR or not self.runtime:
            return "Обновления работают в установленной программе"
        return "Сервер обновлений не настроен в этой сборке"

    @property
    def available(self) -> bool:
        return bool(self.manifest) and parse_version(self.manifest.get("version")) > parse_version(APP_VERSION)

    @property
    def new_version(self) -> str:
        return str((self.manifest or {}).get("version", ""))

    @property
    def package(self) -> dict:
        """Какой пакет скачивать: маленький patch (тот же набор библиотек) или full."""
        m = self.manifest or {}
        kind = "patch" if m.get("runtime") == self.runtime and m.get("patch") else "full"
        return {"kind": kind, **(m.get(kind) or {})}

    def changelog(self) -> list:
        entries = [e for e in (self.manifest or {}).get("changelog", []) if isinstance(e, dict)]
        return sorted(entries, key=lambda e: parse_version(e.get("version")), reverse=True)

    def _emit(self):
        with suppress(Exception):
            self.notify()

    # --- проверка ---
    def check(self) -> bool:
        """Блокирующий запрос manifest.json последнего выпуска. True — есть новая версия."""
        import requests
        if not self.enabled or self.checking:
            return self.available
        self.checking = True
        try:
            r = requests.get(f"https://github.com/{UPDATE_REPO}/releases/latest/download/manifest.json", timeout=15)
            if r.status_code == 404:
                self.manifest = None  # выпусков ещё нет
            else:
                r.raise_for_status()
                m = r.json()
                if self.state in ("idle", "error") or m.get("version") == self.new_version:
                    self.manifest = m
            self.last_check = "available" if self.available else "latest"
        except Exception as e:
            self.last_check, self.error = "error", f"Не удалось проверить обновления: {e}"
        finally:
            self.checking = False
            self._emit()
        return self.available

    # --- скачивание: пауза / продолжить / прервать ---
    def start(self):
        if not self.available or self.state in ("downloading", "paused", "ready", "installing"):
            return
        pkg = self.package
        if not pkg.get("url") or not pkg.get("sha256"):
            self.state, self.error = "error", "В выпуске нет пакета обновления."
            return self._emit()
        UPDATES_DIR.mkdir(parents=True, exist_ok=True)
        self.zip_path = UPDATES_DIR / f"ClipsStudio-{self.new_version}-{pkg['kind']}.zip"
        part = self.zip_path.with_suffix(".part")
        self.total = int(pkg.get("size") or 0)
        self.done = part.stat().st_size if part.exists() else 0  # докачка после перезапуска программы
        self.state, self.error, self.speed = "downloading", "", 0.0
        if self._thread and self._thread.is_alive():  # дождаться остановки прерванной загрузки
            self._thread.join(timeout=5)
        self._cancel, self._resume = threading.Event(), threading.Event()  # свои флаги у каждой загрузки
        self._resume.set()
        self._thread = threading.Thread(target=self._download, args=(pkg, part, self._cancel, self._resume), daemon=True)
        self._thread.start()
        self._emit()

    def pause(self):
        if self.state == "downloading":
            self._resume.clear()
            self.state = "paused"
            self._emit()

    def resume(self):
        if self.state == "paused":
            self.state = "downloading"
            self._resume.set()
            self._emit()

    def abort(self):
        """Прервать без вопросов: загрузка останавливается, частично скачанный файл удаляется."""
        if self.state in ("downloading", "paused", "ready", "error"):
            self._cancel.set()
            self._resume.set()
            if self.state != "downloading" or not (self._thread and self._thread.is_alive()):
                self._cleanup()
            self.state, self.done, self.speed, self.error = "idle", 0, 0.0, ""
            self._emit()

    def _cleanup(self):
        for p in (self.zip_path, self.zip_path.with_suffix(".part") if self.zip_path else None):
            if p:
                with suppress(Exception):
                    p.unlink(missing_ok=True)

    def _download(self, pkg: dict, part: Path, cancel: threading.Event, resume: threading.Event):
        import requests
        fails, last_emit, t0, d0 = 0, 0.0, time.time(), self.done
        while not cancel.is_set():
            resume.wait()
            if cancel.is_set():
                break
            try:
                have = part.stat().st_size if part.exists() else 0
                hdr = {"Range": f"bytes={have}-"} if have else {}
                with requests.get(pkg["url"], headers=hdr, stream=True, timeout=(15, 60)) as r:
                    if r.status_code == 416:  # уже скачано целиком
                        break
                    r.raise_for_status()
                    mode = "ab" if have and r.status_code == 206 else "wb"
                    self.done = have if mode == "ab" else 0
                    self.total = self.total or self.done + int(r.headers.get("Content-Length", 0))
                    with open(part, mode) as f:
                        for chunk in r.iter_content(256 * 1024):
                            if cancel.is_set() or not resume.is_set():
                                break
                            f.write(chunk)
                            self.done += len(chunk)
                            now = time.time()
                            if now - last_emit > 0.15:
                                self.speed = (self.done - d0) / max(0.001, now - t0)
                                last_emit = now
                                self._emit()
                if cancel.is_set():
                    break
                if not resume.is_set():  # пауза: соединение закрыто, ждём «Продолжить»
                    t0, d0 = time.time(), self.done
                    continue
                break
            except Exception as e:
                fails += 1
                if cancel.is_set():
                    break
                if fails > 5:
                    self.state, self.error = "error", f"Загрузка не удалась: {e}"
                    return self._emit()
                time.sleep(min(10, 2 * fails))
        if cancel.is_set():
            with suppress(Exception):
                part.unlink(missing_ok=True)
            return
        try:
            h = hashlib.sha256()
            with open(part, "rb") as f:
                for block in iter(lambda: f.read(1 << 20), b""):
                    h.update(block)
            if h.hexdigest().lower() != str(pkg["sha256"]).lower():
                part.unlink(missing_ok=True)
                raise RuntimeError("файл повреждён при загрузке (не совпала контрольная сумма) — скачайте ещё раз")
            part.replace(self.zip_path)
            self.state, self.speed = "ready", 0.0
        except Exception as e:
            self.state, self.error = "error", f"Ошибка проверки обновления: {e}"
        self._emit()

    # --- установка ---
    def install(self):
        """Ставит скачанный пакет и перезапускает программу. Код (patch) меняется сразу; полный пакет
        копирует отдельный помощник после закрытия программы. Предыдущий код сохраняется в app_prev."""
        import zipfile
        if self.state != "ready" or not INSTALL_DIR:
            return
        self.state = "installing"
        self._emit()
        exe = Path(sys.executable)
        try:
            if self.package["kind"] == "patch":
                new, cur, prev = INSTALL_DIR / "app_new", INSTALL_DIR / "app", INSTALL_DIR / "app_prev"
                shutil.rmtree(new, ignore_errors=True)
                with zipfile.ZipFile(self.zip_path) as z:
                    for m in z.namelist():
                        if m.startswith("app/") and not m.endswith("/"):
                            (new / m[4:]).parent.mkdir(parents=True, exist_ok=True)
                            (new / m[4:]).write_bytes(z.read(m))
                compile((new / "app.py").read_text(encoding="utf-8"), "app.py", "exec")  # битый код не ставим
                shutil.rmtree(prev, ignore_errors=True)
                if cur.exists():
                    cur.rename(prev)
                new.rename(cur)
                self.zip_path.unlink(missing_ok=True)
                subprocess.Popen([str(exe)], cwd=str(INSTALL_DIR), creationflags=getattr(subprocess, "DETACHED_PROCESS", 0))
            else:
                staging = UPDATES_DIR / "staging"
                shutil.rmtree(staging, ignore_errors=True)
                with zipfile.ZipFile(self.zip_path) as z:
                    z.extractall(staging)
                if not (staging / exe.name).exists():
                    raise RuntimeError("в пакете нет файла программы")
                helper = UPDATES_DIR / "apply_update.ps1"
                helper.write_text(
                    "param([int]$ProcId, [string]$Src, [string]$Dst, [string]$Exe, [string]$Zip)\n"
                    "Wait-Process -Id $ProcId -Timeout 90 -ErrorAction SilentlyContinue\n"
                    "Start-Sleep -Milliseconds 700\n"
                    "robocopy $Src $Dst /MIR /XD models app_prev banners /R:5 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null\n"
                    "if ($LASTEXITCODE -lt 8) { Remove-Item $Src -Recurse -Force -ErrorAction SilentlyContinue; "
                    "Remove-Item $Zip -Force -ErrorAction SilentlyContinue }\n"
                    "Start-Process -FilePath $Exe -WorkingDirectory $Dst\n", encoding="utf-8-sig")
                subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
                                  "-File", str(helper), "-ProcId", str(os.getpid()), "-Src", str(staging),
                                  "-Dst", str(INSTALL_DIR), "-Exe", str(exe), "-Zip", str(self.zip_path)],
                                 creationflags=NO_WINDOW_FLAG)
            return True
        except Exception as e:
            self.state, self.error = "error", f"Не удалось установить обновление: {e}"
            self._emit()
            return False


# ---------------------------- UI-ХЕЛПЕРЫ ----------------------------
def F(size=12, bold=False):
    return ("Segoe UI", size, "bold") if bold else ("Segoe UI", size)


BTN_STYLES = {
    "primary": dict(fg_color=MD3["primary"], hover_color=MD3["primary_hover"], text_color=MD3["on_primary"]),
    "secondary": dict(fg_color=MD3["secondary_container"], hover_color=MD3["surface_highest"], text_color=MD3["on_secondary"]),
    "surface": dict(fg_color=MD3["surface_high"], hover_color=MD3["surface_highest"], text_color=MD3["on_surface"],
                    border_width=1, border_color=MD3["outline"]),
    "ghost": dict(fg_color="transparent", hover_color=MD3["surface_highest"], text_color=MD3["on_surface"]),
    "danger": dict(fg_color=MD3["error_container"], hover_color="#A8241E", text_color="#FFDAD6"),
    "success": dict(fg_color=MD3["success_container"], hover_color="#284D3E", text_color=MD3["on_success"]),
}
DISABLED_BTN = dict(state="disabled", fg_color=MD3["surface_highest"], text_color=MD3["on_surface_var"])


def button(parent, text, command=None, style="secondary", **kw):
    return ctk.CTkButton(parent, text=text, command=command, **{**BTN_STYLES[style], **kw})


def card(parent, **kw):
    return ctk.CTkFrame(parent, **{"fg_color": MD3["surface_container"], "corner_radius": 16, "border_width": 1,
                                   "border_color": MD3["outline"], **kw})


def label(parent, text="", font=None, color="on_surface", **kw):
    if font is not None:
        kw["font"] = font
    return ctk.CTkLabel(parent, text=text, text_color=MD3.get(color, color), **kw)


class Tooltip:
    """Одна всплывающая подсказка на всё приложение (над курсором)."""
    win, key = None, None

    @classmethod
    def show(cls, widget, text: str, x_root: int, y_root: int, key=None):
        if cls.win is not None and cls.key == key and key is not None:
            with suppress(Exception):
                cls.win.geometry(f"+{x_root - cls.win.winfo_width() // 2}+{y_root - cls.win.winfo_height() - 14}")
            return
        cls.hide()
        tip = tk.Toplevel(widget)
        tip.overrideredirect(True)
        with suppress(Exception):
            tip.attributes("-topmost", True)
        tk.Label(tip, text=text, bg="#33363d", fg="#ffffff", font=("Segoe UI", 10), padx=8, pady=4, bd=0,
                 justify="left", wraplength=360).pack()
        tip.update_idletasks()
        tip.geometry(f"+{x_root - tip.winfo_width() // 2}+{y_root - tip.winfo_height() - 14}")
        cls.win, cls.key = tip, key

    @classmethod
    def hide(cls):
        if cls.win is not None:
            with suppress(Exception):
                cls.win.destroy()
        cls.win, cls.key = None, None


def entry(parent, **kw):
    return ctk.CTkEntry(parent, **{"fg_color": MD3["surface_high"], "border_color": MD3["outline"],
                                   "text_color": MD3["on_surface"], "corner_radius": 10, **kw})


def checkbox(parent, text, variable, command=None, font=None):
    kw = {"font": font} if font else {}
    return ctk.CTkCheckBox(parent, text=text, variable=variable, command=command, fg_color=MD3["primary"],
                           checkmark_color=MD3["on_primary"], **kw)


def combo(parent, values, value, width=None, **kw):
    kw = {"fg_color": MD3["surface_high"], "border_color": MD3["outline"], "button_color": MD3["secondary_container"], **kw}
    if width:
        kw["width"] = width
    c = ctk.CTkComboBox(parent, values=values, **kw)
    c.set(value)
    return c


def slider(parent, lo, hi, value, width, command):
    s = ctk.CTkSlider(parent, from_=lo, to=hi, number_of_steps=hi - lo, width=width, button_color=MD3["primary"],
                      progress_color=MD3["primary"], command=command)
    s.set(value)
    return s


def ctk_image(pil_img, size):
    return ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=size)


def ask_yes_no(parent, title: str, message: str) -> bool:
    """Модальное окно-предупреждение в стиле программы с кнопками «Да» / «Нет»."""
    result = {"yes": False}
    dlg = ctk.CTkToplevel(parent)
    dlg.title(title)
    dlg.configure(fg_color=MD3["bg"])
    dlg.resizable(False, False)
    dlg.transient(parent)
    body = card(dlg)
    body.pack(fill="both", expand=True, padx=12, pady=12)
    label(body, "⚠", font=F(34, True), color="tertiary").pack(pady=(14, 0))
    label(body, message, font=F(13), wraplength=430, justify="center").pack(padx=22, pady=(4, 16))
    row = ctk.CTkFrame(body, fg_color="transparent")
    row.pack(pady=(0, 18))

    def _close(val):
        result["yes"] = val
        with suppress(Exception):
            dlg.grab_release()
        dlg.destroy()

    style = dict(width=140, height=38, corner_radius=19, font=F(13, True))
    button(row, "Да", lambda: _close(True), "danger", **style).pack(side="left", padx=8)
    no_btn = button(row, "Нет", lambda: _close(False), "primary", **style)
    no_btn.pack(side="left", padx=8)
    dlg.protocol("WM_DELETE_WINDOW", lambda: _close(False))
    dlg.bind("<Escape>", lambda _e: _close(False))
    dlg.update_idletasks()
    w, h = dlg.winfo_reqwidth(), dlg.winfo_reqheight()
    x = parent.winfo_rootx() + (parent.winfo_width() - w) // 2
    y = parent.winfo_rooty() + (parent.winfo_height() - h) // 3
    dlg.geometry(f"+{max(0, x)}+{max(0, y)}")
    dlg.lift()
    dlg.attributes("-topmost", True)
    with suppress(Exception):
        dlg.wait_visibility()
        dlg.grab_set()
    no_btn.focus_set()
    parent.wait_window(dlg)
    return result["yes"]


def monitor_work_area(widget, x: int, y: int) -> tuple:
    """Рабочая область монитора под точкой (x, y) в тех же пикселях, что и координаты мыши.
    winfo_screenwidth при масштабе Windows 125–150% возвращает уменьшенный размер — из-за этого меню
    «упиралось» в несуществующий край и открывалось посередине экрана."""
    if sys.platform == "win32":
        with suppress(Exception):
            import ctypes
            from ctypes import wintypes

            class _MonInfo(ctypes.Structure):
                _fields_ = [("cbSize", wintypes.DWORD), ("rcMonitor", wintypes.RECT), ("rcWork", wintypes.RECT),
                            ("dwFlags", wintypes.DWORD)]
            u32 = ctypes.windll.user32
            u32.MonitorFromPoint.restype = ctypes.c_void_p
            u32.MonitorFromPoint.argtypes = [wintypes.POINT, wintypes.DWORD]
            mon = u32.MonitorFromPoint(wintypes.POINT(int(x), int(y)), 2)  # MONITOR_DEFAULTTONEAREST
            info = _MonInfo()
            info.cbSize = ctypes.sizeof(_MonInfo)
            if mon and u32.GetMonitorInfoW(ctypes.c_void_p(mon), ctypes.byref(info)):
                r = info.rcWork
                return r.left, r.top, r.right, r.bottom
    return 0, 0, widget.winfo_screenwidth(), widget.winfo_screenheight()


class Popover:
    """
    Всплывающее меню в стиле MD3: скруглённые углы (прозрачный фон окна), крупные пункты. Одно на всё приложение.
    Закрывается: кликом мимо (обработчики на всех виджетах и на главном окне), потерей фокуса, Esc,
    перемещением окна, повторным нажатием кнопки-якоря.
    """
    KEY = "#010203"           # цвет-«ключ» прозрачности (почти чёрный — без светлой каймы на тёмной теме)
    DANGER = "#FF8A80"
    OPEN_GUARD = 0.3          # сек: клик, который открыл меню, не должен тут же его закрыть
    current = None
    last_closed = (None, 0.0)  # (якорь, время) — чтобы повторное нажатие кнопки не открывало меню заново

    def __init__(self, app, anchor=None, width=270, parent=None):
        if parent is None:
            Popover.close_current()
        self.app, self.anchor, self.width, self.items, self.buttons = app, anchor, width, [], []
        self._pos, self.created = None, time.time()
        self.parent, self.child = parent, None   # parent — вложенное меню (раскрывается справа от пункта)
        self.win = tk.Toplevel(app)
        self.win.overrideredirect(True)
        self.win.geometry("+-20000+-20000")   # строится за экраном и сразу переносится на место (без withdraw:
        self.win.configure(bg=self.KEY)        # у скрытого окна без рамки Windows игнорирует позицию)
        with suppress(Exception):
            self.win.attributes("-transparentcolor", self.KEY)
        with suppress(Exception):
            self.win.attributes("-topmost", True)
        frame = ctk.CTkFrame(self.win, fg_color=MD3["surface_high"], bg_color=self.KEY, corner_radius=16,
                             border_width=1, border_color=MD3["outline"])
        frame.pack()
        self.body = ctk.CTkFrame(frame, fg_color="transparent")
        self.body.pack(padx=6, pady=6)
        self.win.bind("<Escape>", lambda _e: self.root.close())
        if parent is None:
            self.win.bind("<FocusOut>", lambda _e: self.app.after(80, self._check_focus))
            Popover.current = self
        else:
            if parent.child is not None:
                parent.child.close()
            parent.child = self

    @property
    def root(self):
        return self.parent.root if self.parent else self

    def wins(self):
        return [self.win] + (self.child.wins() if self.child else [])

    # --- содержимое ---
    def item(self, text, command, color=None, enabled=True, keep_open=False, image=None, parent=None, indent=0):
        b = button(parent or self.body, text, None, "ghost", anchor="w", width=self.width - 12 - indent, height=35,
                   corner_radius=10, font=F(12), text_color=color or MD3["on_surface"],
                   hover_color="#4A1F1F" if color == self.DANGER else MD3["surface_highest"],
                   **({"image": image, "compound": "left"} if image else {}))

        def _run():
            if not keep_open:
                self.root.close()
            if command:
                command()
        b.configure(command=_run)
        if not enabled:
            b.configure(state="disabled")
        b.pack(fill="x", pady=1, padx=(indent, 0))
        self.items.append(text)
        self.buttons.append(b)
        return b

    def caption(self, text, parent=None):
        label(parent or self.body, text, F(11, True), "on_surface_var", anchor="w").pack(fill="x", padx=12, pady=(6, 2))
        self.items.append(text)

    def separator(self, parent=None):
        ctk.CTkFrame(parent or self.body, height=1, fg_color=MD3["outline"]).pack(fill="x", padx=8, pady=6)

    # --- показ ---
    def show(self, x, y):
        self._pos = (x, y)
        self.reflow()
        self.win.lift()
        if self.parent is None:  # вложенное меню фокус не забирает — иначе главное меню закроется
            with suppress(Exception):
                self.win.focus_force()
        self.app.after(30, self.reflow)  # повторно — если Windows сдвинул окно при первом показе

    def show_beside(self, item):
        """Справа от пункта главного меню (или слева, если справа не хватает экрана)."""
        self.win.update_idletasks()
        w = self.win.winfo_reqwidth()
        x = item.winfo_rootx() + item.winfo_width() + 14
        if x + w > monitor_work_area(self.win, item.winfo_rootx(), item.winfo_rooty())[2] - 4:
            x = self.parent.win.winfo_rootx() - w - 6
        self.show(x, item.winfo_rooty() - 10)

    def show_under(self, anchor, align="right"):
        self.win.update_idletasks()
        w = self.win.winfo_reqwidth()
        x = anchor.winfo_rootx() + (anchor.winfo_width() - w if align == "right" else 0)
        self.show(x, anchor.winfo_rooty() + anchor.winfo_height() + 6)

    def reflow(self):
        """Пересчитать размер (например, после раскрытия «Удалить») и не дать меню выйти за экран."""
        if not self._pos or Popover.current is not self.root:
            return
        with suppress(Exception):
            self.win.update_idletasks()
            w, h = self.win.winfo_reqwidth(), self.win.winfo_reqheight()
            left, top, right, bottom = monitor_work_area(self.win, *self._pos)
            x = max(left + 4, min(int(self._pos[0]), right - w - 4))
            y = max(top + 4, min(int(self._pos[1]), bottom - h - 8))
            self.win.geometry(f"{w}x{h}+{x}+{y}")

    def close(self):
        if self.child is not None:
            self.child.close()
        if self.parent is not None and self.parent.child is self:
            self.parent.child = None
        with suppress(Exception):
            self.win.destroy()
        if Popover.current is self:
            Popover.current = None
            Popover.last_closed = (self.anchor, time.time())

    def _check_focus(self):
        if Popover.current is not self or time.time() - self.created < self.OPEN_GUARD:
            return
        with suppress(Exception):
            f = self.app.focus_get()
            if f is not None and f.winfo_toplevel() in self.wins():
                return
        self.close()

    @classmethod
    def close_current(cls):
        if cls.current is not None:
            cls.current.close()

    @classmethod
    def is_open_for(cls, anchor) -> bool:
        return cls.current is not None and cls.current.anchor is anchor

    @classmethod
    def just_closed_by(cls, anchor) -> bool:
        """Меню этой кнопки закрылось только что (нажатием на неё же) — не открывать его снова."""
        return anchor is not None and cls.last_closed[0] is anchor and time.time() - cls.last_closed[1] < 0.35

    @classmethod
    def on_global_click(cls, event):
        p = cls.current
        if p is None or time.time() - p.created < cls.OPEN_GUARD:
            return
        w = event.widget
        with suppress(Exception):
            if w.winfo_toplevel() in p.wins():
                return
        with suppress(Exception):
            if any(str(w) == str(x) or str(w).startswith(str(x) + ".") for x in p.wins()):
                return
        p.close()


# ---------------------------- ВСПЛЫВАЮЩИЕ ОКНА ПОВЕРХ ИНТЕРФЕЙСА ----------------------------
class Overlay:
    """
    Окно по центру поверх размытого интерфейса: крестик справа вверху, закрытие кликом мимо окна или Esc.
    Наследники задают TITLE и метод build(body); render() перестраивает содержимое.
    """
    WIDTH, TITLE, SCROLL_HEIGHT = 540, "", 0

    def __init__(self, app):
        self.app = app
        self.backdrop = self.panel = self.body = None
        self._photo = self._resize_job = None
        self._refs = []

    @property
    def is_open(self) -> bool:
        return self.panel is not None

    def open(self):
        if self.is_open:
            return
        for other in getattr(self.app, "overlays", ()):  # одновременно открыто только одно окно
            if other is not self:
                other.close()
        self._show_backdrop()
        self.panel = card(self.app, corner_radius=20, border_color=MD3["secondary_container"])
        self.panel.place(relx=0.5, rely=0.5, anchor="center")
        head = ctk.CTkFrame(self.panel, fg_color="transparent")
        head.pack(fill="x", padx=(22, 12), pady=(14, 4))
        label(head, self.TITLE, F(18, True)).pack(side="left")
        button(head, "✕", self.close, "ghost", width=34, height=34, corner_radius=17, font=F(15, True)).pack(side="right")
        ctk.CTkFrame(self.panel, fg_color="transparent", width=self.WIDTH, height=1).pack()  # фиксирует ширину окна
        if self.SCROLL_HEIGHT:
            h = max(260, min(self.SCROLL_HEIGHT, int(self.app.winfo_height() / max(0.5, self.app._get_window_scaling())) - 200))
            self.body = ctk.CTkScrollableFrame(self.panel, fg_color="transparent", height=h, width=self.WIDTH - 20)
        else:
            self.body = ctk.CTkFrame(self.panel, fg_color="transparent")
        self.body.pack(fill="both", expand=True, padx=22 if not self.SCROLL_HEIGHT else (14, 8), pady=(0, 22))
        self.build_footer(self.panel)
        self.app.bind("<Escape>", lambda _e: self.close(), add="+")
        self.render()

    def close(self):
        for w in (self.panel, self.backdrop):
            if w is not None:
                with suppress(Exception):
                    w.destroy()
        self.panel = self.backdrop = self.body = None
        self._photo = None
        self.on_close()
        with suppress(Exception):
            self.app.unbind("<Escape>")

    def render(self):
        if not self.is_open:
            return
        for w in self.body.winfo_children():
            w.destroy()
        self._refs.clear()
        self.build(self.body)

    # для наследников
    def build(self, body):
        pass

    def build_footer(self, panel):
        pass

    def on_close(self):
        pass

    # --- размытый фон ---
    def _blurred_screenshot(self):
        try:
            from PIL import ImageGrab, ImageFilter, ImageEnhance, ImageTk
            a = self.app
            a.update_idletasks()
            x, y, w, h = a.winfo_rootx(), a.winfo_rooty(), a.winfo_width(), a.winfo_height()
            img = ImageGrab.grab(bbox=(x, y, x + w, y + h), all_screens=True).convert("RGB")
            small = img.resize((max(1, w // 3), max(1, h // 3)), Image.Resampling.BILINEAR).filter(ImageFilter.GaussianBlur(2))
            self._photo = ImageTk.PhotoImage(ImageEnhance.Brightness(small.resize((w, h), Image.Resampling.BILINEAR)).enhance(0.72))
            return self._photo
        except Exception:
            return None  # нет снимка — просто затемнённый фон

    def _show_backdrop(self):
        photo = self._blurred_screenshot()
        if self.backdrop is None:
            self.backdrop = tk.Label(self.app, bd=0, highlightthickness=0, bg="#0d0c10")
            self.backdrop.bind("<Button-1>", lambda _e: self.close())
        self.backdrop.configure(image=photo or "")
        self.backdrop.place(x=0, y=0, relwidth=1, relheight=1)

    def on_resize(self):
        if self.is_open:
            if self._resize_job:
                self.app.after_cancel(self._resize_job)
            self._resize_job = self.app.after(250, self._reblur)

    def _reblur(self):
        self._resize_job = None
        if not self.is_open:
            return
        self.backdrop.place_forget()
        self.panel.place_forget()
        self.app.update()
        self._show_backdrop()
        self.panel.place(relx=0.5, rely=0.5, anchor="center")

    @staticmethod
    def _title(parent, text, top=10):
        label(parent, text, F(14, True), "primary", anchor="w").pack(fill="x", pady=(top, 6))


# ---------------------------- ОБХОД БЛОКИРОВОК YOUTUBE ----------------------------
# ByeDPI (hufrea/byedpi, MIT) — локальный SOCKS-прокси, который меняет разбиение и порядок пакетов при подключении,
# чтобы фильтр провайдера не узнал адрес YouTube. Без драйверов и прав администратора, работает только для
# скачивания в этой программе. Включается, только если YouTube напрямую не открывается; подходящий способ
# подбирается автоматически и запоминается.
BYEDPI_EXE = DATA_ROOT / "tools" / "ciadpi.exe"
PROXY_HINT = ("Если у VPN-клиента включён локальный прокси — укажите его адрес: тогда через VPN пойдёт только "
              "скачивание в программе. Прокси используется для всех ссылок вместо обхода блокировок.")
BYEDPI_SHA256 = "eb53ceeeb981cc6735ac24bb1e51e725280b86630e80fdf19ddc4ee4a5b54ef4"   # ByeDPI 0.17.3, x86_64
BYEDPI_URLS = ("https://raw.githubusercontent.com/Quiltonn/clips-studio/claude/models/tools/byedpi/ciadpi.exe",
               "https://github.com/Quiltonn/clips-studio/raw/claude/models/tools/byedpi/ciadpi.exe")
BYEDPI_STRATEGIES = (
    "--split 1 --disorder 3+s --mod-http=h,d --auto=torst --tlsrec 1+s",
    "--split 1+s --disorder 3+s",
    "--disorder 1 --fake -1 --auto=torst --tlsrec 1+s",
    "--fake -1 --ttl 8 --auto=torst --tlsrec 1+s",
    "--oob 3+s --tlsrec 1+s",
    "--disoob 3+s --split 1+s --tlsrec 3+s",
    "--disorder 1 --fake -1 --fake-sni www.google.com --tlsrec 1+s",
    "--split 2 --disorder 1 --tlsrec 3+s --auto=torst",
)
YT_PROBE_HOSTS = ("www.youtube.com", "redirector.googlevideo.com")
YT_HOST_RE = re.compile(r"^https?://([^/]*\.)?(youtube\.com|youtu\.be|youtube-nocookie\.com)(/|$)", re.IGNORECASE)


def tls_probe(host: str, socks: tuple = None, timeout: float = 6.0) -> bool:
    """Открывается ли https://host (напрямую или через SOCKS5): рукопожатие TLS и ответ сервера."""
    import socket
    import ssl
    sock = None
    try:
        if socks:
            sock = socket.create_connection(socks, timeout=timeout)
            sock.sendall(b"\x05\x01\x00")
            if sock.recv(2) != b"\x05\x00":
                return False
            hb = host.encode()
            sock.sendall(b"\x05\x01\x00\x03" + bytes([len(hb)]) + hb + (443).to_bytes(2, "big"))
            rep_ = sock.recv(4)
            if len(rep_) < 4 or rep_[1] != 0:
                return False
            sock.recv({1: 4, 4: 16}.get(rep_[3], 0) + 2 if rep_[3] != 3 else sock.recv(1)[0] + 2)
        else:
            sock = socket.create_connection((host, 443), timeout=timeout)
        ctx = ssl.create_default_context()
        tls = ctx.wrap_socket(sock, server_hostname=host)
        sock = tls
        tls.sendall(f"HEAD / HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n\r\n".encode())
        return tls.recv(16).startswith(b"HTTP/")
    except Exception:
        return False
    finally:
        if sock is not None:
            with suppress(Exception):
                sock.close()


class YouTubeBypass:
    """Подбирает доступ к YouTube для yt-dlp: свой прокси пользователя → напрямую → ByeDPI."""

    def __init__(self, app):
        self.app, self.proc, self.port = app, None, None

    def _log(self, msg):
        with suppress(Exception):
            self.app.log(msg)

    def ensure_binary(self) -> bool:
        def ok():
            with suppress(Exception):
                return hashlib.sha256(BYEDPI_EXE.read_bytes()).hexdigest() == BYEDPI_SHA256
            return False
        if BYEDPI_EXE.exists() and ok():
            return True
        import requests
        BYEDPI_EXE.parent.mkdir(parents=True, exist_ok=True)
        for url in BYEDPI_URLS:
            with suppress(Exception):
                r = requests.get(url, timeout=60)
                if r.ok and hashlib.sha256(r.content).hexdigest() == BYEDPI_SHA256:
                    BYEDPI_EXE.write_bytes(r.content)
                    return True
        return False

    def _start(self, args: str) -> bool:
        import socket
        self.stop()
        with socket.socket() as s_:
            s_.bind(("127.0.0.1", 0))
            self.port = s_.getsockname()[1]
        try:
            self.proc = subprocess.Popen([str(BYEDPI_EXE), "-i", "127.0.0.1", "-p", str(self.port), *args.split()],
                                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW_FLAG)
        except OSError:
            self.proc = None
            return False
        for _ in range(30):  # ждём, пока прокси начнёт принимать подключения (до 3 с)
            if self.proc.poll() is not None:
                return False
            with suppress(OSError), socket.create_connection(("127.0.0.1", self.port), timeout=0.3):
                return True
            time.sleep(0.1)
        return False

    def stop(self):
        if self.proc is not None:
            with suppress(Exception):
                self.proc.kill()
                self.proc.wait(timeout=3)
        self.proc = None

    def proxy_for(self, url: str, cancelled=lambda: False):
        """Адрес прокси для yt-dlp (или None — напрямую)."""
        cfg = self.app.config_data
        own = (cfg.get("proxy") or "").strip()
        if own:
            self._log(f" -> Скачивание через прокси из настроек: {own}")
            return own
        if not cfg.get("yt_bypass", True) or not YT_HOST_RE.match(url or ""):
            return None
        if all(tls_probe(h) for h in YT_PROBE_HOSTS):
            return None
        self._log(" -> YouTube напрямую не открывается — включаю обход блокировок...")
        if not self.ensure_binary():
            self._log(" [!] Не удалось скачать модуль обхода (ByeDPI). Пробую напрямую.")
            return None
        saved = cfg.get("yt_bypass_strategy")
        order = ([saved] if saved in BYEDPI_STRATEGIES else []) + [x for x in BYEDPI_STRATEGIES if x != saved]
        for n, args in enumerate(order, 1):
            if cancelled():
                raise Cancelled()
            if self._start(args) and all(tls_probe(h, ("127.0.0.1", self.port), 8.0) for h in YT_PROBE_HOSTS):
                self._log(f" -> Обход блокировок работает (способ {BYEDPI_STRATEGIES.index(args) + 1}).")
                if saved != args:
                    cfg["yt_bypass_strategy"] = args
                    with suppress(Exception):
                        self.app.save_config()
                return f"socks5://127.0.0.1:{self.port}"
            self.stop()
            self._log(f"   способ {n} из {len(order)} не подошёл...")
        self._log(" [!] Обойти блокировку не получилось — попробуйте VPN или укажите прокси в Настройках → «Сеть».")
        return None


# ---------------------------- ОКНО НАСТРОЕК ----------------------------
class SettingsOverlay(Overlay):
    """Настройки. Новый раздел = метод self._section_<имя>(parent) + его имя в SECTIONS."""
    TITLE = "Настройки"
    SCROLL_HEIGHT = 640
    SECTIONS = ("ai", "gdrive", "storage", "performance", "network", "analysis", "updates")

    def __init__(self, app):
        super().__init__(app)
        self.login_busy = self.editing_folder = False

    def on_close(self):
        self.editing_folder = False

    def build(self, body):
        self.sections = {}
        for name in self.SECTIONS:
            holder = ctk.CTkFrame(body, fg_color="transparent")
            holder.pack(fill="x")
            self.sections[name] = holder
            getattr(self, f"_section_{name}")(holder)

    def render_section(self, *names):
        """Перестроить только нужные разделы — остальное окно не мигает."""
        if not self.is_open:
            return
        for name in names:
            holder = self.sections.get(name)
            if holder is None:
                continue
            for w in holder.winfo_children():
                w.destroy()
            getattr(self, f"_section_{name}")(holder)

    def build_footer(self, panel):
        label(panel, f"v{APP_VERSION}", F(11), "outline").place(relx=1.0, rely=1.0, x=-16, y=-8, anchor="se")

    def _section_ai(self, parent):
        app = self.app
        self._title(parent, "Нейросеть", top=4)
        pill = dict(height=32, corner_radius=16)
        cap = lambda text, top=8: label(parent, text, F(12), "on_surface_var", anchor="w").pack(fill="x", pady=(top, 3))
        cap("API ключ", top=0)
        holder = ctk.CTkFrame(parent, fg_color="transparent", height=34)
        holder.pack(fill="x")
        key = entry(holder, textvariable=app.api_key_var, show="•", height=34, placeholder_text="Вставьте ваш ключ sk-...")
        key.pack(fill="x")
        eye_imgs = [ctk_image(make_eye_icon(40), (20, 20)), ctk_image(make_eye_icon(40, crossed=True), (20, 20))]
        self._refs.extend(eye_imgs)
        eye = ctk.CTkButton(holder, text="", image=eye_imgs[0], width=28, height=28, corner_radius=14,
                            fg_color=MD3["surface_high"], hover_color=MD3["surface_highest"], bg_color=MD3["surface_high"])

        def toggle_eye():
            hidden = key.cget("show") != ""
            key.configure(show="" if hidden else "•")
            eye.configure(image=eye_imgs[1 if hidden else 0])
        eye.configure(command=toggle_eye)
        eye.place(relx=1.0, rely=0.5, x=-5, anchor="e")  # внутри поля, справа
        r = ctk.CTkFrame(parent, fg_color="transparent")
        r.pack(fill="x", pady=(8, 0))
        button(r, app.tokens_balance_var.get(), lambda: app.refresh_token_balance_async(silent=False, allow_browser=True),
               "success", textvariable=app.tokens_balance_var, font=F(12, True), **pill).pack(fill="x")
        cap("Сервер (Base URL)")
        entry(parent, textvariable=app.base_url_var, height=34).pack(fill="x")
        cap("Модель ИИ")
        r = ctk.CTkFrame(parent, fg_color="transparent")
        r.pack(fill="x")
        button(r, "Проверить ключ", app.test_api, "primary", width=140, font=F(12, True), **pill).pack(side="right")
        combo(r, TOKIFY_MODELS, app.model_var.get(), variable=app.model_var, corner_radius=10, height=32).pack(
            side="left", fill="x", expand=True, padx=(0, 8))

    def _section_gdrive(self, parent):
        self._title(parent, "Интеграция с Google Drive", top=16)
        row = ctk.CTkFrame(parent, fg_color=MD3["surface_high"], corner_radius=14)
        row.pack(fill="x")
        drive = self.app.drive
        if drive.connected:
            u = drive.user
            av = ctk_image(circle_avatar(u.get("avatar", ""), 72), (36, 36))
            self._refs.append(av)
            ctk.CTkLabel(row, text="", image=av).pack(side="left", padx=(12, 10), pady=10)
            names = ctk.CTkFrame(row, fg_color="transparent")
            names.pack(side="left", fill="x", expand=True)
            label(names, u.get("name", "Google"), F(13, True), anchor="w").pack(fill="x")
            if u.get("email"):
                label(names, u["email"], F(11), "on_surface_var", anchor="w").pack(fill="x")
            door = ctk_image(make_logout_icon(40), (20, 20))
            self._refs.append(door)
            button(row, "", self._logout, "ghost", image=door, width=36, height=36, corner_radius=10,
                   hover_color="#4A1F1F").pack(side="right", padx=10)
        else:
            text = "Ожидание входа в окне браузера..." if self.login_busy else "Подключить аккаунт"
            b = button(row, text, self._connect, "primary", height=36, corner_radius=18, font=F(13, True))
            if self.login_busy:
                b.configure(state="disabled")
            b.pack(side="left", padx=12, pady=12)
            label(row, "Отдельный аккаунт — не связан с YouTube", F(11), "on_surface_var").pack(side="left", padx=(4, 12))

    def _radio(self, parent, text, value, enabled=True):
        rb = ctk.CTkRadioButton(parent, text=text, value=value, variable=self.mode_var, command=self._on_mode,
                                font=F(13, True), fg_color=MD3["primary"], hover_color=MD3["primary_hover"],
                                border_color=MD3["on_surface_var"], text_color=MD3["on_surface"],
                                text_color_disabled=MD3["outline"], state="normal" if enabled else "disabled")
        rb.pack(fill="x", anchor="w", pady=(8, 2))
        return rb

    def _path_row(self, parent, caption, value, command):
        row = ctk.CTkFrame(parent, fg_color=MD3["surface_high"], corner_radius=12)
        row.pack(fill="x", padx=(28, 0), pady=(2, 4))
        label(row, caption, F(11), "on_surface_var", anchor="w").pack(fill="x", padx=12, pady=(6, 0))
        line = ctk.CTkFrame(row, fg_color="transparent")
        line.pack(fill="x", padx=12, pady=(0, 8))
        shown = value if len(value) <= 52 else "…" + value[-50:]
        label(line, shown, F(12, True), anchor="w").pack(side="left", fill="x", expand=True)
        button(line, "Изменить...", command, width=100, height=28, corner_radius=14).pack(side="right")

    def _section_storage(self, parent):
        app, drive = self.app, self.app.drive
        self._title(parent, "Хранилище клипов", top=16)
        mode = app.config_data.get("storage_mode", "local")
        if mode == "cloud" and not drive.connected:
            mode = app.config_data["storage_mode"] = "local"
        self.mode_var = tk.StringVar(value=mode)
        self._radio(parent, "Локальное хранилище", "local")
        if mode == "local":
            self._path_row(parent, "Клипы сохраняются в папку (для каждого запуска — подпапка Clips_Output_…):",
                           str(app.local_root()), self._change_local_dir)
        self._radio(parent, "Облачное хранилище (Google Drive)", "cloud", enabled=drive.connected)
        if not drive.connected:
            label(parent, "Станет доступно после подключения Google Drive", F(11), "outline", anchor="w").pack(fill="x", padx=28)
        elif mode == "cloud":
            folder = app.config_data.get("gdrive_folder", "Клипы")
            if self.editing_folder:
                self._folder_editor(parent, folder)
            else:
                self._path_row(parent, "Папка на Google Drive («Мой диск»), создаётся при первом сохранении:",
                               f"/{folder}", self._start_edit_folder)
            label(parent, "Рабочая копия клипа остаётся на ПК — для просмотра, редактирования и загрузки на YouTube/TikTok.",
                  F(11), "on_surface_var", anchor="w", justify="left", wraplength=480).pack(fill="x", padx=28, pady=(2, 0))

    def _section_performance(self, parent):
        app = self.app
        self._title(parent, "Производительность", top=16)
        ok = parallel_render_available()
        var = ctk.BooleanVar(value=bool(app.config_data.get("parallel_render")) and ok)
        self._refs.append(var)

        def toggle():
            app.config_data["parallel_render"] = bool(var.get())
            app.save_config()
        cb = checkbox(parent, "Параллельный рендер (2 клипа одновременно)", var, toggle, F(13, True))
        cb.pack(fill="x", anchor="w", pady=(4, 2))
        if ok:
            hint = "Быстрее, но сильно нагружает процессор — работать параллельно в других программах будет тяжело."
        else:
            cb.configure(state="disabled")
            hint = f"Недоступно: ядер в процессоре — {physical_cores()}, нужно от {PARALLEL_MIN_CORES}."
        label(parent, hint, F(11), "on_surface_var", anchor="w", justify="left", wraplength=480).pack(fill="x", padx=28)

    def _section_network(self, parent):
        app = self.app
        self._title(parent, "Сеть", top=16)
        var = ctk.BooleanVar(value=bool(app.config_data.get("yt_bypass", True)))
        self._refs.append(var)

        def toggle():
            app.config_data["yt_bypass"] = bool(var.get())
            app.save_config()
        checkbox(parent, "Обход блокировок YouTube", var, toggle, F(13, True)).pack(fill="x", anchor="w", pady=(4, 2))
        label(parent, "Если YouTube напрямую не открывается, программа сама подберёт способ обхода для скачивания "
                      "по ссылке (без VPN, только для этой программы).", F(11), "on_surface_var", anchor="w",
              justify="left", wraplength=480).pack(fill="x", padx=28)
        label(parent, "Прокси (необязательно):", F(12, True), anchor="w").pack(fill="x", pady=(10, 2))
        e = entry(parent, font=F(12), height=32, placeholder_text="socks5://127.0.0.1:10808 или http://адрес:порт")
        e.pack(fill="x")
        if app.config_data.get("proxy"):
            e.insert(0, app.config_data["proxy"])

        def save_proxy(_ev=None):
            v = e.get().strip()
            if v and not re.match(r"^(socks5h?|socks4a?|https?)://[^\s/]+:\d+/?$", v, re.IGNORECASE):
                hint.configure(text="Формат: socks5://адрес:порт или http://адрес:порт", text_color=MD3["error"])
                return
            hint.configure(text=PROXY_HINT, text_color=MD3["on_surface_var"])
            if v != (app.config_data.get("proxy") or ""):
                app.config_data["proxy"] = v
                app.save_config()
        e.bind("<KeyRelease>", save_proxy)
        e.bind("<FocusOut>", save_proxy)
        hint = label(parent, PROXY_HINT, F(11), "on_surface_var", anchor="w", justify="left", wraplength=480)
        hint.pack(fill="x", padx=2, pady=(2, 0))

    def _section_analysis(self, parent):
        app = self.app
        self._title(parent, "Нейросети анализа", top=16)
        items = (("nn_voice", "voice", "Различать голоса нейросетью", (SPEAKER_MODEL,),
                  "Точнее понимает, сколько персонажей и кто из них говорит."),
                 ("nn_vgender", "vgender", "Определять пол по голосу нейросетью", (VOICE_GENDER_MODEL,),
                  "Надёжнее, чем по высоте голоса: не путается на низких женских и высоких мужских голосах."),
                 ("nn_face", "face", "Определять пол по лицу и фигуре", (MIVOLO_MODEL, GENDER_MODEL),
                  "Уточняет пол по тому, кто говорит в кадре; работает, даже если лица не видно."))
        for key, flag, text, models, hint in items:
            ok = any((NN_DIR / m).exists() for m in models)
            var = ctk.BooleanVar(value=bool(app.config_data.get(key, True)) and ok)
            self._refs.append(var)

            def toggle(k=key, f=flag, v=var):
                app.config_data[k] = NN_ENABLED[f] = bool(v.get())
                app.save_config()
            cb = checkbox(parent, text, var, toggle, F(13, True))
            cb.pack(fill="x", anchor="w", pady=(4, 2))
            if not ok:
                cb.configure(state="disabled")
                hint = "Модель не установлена — работает прежний способ."
            label(parent, hint, F(11), "on_surface_var", anchor="w", justify="left", wraplength=480).pack(fill="x", padx=28)

    def _section_updates(self, parent):
        u = self.app.updater
        self._title(parent, "Обновления", top=16)
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x")
        b = button(row, "Проверить обновления", self._check_updates, height=32, corner_radius=16, font=F(12, True))
        if not u.enabled or u.checking:
            b.configure(state="disabled")
        b.pack(side="left")
        if not u.enabled:
            status, color = u.disabled_reason, "outline"
        elif u.checking:
            status, color = "Проверка...", "on_surface_var"
        elif u.available:
            status, color = f"Доступна версия {u.new_version}", "primary"
        elif u.last_check == "latest":
            status, color = "Установлена последняя версия", "on_success"
        elif u.last_check == "error":
            status, color = "Не удалось проверить — нет связи с GitHub", "error"
        else:
            status, color = "", "on_surface_var"
        label(row, status, F(12, True), color).pack(side="left", padx=12)
        if u.enabled and u.available and not u.checking:
            button(row, "Обновить", self.app.updates_overlay.open, "primary", width=96, height=32, corner_radius=16,
                   font=F(12, True)).pack(side="left")

    def _check_updates(self):
        run_bg(self.app.updater.check)
        self.app.after(50, lambda: self.render_section("updates"))

    def _folder_editor(self, parent, folder):
        row = ctk.CTkFrame(parent, fg_color=MD3["surface_high"], corner_radius=12)
        row.pack(fill="x", padx=(28, 0), pady=(2, 4))
        label(row, "Путь от «Мой диск», вложенные папки через «/» (например: Клипы/Shorts):", F(11), "on_surface_var",
              anchor="w").pack(fill="x", padx=12, pady=(6, 2))
        line = ctk.CTkFrame(row, fg_color="transparent")
        line.pack(fill="x", padx=12, pady=(0, 8))
        ent = entry(line, height=30)
        ent.insert(0, folder)
        ent.pack(side="left", fill="x", expand=True, padx=(0, 8))
        save = lambda *_: self._save_folder(ent.get())
        ent.bind("<Return>", save)
        button(line, "✓", save, "primary", width=34, height=30, corner_radius=15, font=F(13, True)).pack(side="left", padx=(0, 4))
        button(line, "✕", self._cancel_edit_folder, width=34, height=30, corner_radius=15).pack(side="left")
        ent.focus_set()

    # --- действия ---
    def _on_mode(self):
        self.app.set_storage_mode(self.mode_var.get())
        self.editing_folder = False
        self.render_section("storage")

    def _change_local_dir(self):
        path = filedialog.askdirectory(title="Папка для сохранения клипов", initialdir=str(self.app.local_root()), parent=self.app)
        if path:
            self.app.config_data["local_dir"] = path
            self.app.save_config()
            self.app.log(f"[*] Клипы будут сохраняться в: {path}")
        self.render_section("storage")

    def _start_edit_folder(self):
        self.editing_folder = True
        self.render_section("storage")

    def _cancel_edit_folder(self):
        self.editing_folder = False
        self.render_section("storage")

    def _save_folder(self, value):
        folder = GoogleDrive.normalize_folder(value)
        self.app.config_data["gdrive_folder"] = folder
        self.app.save_config()
        self.app.log(f"[*] Папка на Google Drive для клипов: /{folder}")
        self.editing_folder = False
        self.render_section("storage")

    def _connect(self):
        self.app.drive_wizard.open()

    def _logout(self):
        name = self.app.drive.user.get("name", "Google")
        if not ask_yes_no(self.app, "Выход из аккаунта",
                          f"Выйти из аккаунта Google Drive «{name}»?\n\nКлипы, уже сохранённые на Google Drive, останутся там. "
                          "Новые клипы будут сохраняться в локальное хранилище."):
            return
        self.app.drive.logout()
        self.app.set_storage_mode("local")
        self.app.log(f"[*] Выполнен выход из Google Drive ({name}).")
        self.render_section("gdrive", "storage")


# ---------------------------- МАСТЕР ПОДКЛЮЧЕНИЯ GOOGLE DRIVE ----------------------------
GCLOUD_PROFILE_DIR = DATA_ROOT / "gcloud_setup_profile"   # общий вход Google для всех шагов мастера
GDRIVE_SETUP_FILE = DATA_ROOT / "gdrive_setup.json"        # какие шаги уже выполнены (можно продолжить позже)
CLOUD = "https://console.cloud.google.com"
SETUP_STEPS = (  # ключ, шаг, что сделать, страница
    ("signin", "Войдите в Google", "Войдите в аккаунт и примите условия Google Cloud", f"{CLOUD}/"),
    ("project", "Создайте проект", "Нажмите «Создать» — имя можно не менять", f"{CLOUD}/projectcreate"),
    ("api", "Включите Google Drive API", "Нажмите «Включить»", f"{CLOUD}/apis/library/drive.googleapis.com"),
    ("consent", "Настройте экран входа", "Название, почта, тип «Внешний» → «Создать»", f"{CLOUD}/auth/overview/create"),
    ("publish", "Опубликуйте приложение", "«Опубликовать приложение» → «Подтвердить»", f"{CLOUD}/auth/audience"),
    ("client", "Создайте ключ", "Тип «Приложение для ПК» → «Создать» → «Скачать JSON»", f"{CLOUD}/auth/clients/create"),
    ("login", "Войдите в Google Drive", "Выберите аккаунт для клипов и разрешите доступ", None),
)


class CloudSetupCheck:
    """Как понять, что шаг выполнен, — по адресу и содержимому страницы, которой управляет программа."""
    SIGNED_COOKIES = ("SID", "__Secure-1PSID", "__Secure-3PSID", "SAPISID")
    TOS = re.compile(r"Terms of Service|Условия (использования|предоставления)", re.I)
    API_ON = re.compile(r"^(Manage|Управлять|Управление|Disable API|Отключить API)$", re.I)
    PUBLISHED = re.compile(r"In production|Back to testing|Рабочая версия|В рабочем режиме|Вернуть в режим тестирования|"
                           r"Вернуться к тестированию|Перевести в режим тестирования", re.I)

    @staticmethod
    def project_of(url: str):
        from urllib.parse import urlparse, parse_qs
        return (parse_qs(urlparse(url).query).get("project") or [None])[0]

    @classmethod
    def done(cls, key: str, page, ctx, st: dict) -> bool:
        url = page.url or ""
        if key == "signin":
            signed = "console.cloud.google.com" in url and any(c.get("name") in cls.SIGNED_COOKIES for c in ctx.cookies())
            return signed and page.get_by_text(cls.TOS).count() == 0
        if key == "project":
            pid = cls.project_of(url)
            if "projectcreate" not in url and pid and pid != st.get("start_project"):
                st["project"] = pid
                return True
            return False
        if key == "api":
            return "/apis/api/drive.googleapis.com" in url or page.get_by_role("button", name=cls.API_ON).count() > 0
        if key == "consent":
            return bool(re.search(r"/auth/(overview|branding|audience|clients|data)(\?|$|/)", url)) and "/create" not in url
        if key == "publish":
            return "/auth/audience" in url and page.get_by_text(cls.PUBLISHED).count() > 0
        return False


class DriveSetupWizard(Overlay):
    TITLE = "Подключение Google Drive"
    WIDTH = 560
    SCROLL_HEIGHT = 620

    def __init__(self, app):
        super().__init__(app)
        st = read_json(GDRIVE_SETUP_FILE, {})
        self.state = st if isinstance(st, dict) else {}
        self.state.setdefault("done", [])
        self.busy = None          # ключ шага, окно которого сейчас открыто
        self.error = ""
        self._stop = threading.Event()

    def open(self):
        if GoogleDrive.has_client():  # ключ уже есть — остался только вход
            self.state["done"] = [k for k, *_ in SETUP_STEPS if k != "login"]
        super().open()

    def on_close(self):
        self._stop.set()

    def _save(self):
        write_json(GDRIVE_SETUP_FILE, self.state)

    def _is_done(self, key) -> bool:
        return key in self.state["done"]

    def _current(self):
        return next((k for k, *_ in SETUP_STEPS if not self._is_done(k)), None)

    def build(self, body):
        label(body, "Один раз зарегистрируйте программу в своём Google — клипы будут сохраняться на ваш Диск.",
              F(12), "on_surface_var", anchor="w", justify="left", wraplength=self.WIDTH - 70).pack(fill="x", pady=(0, 10))
        cur = self._current()
        for n, (key, title, hint, url) in enumerate(SETUP_STEPS, 1):
            done, active = self._is_done(key), key == cur
            if n > 1:  # пункты идут списком на общем фоне, между ними — тонкая линия
                ctk.CTkFrame(body, height=1, fg_color=MD3["outline"]).pack(
                    fill="x", padx=(52, 0))
            row = ctk.CTkFrame(body, fg_color="transparent")
            row.pack(fill="x", pady=2)
            row.grid_columnconfigure(1, weight=1)
            label(row, "✓" if done else str(n), F(13, True), "on_primary" if (active and not done) else ("on_success" if done else "on_surface_var"),
                  width=30, height=30, corner_radius=15,
                  fg_color="#2E6B4F" if done else (MD3["primary"] if active else MD3["surface_highest"])).grid(
                row=0, column=0, rowspan=2, padx=(4, 14), pady=10)
            label(row, title, F(13, True), "#81C995" if done else (MD3["primary"] if active else "on_surface_var"),
                  anchor="w").grid(row=0, column=1, sticky="ew", pady=(10, 0))
            if not done:
                label(row, hint, F(11), "on_surface_var", anchor="w").grid(row=1, column=1, sticky="ew", pady=(0, 10))
            if active:
                busy = self.busy == key
                text = ("Ожидание..." if busy else "Войти") if key == "login" else ("Открыто..." if busy else "Открыть")
                b = button(row, text, lambda k=key: self._run(k), "primary", width=104, height=32, corner_radius=16, font=F(12, True))
                if self.busy:
                    b.configure(state="disabled")
                b.grid(row=0, column=2, rowspan=2, padx=(12, 4))
                if key != "login" and not busy:
                    manual = label(row, "Отметить выполненным", F(10), "on_surface_var", cursor="hand2")
                    manual.grid(row=2, column=1, columnspan=2, sticky="e", padx=4, pady=(0, 8))
                    manual.bind("<Button-1>", lambda _e, k=key: self._manual(k))
        if self.error:
            label(body, self.error, F(12), "error", anchor="w", justify="left", wraplength=self.WIDTH - 70).pack(fill="x", pady=(8, 0))
        if not GoogleDrive.has_client():
            link = label(body, "Уже есть файл ключа (client_secret….json)? Выбрать файл", F(11), "primary", cursor="hand2")
            link.pack(anchor="w", pady=(10, 0))
            link.bind("<Button-1>", lambda _e: self._pick_client_file())

    # --- действия ---
    def _mark(self, key):
        if key not in self.state["done"]:
            self.state["done"].append(key)
        self._save()

    def _manual(self, key):
        if key == "client":
            return self._pick_client_file()
        self._mark(key)
        self.render()

    def _pick_client_file(self):
        path = filedialog.askopenfilename(title="Файл ключа Google (client_secret….json)", parent=self.app,
                                          filetypes=[("JSON", "*.json"), ("Все файлы", "*.*")])
        if not path:
            return
        try:
            GoogleDrive.import_client(path)
        except Exception as e:
            self.error = str(e)
            return self.render()
        self.error = ""
        for k, *_ in SETUP_STEPS:
            if k != "login":
                self._mark(k)
        self.render()

    def _run(self, key):
        if self.busy:
            return
        self.busy, self.error = key, ""
        self._stop.clear()
        self.render()
        run_bg(self._login_worker if key == "login" else self._step_worker, key)

    def _finish(self, key, ok, err=""):
        def _ui():
            self.busy = None
            if ok:
                self._mark(key)
            elif err:
                self.error = err
            if key == "login" and ok:
                shutil.rmtree(GCLOUD_PROFILE_DIR, ignore_errors=True)
                GDRIVE_SETUP_FILE.unlink(missing_ok=True)
                self.state = {"done": []}
                self.close()
                self.app.settings.open()
                return
            self.render()
        self.app.after(0, _ui)

    def _step_worker(self, key):
        url = dict((k, u) for k, _, _, u in SETUP_STEPS)[key]
        if self.state.get("project"):
            url += ("&" if "?" in url else "?") + f"project={self.state['project']}"
        ok, err = False, ""
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                ctx = launch_browser_context(p, str(GCLOUD_PROFILE_DIR), headless=False, width=1100, height=780)
                page = ctx.pages[0] if ctx.pages else ctx.new_page()
                got = {}
                if key == "client":  # ключ перехватывается при нажатии «Скачать JSON»
                    ctx.on("page", lambda pg: pg.on("download", lambda d: got.setdefault("dl", d)))
                    page.on("download", lambda d: got.setdefault("dl", d))
                page.goto(url, wait_until="domcontentloaded", timeout=60000)
                page.wait_for_timeout(1500)
                st = {"start_project": CloudSetupCheck.project_of(page.url)}
                deadline = time.time() + 1200
                while not ok and time.time() < deadline and not self._stop.is_set():
                    pages = [pg for pg in ctx.pages if not pg.is_closed()]
                    if not pages:
                        break
                    if key == "client" and "dl" in got:
                        tmp = DATA_ROOT / "client_download.json"
                        got["dl"].save_as(str(tmp))
                        GoogleDrive.import_client(str(tmp))
                        tmp.unlink(missing_ok=True)
                        ok = True
                    elif key != "client":
                        with suppress(Exception):
                            ok = any(CloudSetupCheck.done(key, pg, ctx, st) for pg in pages)
                    if not ok:
                        pages[-1].wait_for_timeout(700)
                if ok:
                    if st.get("project"):
                        self.state["project"] = st["project"]
                    with suppress(Exception):
                        pages[-1].wait_for_timeout(800)  # пользователь видит результат, затем окно закрывается
                with suppress(Exception):
                    ctx.close()
        except Exception as e:
            err = f"Не удалось открыть окно браузера: {e}"
        self._finish(key, ok, err)

    def _login_worker(self, key):
        try:
            user = self.app.drive.login(profile_dir=GCLOUD_PROFILE_DIR)
            self.app.log(f"[+] Google Drive подключён: {user.get('name')} ({user.get('email')})")
            self._finish(key, True)
        except Exception as e:
            msg = str(e)
            self.app.log(f"[-] Google Drive: {msg}")
            self._finish(key, False, "" if msg == "Вход отменён." else msg)


# ---------------------------- ОКНО ОБНОВЛЕНИЯ ----------------------------
@lru_cache(maxsize=4)
def make_folder_icon(size: int = 20, color=(208, 188, 255, 255)) -> Image.Image:
    s = size * 4
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    d.rounded_rectangle((s * 0.06, s * 0.18, s * 0.46, s * 0.40), s * 0.06, fill=color)
    d.rounded_rectangle((s * 0.06, s * 0.28, s * 0.94, s * 0.84), s * 0.08, fill=color)
    return im.resize((size, size), Image.Resampling.LANCZOS)


def make_eye_icon(size: int = 20, crossed: bool = False, color=(202, 196, 208, 255)) -> Image.Image:
    """Глазик для поля пароля: открытый — ключ скрыт (нажми, чтобы показать), перечёркнутый — ключ виден."""
    s = size * 4
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    w = max(2, s // 12)
    d.arc((s * 0.06, s * 0.22, s * 0.94, s * 1.10), 200, 340, fill=color, width=w)
    d.arc((s * 0.06, s * -0.10, s * 0.94, s * 0.78), 20, 160, fill=color, width=w)
    r = s * 0.14
    d.ellipse((s * 0.5 - r, s * 0.5 - r, s * 0.5 + r, s * 0.5 + r), fill=color)
    if crossed:
        d.line((s * 0.16, s * 0.16, s * 0.84, s * 0.84), fill=(0, 0, 0, 0), width=w * 3)
        d.line((s * 0.16, s * 0.16, s * 0.84, s * 0.84), fill=color, width=w)
    return im.resize((size, size), Image.Resampling.LANCZOS)


def make_download_icon(size: int = 22, color=(208, 188, 255, 255)) -> Image.Image:
    s = size * 4
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    w = max(2, s // 10)
    d.line((s * 0.5, s * 0.10, s * 0.5, s * 0.62), fill=color, width=w)
    d.polygon([(s * 0.5, s * 0.74), (s * 0.27, s * 0.47), (s * 0.73, s * 0.47)], fill=color)
    d.line((s * 0.14, s * 0.70, s * 0.14, s * 0.88, s * 0.86, s * 0.88, s * 0.86, s * 0.70), fill=color, width=w, joint="curve")
    return im.resize((size, size), Image.Resampling.LANCZOS)


class ClipPlayer(Overlay):
    """
    Встроенный плеер: видео 9:16 без рамок поверх размытого интерфейса. Всё нарисовано на одном холсте —
    крестик и кнопки «парят» без подложек. Клик по свободному месту закрывает плеер, клик по видео — пауза.
    Звук — sounddevice (часы воспроизведения), без звука — по системным часам.
    """
    SR = 48000

    def __init__(self, app):
        super().__init__(app)
        self.canvas = self.clip = None
        self._stop = threading.Event()
        self._seek_to = None
        self._frames = None
        self._tick_job = None
        self._audio = self._stream = None
        self._pos = 0              # позиция звука в сэмплах
        self._paused = False
        self._t0_wall, self._t0_pos = 0.0, 0.0
        self._duration = 0.0
        self._photo = self._vphoto = None
        self._dragging = False
        self.volume = float(app.config_data.get("player_volume", 1.0)) if hasattr(app, "config_data") else 1.0

    @property
    def is_open(self) -> bool:
        return self.canvas is not None

    # --- открытие/закрытие ---
    def open(self, clip=None):
        if clip is None:
            return
        if not self.is_open:
            for other in self.app.overlays:
                if other is not self:
                    other.close()
            self._build_canvas()
        self._load(clip)

    def close(self):
        self._stop_media()
        if self.canvas is not None:
            with suppress(Exception):
                self.canvas.destroy()
        self.canvas = self.clip = None
        self._photo = self._vphoto = None
        for seq in ("<Escape>", "<space>", "<Left>", "<Right>"):
            with suppress(Exception):
                self.app.unbind(seq)

    def on_resize(self):
        if self.is_open:
            if self._resize_job:
                self.app.after_cancel(self._resize_job)
            self._resize_job = self.app.after(250, self._relayout)

    def _build_canvas(self):
        bg = self._blurred_screenshot()
        self.canvas = tk.Canvas(self.app, bd=0, highlightthickness=0, bg="#0d0c10", cursor="arrow")
        self.canvas.place(x=0, y=0, relwidth=1, relheight=1)
        if bg:
            self.canvas.create_image(0, 0, anchor="nw", image=bg, tags="bg")
        self.canvas.bind("<Button-1>", self._on_click)
        self.canvas.bind("<B1-Motion>", self._on_drag)
        self.canvas.bind("<ButtonRelease-1>", self._on_release)
        self.canvas.bind("<Configure>", self._on_canvas_resize)
        self.app.bind("<Escape>", lambda _e: self.close(), add="+")
        self.app.bind("<space>", lambda _e: self.toggle_pause(), add="+")
        self.app.bind("<Left>", lambda _e: self.seek(self.position() - 5), add="+")
        self.app.bind("<Right>", lambda _e: self.seek(self.position() + 5), add="+")

    def _on_canvas_resize(self, e):
        if self.is_open and hasattr(self, "_laid_out_for") and (e.width, e.height) != self._laid_out_for and e.width > 50:
            self._layout()

    def _on_release(self, _e):
        if self._dragging == "vol":
            self._save_volume()
        self._dragging = False

    def _relayout(self):
        self._resize_job = None
        if not self.is_open:
            return
        self.canvas.place_forget()
        self.app.update()
        bg = self._blurred_screenshot()
        self.canvas.delete("bg")
        if bg:
            self.canvas.create_image(0, 0, anchor="nw", image=bg, tags="bg")
            self.canvas.tag_lower("bg")
        self.canvas.place(x=0, y=0, relwidth=1, relheight=1)
        self._layout()

    # --- раскладка ---
    def _layout(self):
        c = self.canvas
        with suppress(Exception):
            c.update_idletasks()
        # холст только что размещён — его размер может быть ещё 1×1; тогда берём размер окна программы
        W = c.winfo_width() if c.winfo_width() > 50 else self.app.winfo_width()
        H = c.winfo_height() if c.winfo_height() > 50 else self.app.winfo_height()
        W, H = max(320, W), max(320, H)
        self._laid_out_for = (W, H)
        sc = max(0.5, self.app._get_window_scaling())
        ctrl_h = int(110 * sc)
        vh = int(min(H - ctrl_h - 40 * sc, (W - 80 * sc) / max(0.2, self.aspect)))
        vw = max(2, int(vh * self.aspect)) // 2 * 2
        vh = max(2, vh) // 2 * 2
        x0, y0 = (W - vw) // 2, max(int(16 * sc), (H - vh - ctrl_h) // 2)
        self.box = (x0, y0, vw, vh)
        self.regions = {"video": (x0, y0, x0 + vw, y0 + vh)}  # области кликов (невидимые элементы холста не ловят клик)
        c.delete("ui")
        self._vphoto = None
        c.create_image(x0, y0, anchor="nw", tags=("ui", "video"))
        # прогресс
        py = y0 + vh + int(18 * sc)
        self.bar = (x0, py, x0 + vw)
        c.create_line(x0, py, x0 + vw, py, fill="#5a5562", width=int(5 * sc), capstyle="round", tags=("ui", "seek", "track"))
        c.create_line(x0, py, x0, py, fill=MD3["primary"], width=int(5 * sc), capstyle="round", tags=("ui", "seek", "fill"))
        r = int(7 * sc)
        c.create_oval(x0 - r, py - r, x0 + r, py + r, fill=MD3["primary"], outline="", tags=("ui", "seek", "knob"))
        self.regions["seek"] = (x0 - r, py - 12 * sc, x0 + vw + r, py + 12 * sc)
        f = ("Segoe UI", max(9, int(10 * sc)))
        c.create_text(x0, py + 18 * sc, text="0:00", anchor="w", fill="#e6e0e9", font=f, tags=("ui", "tcur"))
        c.create_text(x0 + vw, py + 18 * sc, text="0:00", anchor="e", fill="#cac4d0", font=f, tags=("ui", "tdur"))
        # кнопки: ⏮  ⏯  ⏭
        cy, cx = py + int(56 * sc), x0 + vw // 2
        self._icon_play(cx, cy, int(22 * sc))
        for dx, tag, d in ((-int(78 * sc), "prev", -1), (int(78 * sc), "next", 1)):
            self._icon_skip(cx + dx, cy, int(14 * sc), d, tag)
        # громкость: значок + ползунок справа (общая для всех клипов)
        vx1 = x0 + vw
        vx0 = max(cx + int(118 * sc), vx1 - int(110 * sc))
        self.vol_bar = (vx0, cy, vx1)
        c.create_polygon(vx0 - 30 * sc, cy - 5 * sc, vx0 - 24 * sc, cy - 5 * sc, vx0 - 16 * sc, cy - 11 * sc,
                         vx0 - 16 * sc, cy + 11 * sc, vx0 - 24 * sc, cy + 5 * sc, vx0 - 30 * sc, cy + 5 * sc,
                         fill="#f4eff4", outline="", tags=("ui", "volicon"))
        c.create_line(vx0, cy, vx1, cy, fill="#5a5562", width=int(4 * sc), capstyle="round", tags=("ui",))
        c.create_line(vx0, cy, vx0, cy, fill="#f4eff4", width=int(4 * sc), capstyle="round", tags=("ui", "volfill"))
        rk = int(6 * sc)
        c.create_oval(vx0 - rk, cy - rk, vx0 + rk, cy + rk, fill="#f4eff4", outline="", tags=("ui", "volknob"))
        self.regions["vol"] = (vx0 - rk, cy - 12 * sc, vx1 + rk, cy + 12 * sc)
        self.regions["mute"] = (vx0 - 34 * sc, cy - 14 * sc, vx0 - 12 * sc, cy + 14 * sc)
        self._draw_volume()
        # крестик справа вверху — просто линии, без подложки
        s, m = int(11 * sc), int(28 * sc)
        for a, b in (((W - m - s, m - s), (W - m + s, m + s)), ((W - m + s, m - s), (W - m - s, m + s))):
            c.create_line(*a, *b, fill="#f4eff4", width=max(2, int(3 * sc)), capstyle="round", tags=("ui", "close"))
        self.regions["close"] = (W - m - 2 * s, m - 2 * s, W - m + 2 * s, m + 2 * s)
        c.bind("<Motion>", lambda e: c.configure(cursor="hand2" if self._hit(e) else "arrow"))
        self._update_progress()

    def _icon_play(self, cx, cy, r):
        c = self.canvas
        c.delete("pp")
        c.create_oval(cx - r * 1.6, cy - r * 1.6, cx + r * 1.6, cy + r * 1.6, fill=MD3["primary"], outline="",
                      tags=("ui", "pp", "ppbg"))
        if self._paused or self._ended():
            c.create_polygon(cx - r * 0.45, cy - r * 0.7, cx - r * 0.45, cy + r * 0.7, cx + r * 0.75, cy,
                             fill=MD3["on_primary"], outline="", tags=("ui", "pp"))
        else:
            for dx in (-r * 0.38, r * 0.38):
                c.create_rectangle(cx + dx - r * 0.17, cy - r * 0.62, cx + dx + r * 0.17, cy + r * 0.62,
                                   fill=MD3["on_primary"], outline="", tags=("ui", "pp"))
        self._pp_center = (cx, cy, r)
        self.regions["pp"] = (cx - r * 1.6, cy - r * 1.6, cx + r * 1.6, cy + r * 1.6)

    def _icon_skip(self, cx, cy, r, d, tag):
        c, col = self.canvas, "#f4eff4"
        self.regions[tag] = (cx - r * 2, cy - r * 2, cx + r * 2, cy + r * 2)
        c.create_polygon(cx - d * r * 0.7, cy - r * 0.8, cx - d * r * 0.7, cy + r * 0.8, cx + d * r * 0.5, cy,
                         fill=col, outline="", tags=("ui", tag))
        c.create_line(cx + d * r * 0.75, cy - r * 0.8, cx + d * r * 0.75, cy + r * 0.8, fill=col,
                      width=max(2, int(r * 0.3)), tags=("ui", tag))

    # --- клики ---
    def _hit(self, e):
        return {k for k, (a, b, c, d) in getattr(self, "regions", {}).items() if a <= e.x <= c and b <= e.y <= d}

    def _on_click(self, e):
        tags = self._hit(e)
        if "close" in tags:
            return self.close()
        if "seek" in tags:
            self._dragging = True
            return self._seek_x(e.x)
        if "vol" in tags:
            self._dragging = "vol"
            return self._vol_x(e.x)
        if "mute" in tags:
            self.volume = 0.0 if self.volume > 0 else (getattr(self, "_vol_before_mute", 0.8) or 0.8)
            self._draw_volume()
            return self._save_volume()
        if "pp" in tags or "video" in tags:
            return self.toggle_pause()
        if "prev" in tags:
            return self.step(-1)
        if "next" in tags:
            return self.step(1)
        self.close()  # свободное место

    def _on_drag(self, e):
        if self._dragging == "vol":
            self._vol_x(e.x)
        elif self._dragging:
            self._seek_x(e.x)

    def _vol_x(self, x):
        x0, _, x1 = self.vol_bar
        self.volume = round(min(1.0, max(0.0, (x - x0) / max(1, x1 - x0))), 3)
        if self.volume > 0:
            self._vol_before_mute = self.volume
        self._draw_volume()

    def _draw_volume(self):
        if not hasattr(self, "vol_bar"):
            return
        x0, cy, x1 = self.vol_bar
        x = x0 + (x1 - x0) * self.volume
        c = self.canvas
        c.coords("volfill", x0, cy, x, cy)
        r = (c.coords("volknob")[2] - c.coords("volknob")[0]) / 2 if c.coords("volknob") else 6
        c.coords("volknob", x - r, cy - r, x + r, cy + r)
        c.itemconfigure("volicon", fill="#f4eff4" if self.volume > 0 else "#8a8592")

    def _save_volume(self):
        self.app.config_data["player_volume"] = self.volume
        with suppress(Exception):
            self.app.save_config()

    def _seek_x(self, x):
        x0, _, x1 = self.bar
        self.seek((min(max(x, x0), x1) - x0) / max(1, x1 - x0) * self._duration)

    # --- медиа ---
    def _load(self, clip):
        self._stop_media()
        self.clip = clip
        path = str(clip["file_path"])
        cap = cv2.VideoCapture(path)
        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        w, h = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 1080), int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 1920)
        n = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
        self.fps, self.aspect = fps, (w / h if h else 9 / 16)
        self._duration = float(n / fps) if n > 0 else max(0.1, float(clip.get("end", 0)) - float(clip.get("start", 0)))
        self._paused, self._pos, self._seek_to = False, 0, 0.0
        self._t0_wall, self._t0_pos = time.monotonic(), 0.0
        self._stop = threading.Event()
        self._frames = queue.Queue(maxsize=6)
        self._layout()
        threading.Thread(target=self._decode, args=(cap, self._stop, self._frames), daemon=True).start()
        self._start_audio(path, self._stop)
        self._tick()

    def _stop_media(self):
        self._stop.set()
        if self._tick_job:
            with suppress(Exception):
                self.app.after_cancel(self._tick_job)
            self._tick_job = None
        if self._stream is not None:
            with suppress(Exception):
                self._stream.stop()
                self._stream.close()
        self._stream = self._audio = None

    def _decode(self, cap, stop, frames):
        """Поток декодирования: кадры сразу уменьшаются до размера на экране."""
        try:
            while not stop.is_set():
                if self._seek_to is not None:
                    t, self._seek_to = self._seek_to, None
                    cap.set(cv2.CAP_PROP_POS_MSEC, t * 1000.0)
                    with suppress(queue.Empty):
                        while True:
                            frames.get_nowait()
                if self._paused and not frames.empty():
                    time.sleep(0.02)
                    continue
                ok, frame = cap.read()
                if not ok:
                    time.sleep(0.03)
                    continue
                pts = (cap.get(cv2.CAP_PROP_POS_MSEC) or 0) / 1000.0
                _, _, vw, vh = self.box
                small = cv2.cvtColor(cv2.resize(frame, (vw, vh), interpolation=cv2.INTER_AREA), cv2.COLOR_BGR2RGB)
                while not stop.is_set():
                    try:
                        frames.put((pts, small), timeout=0.1)
                        break
                    except queue.Full:
                        if self._seek_to is not None:
                            break
        finally:
            cap.release()

    def _start_audio(self, path, stop):
        def _worker():
            with suppress(Exception):
                raw = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-vn", "-ac", "2", "-ar", str(self.SR),
                                      "-f", "s16le", "-"], capture_output=True, timeout=120,
                                     creationflags=NO_WINDOW_FLAG).stdout
                if stop.is_set() or not raw:
                    return
                audio = np.frombuffer(raw, np.int16).reshape(-1, 2)
                import sounddevice as sd

                def cb(out, frames, _t, _s):
                    a = self._audio
                    if a is None or self._paused:
                        out.fill(0)
                        return
                    p = self._pos
                    chunk = a[p:p + frames]
                    v = self.volume
                    out[:len(chunk)] = chunk if v >= 0.999 else (chunk * v).astype(np.int16)
                    out[len(chunk):] = 0
                    self._pos = p + len(chunk)
                self._pos = int(self.position() * self.SR)  # звук догоняет уже идущее видео
                if abs(len(audio) / self.SR - self._duration) < 1.0:
                    self._duration = min(self._duration, len(audio) / self.SR)
                self._audio = audio
                stream = sd.OutputStream(samplerate=self.SR, channels=2, dtype="int16", callback=cb, blocksize=1024)
                if stop.is_set():
                    return
                stream.start()
                self._stream = stream
        threading.Thread(target=_worker, daemon=True).start()

    def position(self) -> float:
        if self._audio is not None and self._stream is not None:
            return self._pos / self.SR
        if self._paused:
            return self._t0_pos
        return self._t0_pos + time.monotonic() - self._t0_wall

    def _ended(self) -> bool:
        return self._duration > 0 and self.position() >= self._duration - 0.05

    def seek(self, t):
        t = max(0.0, min(float(t), max(0.0, self._duration - 0.05)))
        self._pos = int(t * self.SR)
        self._t0_pos, self._t0_wall = t, time.monotonic()
        self._seek_to = t
        self._update_progress(t)

    def toggle_pause(self):
        if not self.is_open:
            return
        if self._ended():
            self.seek(0.0)
            self._paused = False
        else:
            if not self._paused:
                self._t0_pos = self.position()
            self._paused = not self._paused
            self._t0_wall = time.monotonic()
        self._icon_play(*self._pp_center)

    def step(self, d: int):
        clips = [c for c in self.app.created_clips if Path(c["file_path"]).exists()]
        if self.clip not in clips or len(clips) < 2:
            return
        self.open(clips[(clips.index(self.clip) + d) % len(clips)])

    # --- отрисовка ---
    def _tick(self):
        self._tick_job = None
        if not self.is_open:
            return
        t = self.position()
        if self._ended() and not self._paused:
            self._t0_pos, self._paused = self._duration, True
            self._icon_play(*self._pp_center)
        frame = None
        with suppress(queue.Empty):
            while True:  # самый свежий кадр, время которого уже наступило
                pts, img = self._frames.queue[0] if self._frames.queue else (None, None)
                if pts is None or pts > t + 0.5 / self.fps:
                    break
                frame = self._frames.get_nowait()
        if frame is not None:
            self._show(frame[1])
        self._update_progress(t)
        self._tick_job = self.app.after(12, self._tick)

    def _show(self, rgb):
        from PIL import ImageTk
        img = Image.fromarray(rgb)
        if self._vphoto is None or self._vphoto.width() != img.width or self._vphoto.height() != img.height:
            self._vphoto = ImageTk.PhotoImage(img)
            self.canvas.itemconfigure("video", image=self._vphoto)
        else:
            self._vphoto.paste(img)

    def _update_progress(self, t=None):
        if not self.is_open or not hasattr(self, "bar"):
            return
        t = self.position() if t is None else t
        x0, py, x1 = self.bar
        k = 0.0 if self._duration <= 0 else min(1.0, max(0.0, t / self._duration))
        x = x0 + (x1 - x0) * k
        c = self.canvas
        c.coords("fill", x0, py, x, py)
        r = (c.coords("knob")[2] - c.coords("knob")[0]) / 2 if c.coords("knob") else 7
        c.coords("knob", x - r, py - r, x + r, py + r)
        fmt = lambda v: f"{int(v) // 60}:{int(v) % 60:02d}"
        c.itemconfigure("tcur", text=fmt(t))
        c.itemconfigure("tdur", text=fmt(self._duration))


class BannerPositionOverlay(Overlay):
    """Чёрный макет видео 9:16: баннер перетаскивается мышью туда, где он будет в клипе; за жёлтую рамку
    (края и углы) — меняется размер. «По умолчанию» возвращает стандартные место и размер."""
    TITLE, WIDTH = "Положение баннера", 420
    EDGE = 7   # px: насколько близко к жёлтой рамке начинается изменение размера
    CURSORS = {"l": "sb_h_double_arrow", "r": "sb_h_double_arrow", "t": "sb_v_double_arrow", "b": "sb_v_double_arrow",
               "tl": "size_nw_se", "br": "size_nw_se", "tr": "size_ne_sw", "bl": "size_ne_sw"}

    def __init__(self, host, get_state, set_state):
        super().__init__(host)
        self.get_state, self.set_state = get_state, set_state   # () -> (имя, xy|None); (xy|None) -> None

    def build(self, body):
        name, xy = self.get_state()
        info = probe_banner(name) if name and name != BANNER_NONE else {}
        if not info:
            label(body, "Сначала выберите баннер.", F(12), "on_surface_var", anchor="w").pack(fill="x")
            return
        sc = max(0.5, self.app._get_window_scaling())
        ch = int(min(600, max(340, self.app.winfo_height() / sc - 260)) * sc)
        cw = int(ch * 9 / 16)
        self.k = cw / BANNER_REF_W
        self.m = m = int(36 * sc)  # поле вокруг кадра: видно, что баннер вышел за край
        cv = tk.Canvas(body, width=cw + 2 * m, height=ch + 2 * m, bg=MD3["surface_container"], highlightthickness=0,
                       bd=0, cursor="fleur")
        cv.pack(pady=(4, 8))
        cv.create_rectangle(m, m, m + cw, m + ch, fill="#000000", outline="")
        self.info = info
        self.bw1, self.bh1 = banner_size(info, BANNER_REF_W, BANNER_REF_H)   # стандартный размер
        self.scale = banner_scale(xy)
        self.bw, self.bh = banner_size(info, BANNER_REF_W, BANNER_REF_H, self.scale)
        self.prev = banner_preview(info)
        self._img = None
        if self.prev is not None:
            cv.create_image(0, 0, anchor="nw", tags="b")
        else:
            cv.create_rectangle(0, 0, 1, 1, fill="#4CAF50", outline="", tags="fill")
        # всё, что за кадром, приглушено — в клип не попадёт
        W2, H2 = cw + 2 * m, ch + 2 * m
        for r in ((0, 0, W2, m), (0, m + ch, W2, H2), (0, m, m, m + ch), (m + cw, m, W2, m + ch)):
            cv.create_rectangle(*r, fill=MD3["surface_container"], outline="", stipple="gray75", tags="shade")
        cv.create_rectangle(m, m, m + cw, m + ch, outline=MD3["outline"], width=1)
        cv.create_rectangle(0, 0, 1, 1, outline="#FFD54F", width=2, tags="frame")  # края баннера
        x, y, _, _ = banner_box(info, BANNER_REF_W, BANNER_REF_H, xy)
        self.pos = [x, y]
        self.cv = cv
        cv.tag_raise("shade")
        cv.tag_raise("frame")
        self._render_img()
        self._place()
        self._grab = self._resize = None
        cv.bind("<Motion>", self._hover)
        cv.bind("<ButtonPress-1>", self._press)
        cv.bind("<B1-Motion>", self._drag)
        cv.bind("<ButtonRelease-1>", lambda _e: self._commit())
        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x")
        self.pos_lbl = label(row, "", F(11), "on_surface_var", anchor="w", justify="left")
        self.pos_lbl.pack(side="left")
        button(row, "По умолчанию", self._reset, "surface", height=30, corner_radius=15, font=F(12)).pack(side="right")
        label(body, "Перетащите баннер мышью. Потяните за жёлтую рамку — изменится размер.", F(11), "outline",
              anchor="w", justify="left", wraplength=self.WIDTH - 40).pack(fill="x", pady=(6, 0))
        self._update_label()

    def _render_img(self, fast=False):
        if self.prev is None:
            return
        from PIL import ImageTk
        size = (max(1, int(self.bw * self.k)), max(1, int(self.bh * self.k)))
        img = ImageTk.PhotoImage(self.prev.resize(size, Image.Resampling.BILINEAR if fast else Image.Resampling.LANCZOS))
        self._img = img   # ссылка держит картинку (иначе Tk её выгрузит)
        self.cv.itemconfigure("b", image=img)

    def _box(self):
        x, y = self.m + self.pos[0] * self.k, self.m + self.pos[1] * self.k
        return x, y, x + self.bw * self.k, y + self.bh * self.k

    def _place(self):
        x0, y0, x1, y1 = self._box()
        self.cv.coords("b", x0, y0)
        self.cv.coords("fill", x0, y0, x1, y1)
        self.cv.coords("frame", x0 - 1, y0 - 1, x1 + 1, y1 + 1)

    def _handle(self, ex, ey):
        """Край или угол жёлтой рамки под курсором: 'l', 'r', 't', 'b', 'tl', … или None."""
        x0, y0, x1, y1 = self._box()
        e = self.EDGE
        if not (x0 - e <= ex <= x1 + e and y0 - e <= ey <= y1 + e):
            return None
        v = "t" if abs(ey - y0) <= e else "b" if abs(ey - y1) <= e else ""
        h = "l" if abs(ex - x0) <= e else "r" if abs(ex - x1) <= e else ""
        return (v + h) or None

    def _hover(self, e):
        if self._grab is None and self._resize is None:
            self.cv.configure(cursor=self.CURSORS.get(self._handle(e.x, e.y), "fleur"))

    def _press(self, e):
        hd = self._handle(e.x, e.y)
        if hd:
            self._resize = (hd, self.pos[0], self.pos[1], self.bw, self.bh)
            return
        x0, y0, x1, y1 = self._box()
        inside = x0 <= e.x <= x1 and y0 <= e.y <= y1
        self._grab = (e.x - x0, e.y - y0) if inside else (self.bw * self.k / 2, self.bh * self.k / 2)
        self._drag(e)

    def _drag(self, e):
        if self._resize is not None:
            return self._do_resize(e)
        if self._grab is None:
            return
        nx = (e.x - self._grab[0] - self.m) / self.k
        ny = (e.y - self._grab[1] - self.m) / self.k
        self.pos = list(clamp_banner_xy(nx, ny, self.bw, self.bh))
        self._place()
        self._update_label()

    def _do_resize(self, e):
        """Размер меняется пропорционально; противоположный край (угол) остаётся на месте."""
        hd, x0, y0, w0, h0 = self._resize
        mx, my = (e.x - self.m) / self.k, (e.y - self.m) / self.k
        cand = []
        if "r" in hd:
            cand.append((mx - x0) / self.bw1)
        if "l" in hd:
            cand.append((x0 + w0 - mx) / self.bw1)
        if "b" in hd:
            cand.append((my - y0) / self.bh1)
        if "t" in hd:
            cand.append((y0 + h0 - my) / self.bh1)
        s0 = w0 / float(self.bw1)   # за угол — по той стороне, которую потянули сильнее
        sc = min(BANNER_SCALE_MAX, max(BANNER_SCALE_MIN, max(cand, key=lambda c: abs(c - s0))))
        self.scale = sc
        self.bw, self.bh = banner_size(self.info, BANNER_REF_W, BANNER_REF_H, sc)
        nx = x0 + w0 - self.bw if "l" in hd else x0
        ny = y0 + h0 - self.bh if "t" in hd else y0
        if hd in ("l", "r"):   # за боковой край — по центру по вертикали
            ny = y0 + (h0 - self.bh) / 2
        if hd in ("t", "b"):
            nx = x0 + (w0 - self.bw) / 2
        self.pos = list(clamp_banner_xy(nx, ny, self.bw, self.bh))
        self._render_img(fast=True)
        self._place()
        self._update_label()

    def _commit(self):
        if self._resize is not None:
            self._resize = None
            self._render_img()
            self.set_state([self.pos[0], self.pos[1], self.scale])
        elif self._grab is not None:
            self._grab = None
            self.set_state([self.pos[0], self.pos[1], self.scale])

    def _reset(self):
        self.set_state(None)
        self.render()

    def _update_label(self):
        bottom = BANNER_REF_H - self.pos[1] - self.bh
        self.pos_lbl.configure(text=f"Слева {self.pos[0]} px, снизу {bottom} px (кадр 1080×1920)\n"
                                    f"Размер: {self.scale * 100:.0f}%")


class BannerOverlay(Overlay):
    """Настройки выбранного баннера (запоминаются для каждого файла отдельно)."""
    TITLE, WIDTH = "Настройки баннера", 380

    def build(self, body):
        app = self.app
        name = app.banner_var.get()
        info = probe_banner(name) if name and name != BANNER_NONE else {}
        if not info:
            label(body, "Баннер не выбран.", F(12), "on_surface_var", anchor="w").pack(fill="x")
            return
        label(body, name, F(12, True), "on_surface_var", anchor="w", wraplength=self.WIDTH - 50).pack(fill="x", pady=(0, 8))
        has_audio = bool(info.get("audio"))
        var = ctk.BooleanVar(value=has_audio and app.banner_sound_for(name))
        self._refs.append(var)

        def toggle():
            app.config_data.setdefault("banner_sound", {})[name] = bool(var.get())
            app.save_config()
        cb = checkbox(body, "Включить звук", var, toggle, F(13, True))
        cb.pack(fill="x", anchor="w")
        if not has_audio:
            cb.configure(state="disabled")
            hint = "У этого баннера нет звука." if not info.get("still") else "Картинка — звука нет."
            label(body, hint, F(11), "on_surface_var", anchor="w").pack(fill="x", padx=28, pady=(2, 0))
        kind = "картинка, " + f"{BANNER_IMAGE_SEC:.0f} с" if info.get("still") else f"длительность {info['dur']:.1f} с"
        label(body, f"{info.get('w')}×{info.get('h')}, {kind}", F(11), "outline", anchor="w").pack(fill="x", pady=(10, 0))


class UpdateOverlay(Overlay):
    TITLE = "Обновление программы"
    SCROLL_HEIGHT = 600

    def __init__(self, app):
        super().__init__(app)
        self.pbar = self.ptext = self.top = None
        self._shown_state = self._shown_version = None

    def on_close(self):
        self.pbar = self.ptext = None

    def refresh(self):
        """Смена состояния — перестраивается только верхний блок (кнопки/шкала); список изменений не трогается."""
        if not self.is_open:
            return
        u = self.app.updater
        if u.new_version != self._shown_version:
            return self.render()
        if u.state != self._shown_state or self.pbar is None:
            return self._render_top()
        self.pbar.set(u.done / u.total if u.total else 0)
        self.ptext.configure(text=self._progress_text())

    def _progress_text(self) -> str:
        u = self.app.updater
        if u.state == "ready":
            return f"Загружено {fmt_mb(u.total)} — обновление готово к установке"
        if u.state == "installing":
            return "Установка обновления — программа перезапустится..."
        base = f"{fmt_mb(u.done)} из {fmt_mb(u.total)}" if u.total else fmt_mb(u.done)
        if u.state == "paused":
            return f"{base} · на паузе"
        return f"{base} · {fmt_mb(u.speed)}/с" if u.speed > 0 else base

    def build(self, body):
        u = self.app.updater
        self._shown_version = u.new_version
        self.top = ctk.CTkFrame(body, fg_color="transparent")
        self.top.pack(fill="x")
        self._render_top()
        if not u.available:
            return
        W = self.WIDTH - 60
        log = u.changelog()
        latest = next((e for e in log if str(e.get("version")) == u.new_version), None)
        if latest:
            self._title(body, f"Что нового в версии {u.new_version}" + (f" · {latest['date']}" if latest.get("date") else ""), top=16)
            self._changes(body, latest, W)
        older = [e for e in log if parse_version(e.get("version")) < parse_version(u.new_version)]
        if older:
            self._title(body, "Предыдущие версии", top=18)
        for e in older:
            holder = ctk.CTkFrame(body, fg_color="transparent")
            holder.pack(fill="x", pady=1)
            v = str(e.get("version"))
            head = f"Версия {v}" + (f"  ·  {e['date']}" if e.get("date") else "")
            state = {"box": None, "open": False}
            btn = button(holder, f"▶  {head}", None, "ghost", anchor="w", height=30, corner_radius=10, font=F(12, True),
                         text_color=MD3["on_surface"])
            btn.configure(command=lambda e=e, holder=holder, btn=btn, head=head, st=state: self._toggle(e, holder, btn, head, st, W))
            btn.pack(fill="x")

    def _render_top(self):
        u = self.app.updater
        self._shown_state = u.state
        self.pbar = self.ptext = None
        for w in self.top.winfo_children():
            w.destroy()
        top, W = self.top, self.WIDTH - 60
        vers = ctk.CTkFrame(top, fg_color=MD3["surface_high"], corner_radius=14)
        vers.pack(fill="x", pady=(2, 10))
        for i, (cap, val, col) in enumerate((("Текущая версия", APP_VERSION, "on_surface"),
                                              ("Новая версия", u.new_version or "—", "primary"))):
            box = ctk.CTkFrame(vers, fg_color="transparent")
            box.pack(side="left", expand=True, fill="x", padx=14, pady=10)
            label(box, cap, F(11), "on_surface_var").pack()
            label(box, val, F(20, True), col).pack()
            if i == 0:
                label(vers, "→", F(20, True), "on_surface_var").pack(side="left")
        if not u.available:
            label(top, "Установлена последняя версия программы.", F(13), "on_success").pack(anchor="w", pady=6)
            return
        pkg = u.package
        if pkg.get("size"):
            kind = "только код программы" if pkg["kind"] == "patch" else "полное обновление — изменились библиотеки"
            label(top, f"Размер загрузки: {fmt_mb(pkg['size'])} ({kind})", F(11), "on_surface_var", anchor="w").pack(fill="x")
        if u.state in ("downloading", "paused", "ready", "installing"):
            self.pbar = ctk.CTkProgressBar(top, height=12, corner_radius=6, fg_color=MD3["surface_high"], progress_color=MD3["primary"])
            self.pbar.pack(fill="x", pady=(10, 4))
            self.pbar.set(1.0 if u.state in ("ready", "installing") else (u.done / u.total if u.total else 0))
            self.ptext = label(top, self._progress_text(), F(11), "on_surface_var", anchor="w")
            self.ptext.pack(fill="x")
        if u.state == "error" and u.error:
            label(top, u.error, F(12), "error", anchor="w", justify="left", wraplength=W).pack(fill="x", pady=(8, 0))
        row = ctk.CTkFrame(top, fg_color="transparent")
        row.pack(fill="x", pady=(10, 4))
        big = dict(height=38, corner_radius=19, font=F(13, True))
        if u.state in ("idle", "error"):
            button(row, f"Обновить до версии {u.new_version}", u.start, "primary", **big).pack(side="left")
        elif u.state == "downloading":
            button(row, "Пауза", u.pause, width=130, **big).pack(side="left", padx=(0, 8))
            button(row, "Прервать", u.abort, "danger", width=130, **big).pack(side="left")
        elif u.state == "paused":
            button(row, "Продолжить", u.resume, "primary", width=130, **big).pack(side="left", padx=(0, 8))
            button(row, "Прервать", u.abort, "danger", width=130, **big).pack(side="left")
        elif u.state == "ready":  # установка запускается сама; кнопка — на случай, если ждём конца рендера
            button(row, "Перезапустить и установить", self.app.install_update, "primary", **big).pack(side="left", padx=(0, 8))
        else:
            button(row, "Установка...", None, "primary", state="disabled", **big).pack(side="left")

    def _changes(self, parent, entry, width, indent=0):
        box = ctk.CTkFrame(parent, fg_color=MD3["surface_high"], corner_radius=12)
        box.pack(fill="x", padx=(indent, 0), pady=(0, 6))
        groups = entry.get("changes") or {}
        if isinstance(groups, list):
            groups = {"": groups}
        for group, items in groups.items():
            if group:
                label(box, group, F(12, True), "tertiary", anchor="w").pack(fill="x", padx=12, pady=(8, 2))
            for item in items:
                label(box, f"•  {item}", F(12), anchor="w", justify="left", wraplength=width - indent - 30).pack(fill="x", padx=(16, 12), pady=1)
        ctk.CTkFrame(box, fg_color="transparent", height=6).pack()
        return box

    def _toggle(self, entry, holder, btn, head, st, width):
        """Разворачивает версию на месте — без перестройки окна (нет «моргания»)."""
        st["open"] = not st["open"]
        btn.configure(text=f"{'▼' if st['open'] else '▶'}  {head}")
        if st["open"]:
            if st["box"] is None:
                st["box"] = self._changes(holder, entry, width, indent=18)
            else:
                st["box"].pack(fill="x", padx=(18, 0), pady=(0, 6))
        elif st["box"] is not None:
            st["box"].pack_forget()


# ---------------------------- ОКНО РЕДАКТОРА КЛИПА ----------------------------
class VideoEditorWindow(ctk.CTkToplevel):
    ADV_TEXT = "Дополнительно (Отзеркаливание, персонажи, цвета и окраска по слову)"
    SUB_RE = re.compile(r"^\s*\[?\s*(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*\]?\s*(?:\(\s*Персонаж\s*№?\s*(\d+)\s*\))?\s*(.+)$",
                        re.IGNORECASE)

    def __init__(self, app, clip: dict):
        super().__init__(app)
        self.app, self.clip = app, clip
        self.title(f"Редактировать видео — {clip['title']}")
        self.geometry("860x900")
        self.minsize(760, 680)
        self.configure(fg_color=MD3["bg"])
        self.is_dirty = self.adv_expanded = False
        self.orig_subs_text = self._format_subs_to_text(clip.get("subs", []), clip["start"])
        self.styles = json.loads(json.dumps(clip.get("speaker_styles", {})))
        self.font_size = int(clip.get("font_size", 70))
        self.word_by_word = bool(clip.get("word_by_word", False))
        self.mirror = bool(clip.get("mirror", False))
        self._build_ui()
        self.transient(app)
        self.focus()

    @staticmethod
    def _format_subs_to_text(subs, clip_start) -> str:
        out = []
        for s in subs:
            rs = max(0.0, float(s["start"]) - clip_start)
            re_ = max(rs + 0.3, float(s["end"]) - clip_start)
            out.append(f"[{rs:.1f} - {re_:.1f}] (Персонаж №{int(s.get('speaker_id', 0)) + 1}) {s.get('text', '').strip()}")
        return "\n".join(out)

    FIX_BG = "#8c1d1d"

    def _highlight_fixes(self):
        """Слова и фразы, исправленные нейросетью или словарём CS2, — красным; при наведении — что было до правки."""
        tb = self.sub_textbox
        for tag in list(getattr(self, "_fix_tags", {})):
            with suppress(Exception):
                tb.tag_delete(tag)
        self._fix_tags = {}
        lines = self.orig_subs_text.split("\n")
        for li, sub in enumerate(self.clip.get("subs", [])):
            words = sub.get("words") or []
            if li >= len(lines) or not any(w.get("orig") for w in words):
                continue
            text = sub.get("text", "").strip()
            base = len(lines[li]) - len(text)
            pos, groups = 0, []
            for w in words:
                at = text.find(w["word"], pos)
                if at < 0:
                    break
                pos = at + len(w["word"])
                if w.get("orig"):
                    if groups and groups[-1][2] == w["orig"] and groups[-1][1] >= at - 1:
                        groups[-1][1] = pos
                    else:
                        groups.append([at, pos, w["orig"], w.get("fix", "ai")])
            for a, b, orig, src in groups:
                tag = f"aifix{len(self._fix_tags)}"
                tb.tag_add(tag, f"{li + 1}.{base + a}", f"{li + 1}.{base + b}")
                tb.tag_config(tag, background=self.FIX_BG, foreground="#ffffff")
                tb.tag_bind(tag, "<Enter>", lambda e, t=tag: self._show_fix_tip(e, t))
                tb.tag_bind(tag, "<Leave>", lambda e: self._hide_fix_tip())
                self._fix_tags[tag] = (orig, src)

    def _show_fix_tip(self, event, tag):
        self._hide_fix_tip()
        orig, src = self._fix_tags.get(tag, ("", "ai"))
        who = "словарь CS2" if src == "dict" else "исправила нейросеть"
        tip = tk.Toplevel(self)
        tip.overrideredirect(True)
        with suppress(Exception):
            tip.attributes("-topmost", True)
        tk.Label(tip, text=f"Было: «{orig}»  ({who})", bg=MD3["surface_highest"] if "surface_highest" in MD3 else "#33363d",
                 fg="#ffffff", font=("Segoe UI", 10), padx=8, pady=4, bd=0).pack()
        tip.update_idletasks()
        tip.geometry(f"+{event.x_root - tip.winfo_width() // 2}+{event.y_root - tip.winfo_height() - 14}")
        self._fix_tip = tip

    def _hide_fix_tip(self):
        if self._fix_tip is not None:
            with suppress(Exception):
                self._fix_tip.destroy()
            self._fix_tip = None

    def _parse_text_to_subs(self, raw: str) -> list:
        c0 = float(self.clip["start"])
        orig = self.clip.get("subs", [])
        parsed = []
        for idx, line in enumerate(raw.splitlines()):
            line = line.strip()
            if not line:
                continue
            m = self.SUB_RE.match(line)
            if m:
                rs, txt = float(m.group(1)), m.group(4).strip()
                item = {"start": c0 + rs, "end": c0 + max(rs + 0.2, float(m.group(2))),
                        "speaker_id": max(0, int(m.group(3)) - 1 if m.group(3) else 0), "text": txt}
                if idx < len(orig) and orig[idx].get("text", "").strip() == txt:
                    item["words"] = orig[idx].get("words")
            elif idx < len(orig):
                item = {"start": orig[idx]["start"], "end": orig[idx]["end"],
                        "speaker_id": orig[idx].get("speaker_id", 0), "text": line}
            else:
                item = {"start": c0 + idx * 2.5, "end": c0 + (idx + 1) * 2.5, "speaker_id": 0, "text": line}
            parsed.append(item)
        return parsed

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        meta = card(self)
        meta.grid(row=0, column=0, padx=16, pady=(14, 6), sticky="ew")
        meta.grid_columnconfigure(1, weight=1)
        label(meta, "Название ролика:", F(12, True)).grid(row=0, column=0, padx=12, pady=(10, 4), sticky="w")
        self.yt_title_entry = entry(meta, font=F(12), corner_radius=6)
        self.yt_title_entry.grid(row=0, column=1, padx=(0, 12), pady=(10, 4), sticky="ew")
        self.yt_title_entry.insert(0, self.clip.get("yt_title", self.clip["title"]))
        self.yt_title_entry.bind("<KeyRelease>", self._on_meta_changed)
        label(meta, "Описание + хэштеги:", F(12, True)).grid(row=1, column=0, padx=12, pady=(4, 10), sticky="nw")
        self.yt_desc_box = ctk.CTkTextbox(meta, height=62, font=F(12), fg_color=MD3["surface_high"], corner_radius=10)
        self.yt_desc_box.grid(row=1, column=1, padx=(0, 12), pady=(4, 10), sticky="ew")
        self.yt_desc_box.insert("1.0", self.clip.get("yt_description", ""))
        self.yt_desc_box.bind("<KeyRelease>", self._on_meta_changed)
        label(meta, "Теги YouTube:", F(12, True)).grid(row=2, column=0, padx=12, pady=(0, 10), sticky="w")
        self.yt_tags_entry = entry(meta, font=F(12), corner_radius=6, placeholder_text="ключевые фразы через запятую")
        self.yt_tags_entry.grid(row=2, column=1, padx=(0, 12), pady=(0, 10), sticky="ew")
        if self.clip.get("yt_tags"):
            self.yt_tags_entry.insert(0, self.clip["yt_tags"])
        self.yt_tags_entry.bind("<KeyRelease>", self._on_meta_changed)

        label(self, "Субтитры клипа (формат: [сек_начала - сек_конца] (Персонаж №1) Текст):", F(13, True),
              anchor="w").grid(row=1, column=0, padx=16, pady=(4, 2), sticky="ew")
        self.sub_textbox = ctk.CTkTextbox(self, font=("Consolas", 13), fg_color=MD3["surface_container"],
                                          text_color=MD3["on_surface"], corner_radius=14, border_width=1,
                                          border_color=MD3["outline"])
        self.sub_textbox.grid(row=2, column=0, padx=16, pady=4, sticky="nsew")
        self.sub_textbox.insert("1.0", self.orig_subs_text)
        self.sub_textbox.bind("<KeyRelease>", self._on_text_modified)
        self._fix_tip = None
        with suppress(Exception):
            self._highlight_fixes()

        size_bar = ctk.CTkFrame(self, fg_color=MD3["surface_container"], corner_radius=12)
        size_bar.grid(row=3, column=0, padx=16, pady=4, sticky="ew")
        self.size_lbl = label(size_bar, f"Размер субтитров: {self.font_size} px", F(13, True), width=195, anchor="w")
        self.size_lbl.pack(side="left", padx=(14, 10), pady=8)
        slider(size_bar, 24, 128, min(128, max(24, self.font_size)), 300, self._on_size_slider).pack(side="left", padx=(0, 12), pady=8)

        self._build_banner_bar(row=4)

        adv = ctk.CTkFrame(self, fg_color=MD3["surface_container"], corner_radius=12)
        adv.grid(row=5, column=0, padx=16, pady=4, sticky="ew")
        adv.grid_columnconfigure(0, weight=1)
        self.adv_btn = button(adv, f"▶ {self.ADV_TEXT}", self._toggle_advanced, "ghost", anchor="w",
                              hover_color=MD3["surface_high"], text_color=MD3["primary"], font=F(13, True))
        self.adv_btn.grid(row=0, column=0, padx=6, pady=4, sticky="ew")
        self.adv_body = ctk.CTkFrame(adv, fg_color=MD3["surface_high"], corner_radius=10)

        flags = ctk.CTkFrame(self.adv_body, fg_color="transparent")
        flags.pack(fill="x", padx=12, pady=(8, 4))
        self.mirror_var = ctk.BooleanVar(value=self.mirror)
        checkbox(flags, "Отзеркалить видео", self.mirror_var, self._on_mirror_toggle, F(12, True)).pack(side="left", padx=(0, 24))
        self.wbw_var = ctk.BooleanVar(value=self.word_by_word)
        checkbox(flags, "Окраска по слову", self.wbw_var, self._on_wbw_toggle, F(12, True)).pack(side="left")

        self.color_buttons, self.mode_combos = {}, {}
        for sp in range(max(1, int(self.clip.get("speakers_count", 1)))):
            st = self.styles.get(str(sp), {})
            hex_col = st.get("color", speaker_hex(sp))
            mode = st.get("mode", "bg" if self.clip.get("default_bg", False) else "text")
            row = ctk.CTkFrame(self.adv_body, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=5)
            label(row, f"Персонаж №{sp + 1}", F(13, True), width=110, anchor="w").pack(side="left", padx=(4, 6))
            fem_var = ctk.BooleanVar(value=bool(st.get("is_female")))
            checkbox(row, "Жен.", fem_var, lambda i=sp, v=fem_var: self._on_gender_toggle(i, v.get()),
                     F(12)).pack(side="left", padx=(0, 12))
            cb = tk.Button(row, bg=hex_col, activebackground=hex_col, width=4, height=1, relief="solid", bd=1,
                           cursor="hand2", command=lambda i=sp: self._pick_speaker_color(i))
            cb.pack(side="left", padx=(0, 14))
            self.color_buttons[sp] = cb
            label(row, "Окрашивать:").pack(side="left", padx=(0, 8))
            mc = combo(row, ["Субтитры", "Задний фон"], "Задний фон" if mode == "bg" else "Субтитры", 155,
                       fg_color=MD3["surface_container"], command=lambda ch, i=sp: self._on_speaker_mode_change(i, ch))
            if self.word_by_word:
                mc.configure(state="disabled")
            mc.pack(side="left", padx=(0, 8))
            self.mode_combos[sp] = mc

        bottom = ctk.CTkFrame(self, fg_color="transparent")
        bottom.grid(row=6, column=0, padx=16, pady=(6, 14), sticky="ew")
        bottom.grid_columnconfigure(0, weight=1)
        self.save_btn = button(bottom, "Сохранить и перерендерить", self._save_and_rerender, "primary", height=44,
                               corner_radius=22, font=F(14, True))
        self.save_btn.configure(**DISABLED_BTN)
        self.save_btn.grid(row=0, column=0, sticky="ew")

    def _on_meta_changed(self, _e=None):
        self.clip["yt_title"] = self.yt_title_entry.get().strip()
        self.clip["yt_description"] = self.yt_desc_box.get("1.0", tk.END).strip()
        self.clip["yt_tags"] = self.yt_tags_entry.get().strip()
        self.app._save_gallery_db()

    def _on_size_slider(self, val):
        sz = int(round(val))
        self.size_lbl.configure(text=f"Размер субтитров: {sz} px")
        if sz != int(self.clip.get("font_size", 70)):
            self.font_size = sz
            self._mark_dirty()

    def _on_mirror_toggle(self):
        self.mirror = bool(self.mirror_var.get())
        self._mark_dirty()

    def _on_wbw_toggle(self):
        self.word_by_word = bool(self.wbw_var.get())
        for sp, mc in self.mode_combos.items():
            if self.word_by_word:
                mc.set("Субтитры")
            mc.configure(state="disabled" if self.word_by_word else "normal")
            if str(sp) in self.styles:
                self.styles[str(sp)]["mode"] = "word" if self.word_by_word else "text"
        self._mark_dirty()

    def _toggle_advanced(self):
        self.adv_expanded = not self.adv_expanded
        self.adv_btn.configure(text=f"{'▼' if self.adv_expanded else '▶'} {self.ADV_TEXT}")
        if self.adv_expanded:
            self.adv_body.grid(row=1, column=0, padx=8, pady=(2, 8), sticky="ew")
        else:
            self.adv_body.grid_remove()

    def _mark_dirty(self):
        self.is_dirty = True
        self.save_btn.configure(state="normal", **BTN_STYLES["primary"])

    def _on_text_modified(self, _e=None):
        if self.sub_textbox.get("1.0", tk.END).strip() != self.orig_subs_text.strip():
            self._mark_dirty()
        elif not self.is_dirty:
            self.save_btn.configure(**DISABLED_BTN)

    def _pick_speaker_color(self, sp: int):
        cur = self.styles.get(str(sp), {}).get("color", speaker_hex(sp))
        chosen = colorchooser.askcolor(color=cur, title=f"Выберите цвет для Персонажа №{sp + 1}", parent=self)
        if chosen and chosen[1]:
            self._set_speaker_color(sp, chosen[1])
            self._mark_dirty()

    def _set_speaker_color(self, sp: int, hex_col: str):
        self.styles.setdefault(str(sp), {})["color"] = hex_col
        self.color_buttons[sp].configure(bg=hex_col, activebackground=hex_col)

    def _on_gender_toggle(self, sp: int, is_female: bool):
        """Ручная правка пола: персонаж перекрашивается в женскую/мужскую палитру."""
        st = self.styles.setdefault(str(sp), {"color": speaker_hex(sp), "mode": "word" if self.word_by_word else "text"})
        st["is_female"] = bool(is_female)
        fem_before = sum(1 for k, v in self.styles.items() if v.get("is_female") and int(k) < sp)
        self._set_speaker_color(sp, FEMALE_SPEAKER_HEX[fem_before % len(FEMALE_SPEAKER_HEX)] if is_female else speaker_hex(sp))
        self._mark_dirty()

    def _on_speaker_mode_change(self, sp: int, choice: str):
        if self.word_by_word:
            return
        self.styles.setdefault(str(sp), {"color": speaker_hex(sp)})["mode"] = "bg" if choice == "Задний фон" else "text"
        self._mark_dirty()

    # --- баннер клипа ---
    BANNER_GREEN, TRACK_H = "#4CAF50", 26

    def _build_banner_bar(self, row: int):
        self.clip_dur = max(0.5, float(self.clip["end"]) - float(self.clip["start"]))
        b = dict(self.clip.get("banner") or {})
        self.banner = b if b.get("file") else None
        bar = ctk.CTkFrame(self, fg_color=MD3["surface_container"], corner_radius=12)
        bar.grid(row=row, column=0, padx=16, pady=4, sticky="ew")
        top = ctk.CTkFrame(bar, fg_color="transparent")
        top.pack(fill="x", padx=14, pady=(8, 4))
        label(top, "Баннер:", F(13, True)).pack(side="left", padx=(0, 10))
        names = [BANNER_NONE] + list_banners()
        if self.banner and self.banner["file"] not in names:
            names.append(self.banner["file"])
        self.banner_sel = tk.StringVar(value=self.banner["file"] if self.banner else BANNER_NONE)
        combo(top, names, self.banner_sel.get(), 240, variable=self.banner_sel, corner_radius=8, height=30,
              command=lambda _v: self._on_banner_select()).pack(side="left")
        self.banner_sound_var = ctk.BooleanVar(value=bool(self.banner and self.banner.get("sound")))
        self.banner_sound_cb = checkbox(top, "Включить звук баннера", self.banner_sound_var, self._on_banner_sound, F(12, True))
        self.banner_time_lbl = label(top, "", F(12), "on_surface_var")
        self.banner_time_lbl.pack(side="right")
        self.banner_row2 = ctk.CTkFrame(bar, fg_color="transparent")
        self.banner_over_var = ctk.BooleanVar(value=bool(self.banner.get("over_subs")) if self.banner
                                              else bool(self.app.config_data.get("banner_over_subs", False)))
        checkbox(self.banner_row2, "Поверх субтитров", self.banner_over_var, self._on_banner_over, F(12, True)).pack(side="left")
        self.banner_pos_overlay = BannerPositionOverlay(
            self, lambda: ((self.banner or {}).get("file", BANNER_NONE), (self.banner or {}).get("xy")), self._on_banner_xy)
        button(self.banner_row2, "Положение", self.banner_pos_overlay.open, "surface", width=110, height=30,
               corner_radius=15, font=F(12, True)).pack(side="left", padx=(16, 0))
        self.timeline = tk.Canvas(bar, height=self.TRACK_H, bg=MD3["surface_container"], highlightthickness=0, bd=0,
                                  cursor="hand2")
        self.timeline.pack(fill="x", padx=14, pady=(2, 10))
        self.timeline.bind("<Configure>", lambda _e: self._draw_timeline())
        self.timeline.bind("<ButtonPress-1>", self._tl_press)
        self.timeline.bind("<B1-Motion>", self._tl_drag)
        self._drag_dx = None
        self._sync_banner_controls()

    def _banner_info(self) -> dict:
        return probe_banner(self.banner["file"]) if self.banner else {}

    def _sync_banner_controls(self):
        info = self._banner_info()
        if self.banner:
            self.banner["dur"] = round(float(info.get("dur", self.banner.get("dur", BANNER_IMAGE_SEC))), 2)
            self.banner_sound_cb.pack(side="left", padx=(16, 0))
            self.banner_sound_cb.configure(state="normal" if info.get("audio") else "disabled")
            if not info.get("audio"):
                self.banner_sound_var.set(False)
            self.banner_row2.pack(fill="x", padx=14, pady=(2, 4))
            self.timeline.pack(fill="x", padx=14, pady=(2, 10))
        else:
            self.banner_sound_cb.pack_forget()
            self.banner_row2.pack_forget()
            self.timeline.pack_forget()
        self._draw_timeline()

    def _on_banner_select(self):
        name = self.banner_sel.get()
        if name == BANNER_NONE:
            self.banner = None
        else:
            info = probe_banner(name)
            dur = float(info.get("dur", BANNER_IMAGE_SEC))
            if self.banner:  # сохраняется только начало баннера, выбранное пользователем
                start = float(self.banner.get("start", 0))
            else:
                pos = self.app.config_data.get("banner_pos", "middle")
                start = banner_auto_start(self.clip_dur, dur, pos)
            sound = bool(info.get("audio")) and self.app.banner_sound_for(name)
            old = self.banner or {}
            xy = old.get("xy") if old else (self.app.config_data.get("banner_xy") or {}).get(name)
            self.banner = {"file": name, "start": round(max(0.0, min(start, self.clip_dur - 0.5)), 2), "sound": sound,
                           "dur": round(dur, 2), "xy": xy, "over_subs": bool(self.banner_over_var.get())}
            self.banner_sound_var.set(sound)
        self._sync_banner_controls()
        self._mark_dirty()

    def _on_banner_over(self):
        if self.banner:
            self.banner["over_subs"] = bool(self.banner_over_var.get())
            self._mark_dirty()

    def _on_banner_xy(self, xy):
        if self.banner:
            self.banner["xy"] = banner_xy_value(xy)
            self._mark_dirty()

    def _on_banner_sound(self):
        if self.banner:
            self.banner["sound"] = bool(self.banner_sound_var.get())
            self._mark_dirty()

    def _tl_geom(self):
        w = max(40, self.timeline.winfo_width())
        return 4, w - 4  # x0, x1 полосы клипа

    def _draw_timeline(self):
        c = self.timeline
        c.delete("all")
        if not self.banner:
            self.banner_time_lbl.configure(text="")
            return
        x0, x1 = self._tl_geom()
        h = self.TRACK_H
        c.create_rectangle(x0, h * 0.30, x1, h * 0.70, fill=MD3["surface_highest"], outline="")
        k = (x1 - x0) / self.clip_dur
        st, dur = float(self.banner["start"]), float(self.banner.get("dur", BANNER_IMAGE_SEC))
        bx0, bx1 = x0 + st * k, x0 + min(self.clip_dur, st + dur) * k
        c.create_rectangle(bx0, 2, max(bx0 + 6, bx1), h - 2, fill=self.BANNER_GREEN, outline="#81C784", tags="banner")
        end = min(self.clip_dur, st + dur)
        self.banner_time_lbl.configure(text=f"{st:.1f} – {end:.1f} с из {self.clip_dur:.1f} с")

    def _tl_press(self, e):
        if not self.banner:
            return
        x0, x1 = self._tl_geom()
        k = (x1 - x0) / self.clip_dur
        bx0 = x0 + float(self.banner["start"]) * k
        bx1 = x0 + min(self.clip_dur, float(self.banner["start"]) + float(self.banner.get("dur", 0))) * k
        self._drag_dx = e.x - bx0 if bx0 - 2 <= e.x <= max(bx0 + 6, bx1) + 2 else None

    def _tl_drag(self, e):
        if not self.banner or self._drag_dx is None:
            return
        x0, x1 = self._tl_geom()
        t = (e.x - self._drag_dx - x0) / ((x1 - x0) / self.clip_dur)
        dur = float(self.banner.get("dur", 0))
        hi = max(0.0, self.clip_dur - dur) if dur < self.clip_dur else 0.0
        self.banner["start"] = round(max(0.0, min(t, hi)), 2)
        self._draw_timeline()
        self._mark_dirty()

    def _save_and_rerender(self):
        if self.app.is_running:
            messagebox.showwarning("Процесс в работе", "Дождитесь окончания текущей обработки или остановите её.", parent=self)
            return
        self._on_meta_changed()
        subs = self._parse_text_to_subs(self.sub_textbox.get("1.0", tk.END))
        count = max([int(self.clip.get("speakers_count", 1))] + [s["speaker_id"] + 1 for s in subs])
        default_mode = "word" if self.word_by_word else ("bg" if self.clip.get("default_bg") else "text")
        for sp in range(count):  # новые «Персонаж №N», вписанные вручную, получают свой цвет
            self.styles.setdefault(str(sp), {"color": speaker_hex(sp), "mode": default_mode, "is_female": False})
        self.clip.update(subs=subs, speaker_styles=self.styles, speakers_count=count, font_size=self.font_size,
                         word_by_word=self.word_by_word, mirror=self.mirror,
                         banner=dict(self.banner) if self.banner else None)
        self.app._save_gallery_db()
        self.save_btn.configure(text="Идет перерендер видео...", **DISABLED_BTN)
        self.app.rerender_single_clip(self.clip, on_done=self._on_rerender_finished)

    def _on_rerender_finished(self, ok: bool):
        if not self.winfo_exists():
            return
        self.save_btn.configure(text="Сохранить и перерендерить")
        if ok:
            self.orig_subs_text = self._format_subs_to_text(self.clip.get("subs", []), self.clip["start"])
            self.is_dirty = False
            self.save_btn.configure(**DISABLED_BTN)
            messagebox.showinfo("Готово", f"Видео «{self.clip['title']}» успешно обновлено!", parent=self)
        else:
            self._mark_dirty()


# ---------------------------- ГЛАВНОЕ ОКНО ----------------------------
MODES = {"clips": "Нарезки", "cs2": "CS2"}
MODE_PARAM_DEFAULTS = {k: DEFAULT_CONFIG[k] for k in ("whisper_size", "max_clips", "sub_font", "sub_size", "sub_bg",
                                                 "sub_word_by_word", "sub_mirror", "sub_female_colors", "min_clip_sec",
                                                 "max_clip_sec", "sub_fix")}
MAX_CLIP_LO, MAX_CLIP_HI = 10, 300   # максимальная длительность клипа: от 10 с до 5 мин (по умолчанию 1 мин)


def fmt_dur(sec: int) -> str:
    m, s_ = divmod(int(sec), 60)
    return f"{s_} сек" if not m else (f"{m} мин" if not s_ else f"{m} мин {s_} сек")


def fit_clip_end(start: float, end: float, max_sec: float, min_sec: float, chunks: list) -> float:
    """Конец слишком длинного клипа: по концу последней фразы, которая успевает до предела (не раньше минимума)."""
    if end - start <= max_sec + 0.05:
        return end
    lim = start + max_sec
    ends = [float(c["end"]) for c in chunks or [] if start + min_sec <= float(c["end"]) <= lim]
    return round(max(ends) if ends else lim, 2)
# ---------------------------- СЛОВАРЬ CS2 ----------------------------
# Ники игроков и названия команд — латиницей (как пишут на HLTV), термины — по-русски. Составы — топ-40 мирового
# рейтинга Valve на 2 ноября 2026 (github.com/ValveSoftware/counter-strike_regional_standings).
# Строка: «Как пишется: как слышится, как слышится, ...». Слова из обычной речи («мир», «док», «молодой»)
# не добавлены — их распознанный текст не трогаем; такие ники правит только нейросеть по контексту.
CS2_NAMES = """
MOUZ: маус, мауз, мауса, маузы | Spinx: спинкс, спинкса | torzsi: торжи, торши, торзи | xelex: кселекс, зелекс
xertioN: ксертион, ксершн, ксершен, кершн
Vitality: виталити | flameZ: флеймз, флеймс, флеймзи | jL: джейэл, джей-эл, джей эл | mezii: мези, мезий, мезии
ropz: ропз, ропс, ропза | ZywOo: зайву, зайвуу, зиву, зайвуя, зайвоо
FURIA: фуриа, фурия, фурии, фурию, фурией | FalleN: фаллен, фален, фолен, фоллен | KSCERATO: кайсерато, кейсерато, ксерато
YEKINDAR: екиндар, йекиндар, екиндер, екиндара | yuurih: юрих, юри, юрии
Aurora: аврора, авроры, аврору, авророй | Jimpphat: джимпфат, джимфат, джимпат | kyxsan: киксан, кексан
Wicadia: викадиа, викадия, викадии | woxic: воксик, воксика | XANTARES: ксантарес, зантарес, хантарес, ксантареса
Spirit: спирит, спирита, спириты | donk: донк, донка, донку, донком, донке | magixx: магикс, мэджикс, маджикс
sh1ro: широ, шайро | tN1R: тнир, тинир, тэнир, тинайр, тиэнайр | zont1x: зонтикс, зонтикса
BetBoom: бетбум, бетбума, бетбумы | Boombl4: бумбл, бумбла, бумблы | d1Ledez: дилидез, дайледез, диледез, диледеза
Magnojez: магноджез, магножез | S1ren: сайрен, сайрена | zorte: зорте, зорта
Falcons: фалконс, фолконс, фалькон, фалконсы | karrigan: карриган, кариган, каригана, карригана | kyousuke: киосуке, кьюсуке
m0NESY: монеси, монези, манеси, монесик | NiKo: нико | TeSeS: тесес, тессес
cmtry: симетри, сиэмтри | dziugss: джюгс, дзюгс, джугас | Krabeni: крабени | xfl0ud: иксфлауд, флауд
Legacy: легаси | dumau: думау, дюмау | latto: латто, лато | n1ssim: ниссим, нисим
Nemiga: немига, немиги, немигу | KaiR0N-: кайрон, кайрона | robo: робо | syph0: сайфо, сифо | Xant3r: ксантер, зантер
G2: джиту, джи-ту, джи ту | HeavyGod: хевигод, хэвигод, хевигода | huNter-: хантер, хантера | MATYS: матис, матыс
NertZ: нертз, нерц | r1nkle: ринкл, ринкле
1win: ванвин, ван-вин, ван вин | ArtFr0st: артфрост | Ax1Le: аксайл, аксиле | BELCHONOKK: бельчонок, бельчонка
nafany: нафани, нафаня
NAVI: нави, натус, натусы | Aleksib: алексиб, алексиба | iM: айэм, ай-эм, ай эм | makazze: маказзе, маказе
w0nderful: вондерфул, вандерфул, вондерфула
Astralis: астралис, астралиса | jabbi: джабби, джаби | phzy: физи | ryu: рю | siuhy: сиухи, сюхи | Staehr: стэйр, стаер
NIP: нип, нипы | adamb: адамб | Krimbo: кримбо | sjuush: сьюш, сйуш | stavn: ставн, стафн | xKacpersky: качперски, кацперски
PARIVISION: паривижн, паривижен, паривиженов | FL1T: флит, флита | HObbit: хоббит, хоббита | Jame: джейм, джейма, жаме
xiELO: ксиело, сиело | zweih: цвай, звейх
The MongolZ: монголз, монголс | bLitz: блиц, блица | cobrazera: кобразера | nin9: найн
HEROIC: хероик, героик, хероика | Brollan: броллан, бролан | Chr1zN: крайзен, кризн | MartinezSa: мартинез, мартинеза
nilo: нило | susp: сусп
MIBR: мибр | insani: инсани | tomaszin: томасин | venomzera: веномзера
FaZe: фейз, фейза, фейзы | frozen: фрозен, фрозена | jcobbb: джейкоб, джекоб | Neityu: нейтью | Twistzz: твистз, твистс
Liquid: ликвид, ликвида | EliGE: элайдж, элидж | Jorko: йорко | JT: джейти, джей ти | NAF: наф, нафа
Eternal Fire: этернал, этернал файр | jottAAA: джотта, йотта | Kvem: квем | MisteM: мистем | regali: регали | soulfly: соулфлай
Gizmy: гизми | rain: рейн, рейна | sirah: сира
HUASOPEEK: хуасопик | luchov: лучов | meyern: мейерн
Swisher: свишер | Lake: лейк | s1n: син
HOTU: хоту | frontales: фронталес | kade0: кадео | mizu: мизу | n0rb3r7: норберт, норберта
fnatic: фнатик, фнатика | cairne: кейрн | fEAR: фир | jackasmo: джекасмо | jambo: джамбо | mazay: мазай
esenthial: эсеншиал | kensizor: кенсизор | s1zzi: сиззи
DENDELE: денделе | gafolo: гаффоло, гафоло | maxxkor: макскор | rdnzao: рднзао
Inner Circle: иннер | headtr1ck: хедтрик | onic: оник | zeRRoFIX: зерофикс
Virtus.pro: виртус, виртусы, вэпэ, випи | b1st: бист | Patsi: патси | tO0RO: торо
s1mple: симпл, симпла | electroNic: электроник, электроника | Perfecto: перфекто
"""
# термины — по-русски: латинское написание Whisper → русское
CS2_TERMS = {
    "ace": "эйс", "clutch": "клатч", "clutched": "заклатчил", "eco": "эко", "force": "форс", "retake": "ретейк",
    "plant": "плент", "defuse": "дефуз", "entry": "энтри", "lurk": "лурк", "awp": "АВП", "awper": "авпер",
    "deagle": "дигл", "smoke": "смок", "flash": "флешка", "molotov": "молотов", "headshot": "хедшот", "frag": "фраг",
    "overtime": "овертайм", "rush": "раш", "timing": "тайминг", "spray": "спрей", "peek": "пик", "jiggle": "джигл",
    "one-tap": "ван-тап", "onetap": "ван-тап", "wallbang": "волбэнг", "noscope": "ноускоп", "save": "сейв",
}
CS2_TERMS_RU = ("эйс, клатч, клатчер, раскидка, флешка, смок, молотов, хаешка, АВП, авпер, дигл, эко, форс, фулбай, "
                "пистолетка, ретейк, плент, дефуз, энтри, лурк, раш, тайминг, хедшот, ван-тап, фраг, овертайм, "
                "спрей, пик, сейв, мид, банан, лонг, шорт, Мираж, Инферно, Нюк, Даст 2, Анубис, Эншент, Оверпасс, Трейн")


def _norm_word(w: str) -> str:
    return re.sub(r"[^\w-]", "", w.lower().replace("ё", "е")).strip("-")


def _norm_latin(w: str) -> str:
    return _norm_word(w).translate(str.maketrans("013457", "oieast")).replace("-", "")


@lru_cache(maxsize=1)
def cs2_dictionary():
    """{как слышится (1–2 слова, нормализовано): как пишется} и {латиница без цифр: как пишется}."""
    spoken, latin = {}, {}
    for part in re.split(r"[|\n]", CS2_NAMES):
        if ":" not in part:
            continue
        name, aliases = (x.strip() for x in part.split(":", 1))
        latin[_norm_latin(name)] = name
        for a in aliases.split(","):
            a = " ".join(_norm_word(x) for x in a.split())
            if a:
                spoken[a] = name
    return spoken, latin


def cs2_names() -> list:
    return sorted(set(cs2_dictionary()[1].values()), key=str.lower)


def apply_cs2_dictionary(chunks: list) -> int:
    """Ники и команды — латиницей, термины — по-русски, прямо в словах субтитров (с пометкой «было»).
    Возвращает число замен. Окончание падежа у ника отбрасывается («донка» → «donk»)."""
    spoken, latin = cs2_dictionary()
    n = 0
    for ch in chunks:
        words = ch.get("words")
        if not words:
            continue
        i = 0
        while i < len(words):
            w = words[i]
            raw = w["word"]
            lead = re.match(r"^\W*", raw).group(0)
            trail = re.search(r"[^\w-]*$", raw).group(0)
            core = _norm_word(raw)
            new, span = None, 1
            if i + 1 < len(words):  # двухсловные («джей эл», «ван вин»)
                two = core + " " + _norm_word(words[i + 1]["word"])
                if two in spoken:
                    new, span = spoken[two], 2
                    trail = re.search(r"[^\w-]*$", words[i + 1]["word"]).group(0)
            if new is None and core:
                if core in spoken:
                    new = spoken[core]
                elif re.fullmatch(r"[a-z0-9-]+", core) and _norm_latin(core) in latin:
                    new = latin[_norm_latin(core)]
                    if new == raw.strip(".,!?;:…«»\"'()"):
                        new = None
                elif re.fullmatch(r"[a-z-]+", core) and core in CS2_TERMS:
                    new = CS2_TERMS[core]
                    if raw.lstrip("«\"'(")[:1].isupper():
                        new = new[:1].upper() + new[1:]
            if new:
                orig = " ".join(x["word"] for x in words[i:i + span])
                fixed = lead + new + trail
                if fixed != orig:
                    words[i:i + span] = [{"word": fixed, "start": words[i]["start"], "end": words[i + span - 1]["end"],
                                          "orig": orig, "fix": "dict"}]
                    n += 1
            i += 1
        ch["text"] = " ".join(x["word"] for x in words)
    return n


# ---------------------------- ИСПРАВЛЕНИЕ СУБТИТРОВ НЕЙРОСЕТЬЮ ----------------------------
# Нейросеть присылает только точечные правки «строка, было → стало». Программа применяет правку, лишь если она мелкая:
# те же 1–3 слова той же строки, похожее написание (окончание, пара букв) или ник/термин из словаря. Слова не
# переносятся между строками и не переставляются — субтитры остаются синхронными с речью.
SUBFIX_MAX_PER_LINE = 2
SUBFIX_SCENE_GAP = 1.5   # пауза длиннее — возможно, другая сцена (нейросеть получает пометку)


def _fix_similar(a: str, b: str) -> bool:
    from difflib import SequenceMatcher
    a, b = _norm_word(a.replace(" ", "")), _norm_word(b.replace(" ", ""))
    if not a or not b or a == b:
        return False
    pre = len(os.path.commonprefix([a, b]))
    return SequenceMatcher(None, a, b).ratio() >= 0.6 or (pre >= 3 and abs(len(a) - len(b)) <= 4)


def apply_sub_fix(words: list, frm: str, to: str, glossary: set) -> bool:
    """Применяет одну правку к словам строки (с пометкой «было»). False — правка отклонена."""
    ft, tt = frm.split(), to.split()
    if not (1 <= len(ft) <= 3 and 1 <= len(tt) <= 3 and abs(len(ft) - len(tt)) <= 1):
        return False
    key = [_norm_word(x) for x in ft]
    n = len(ft)
    for i in range(len(words) - n + 1):
        if [_norm_word(w["word"]) for w in words[i:i + n]] != key:
            continue
        span = words[i:i + n]
        in_gloss = _norm_latin(to) in glossary or _norm_word(to) in glossary
        if not (in_gloss or _fix_similar(frm, to)):
            return False
        lead = re.match(r"^\W*", span[0]["word"]).group(0)
        trail = re.search(r"[^\w-]*$", span[-1]["word"]).group(0)
        tt[0] = lead + tt[0].lstrip("«\"'(") if lead else tt[0]
        if not re.search(r"[.,!?;:…»\")]$", tt[-1]):
            tt[-1] += trail
        if len(tt) == n:  # пословно: помечаются только реально изменённые слова
            changed = False
            for k, (w, t) in enumerate(zip(span, tt)):
                if t != w["word"]:
                    words[i + k] = {**w, "word": t, "orig": w.get("orig") or w["word"], "fix": "ai"}
                    changed = True
            return changed
        orig = " ".join(w.get("orig") or w["word"] for w in span)
        t0, t1 = span[0]["start"], span[-1]["end"]
        step = (t1 - t0) / len(tt)
        words[i:i + n] = [{"word": t, "start": round(t0 + k * step, 3), "end": round(t0 + (k + 1) * step, 3),
                           "orig": orig, "fix": "ai"} for k, t in enumerate(tt)]
        return True
    return False


def subfix_prompt(chunks: list, cs2: bool) -> str:
    rows, prev = [], None
    for i, ch in enumerate(chunks, 1):
        if prev is not None and ch["start"] - prev > SUBFIX_SCENE_GAP:
            rows.append("--- пауза (дальше может быть другая сцена) ---")
        rows.append(f"{i}. {ch.get('text', '').strip()}")
        prev = ch["end"]
    gloss = (f"Это трансляция матча Counter-Strike 2. Ники и команды пиши латиницей, как на HLTV: {', '.join(cs2_names())}. "
             f"Термины пиши по-русски: {CS2_TERMS_RU}.\n") if cs2 else ""
    return (
        "Ниже автоматические субтитры (распознавание речи). Найди только явные ошибки распознавания: неверные "
        "окончания и согласование (род, число, падеж), неправильно услышанные слова, ники и названия. "
        "Строки — подряд идущие фразы видео; между ними могут быть смены сцен, поэтому не связывай по смыслу "
        "далёкие строки и не переноси слова между строками.\n"
        "Правила: исправляй 1–3 слова за раз, не переписывай фразы, не меняй стиль, сленг, мат и разговорные слова, "
        "не добавляй и не убирай знаки препинания ради красоты. Если сомневаешься — не исправляй. "
        "Если ошибок нет — верни [].\n" + gloss +
        "Верни СТРОГО JSON-массив правок без лишнего текста: "
        '[{"line": 3, "from": "слово как в строке", "to": "исправленное слово"}]\n\nСубтитры:\n' + "\n".join(rows))


CS2_PROMPT = (
    "Это трансляция матча Counter-Strike 2 (стрим или каст). Лучшие моменты: эйсы и мульти-киллы, клатчи, "
    "решающие и переломные раунды, невероятные выстрелы, ошибки и смешные ситуации, самые эмоциональные реакции "
    "стримера или кастеров. Клип начинай чуть раньше начала действия (за 3–5 секунд), чтобы зритель понял ситуацию, "
    "и заканчивай после реакции. В названии и тегах используй имена игроков, команд, карты и турнира, "
    "если они звучат в речи. Ники игроков и названия команд пиши латиницей, как на HLTV ("
    + ", ".join(cs2_names()) + "), термины — по-русски.\n\n")


class ClipsStudioSK(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f"Clips Studio AI — v{APP_VERSION}")
        self.geometry("1320x860")
        self.minsize(1060, 640)
        self.configure(fg_color=MD3["bg"])

        self.config_data = self.load_config()
        NN_ENABLED.update(voice=bool(self.config_data.get("nn_voice", True)), face=bool(self.config_data.get("nn_face", True)),
                          vgender=bool(self.config_data.get("nn_vgender", True)))
        self._restore_window()
        self.is_running = self.cancel_requested = False
        self._active_subprocesses = []
        self._subproc_lock = threading.Lock()
        self._balance_gen = 0

        self.current_transcript_text = ""
        self.transcript_popup = None
        self.speaker_tracker = ActiveSpeakerTracker()  # Ленивый: не грузит XML при старте
        self.yt_bypass = YouTubeBypass(self)

        hidden = read_json(HIDDEN_CLIPS_FILE, [])
        self.hidden_clip_paths = {str(Path(p).resolve()) for p in (hidden if isinstance(hidden, list) else [])}
        self.created_clips = []
        self.clip_time_expanded = self._gallery_switch_pending = False
        self._current_grid_cols = 0
        self._resize_after_id = None
        self._tiles = {}               # путь → (подпись, плитка): галерея обновляется по одной плитке
        self._gallery_tab = "Готовые клипы"

        self.selected_clip_paths = set()
        self.tile_widgets_map = {}
        self._lasso_start_root = self._lasso_popup = None
        self._lasso_moved = False

        self.drive = GoogleDrive()
        self.updater = Updater(lambda: self.after(0, self._on_update_state))
        self.settings = SettingsOverlay(self)
        self.updates_overlay = UpdateOverlay(self)
        self.drive_wizard = DriveSetupWizard(self)
        self.banner_overlay = BannerOverlay(self)
        self.player = ClipPlayer(self)
        self.overlays = (self.settings, self.updates_overlay, self.drive_wizard, self.banner_overlay, self.player)
        self.yt_state = self._load_yt_accounts()
        self._yt_avatar_refs = []

        self.protocol("WM_DELETE_WINDOW", self._on_close_window_request)
        self.bind_all("<ButtonPress>", Popover.on_global_click, "+")
        self.bind("<ButtonPress>", Popover.on_global_click, "+")
        self._enable_russian_clipboard()
        self._build_ui()

        self.after(150, self._load_existing_clips_async)  # галерея — в фоне, после отрисовки окна
        self.after(STARTUP_BALANCE_DELAY_MS, self._startup_balance_check)  # баланс — через ~4 сек после старта
        self.after(UPDATE_FIRST_CHECK_MS, self._auto_check_updates)         # обновления — через 10 сек, затем раз в 15 мин
        self.bind("<Configure>", self._on_window_resize)
        self.after(180000, self._periodic_folder_sync)

    # --- СОСТОЯНИЕ «ИДЁТ РАБОТА», КНОПКА СТОП И ЗАЩИТА ОТ ЗАКРЫТИЯ ---
    def _register_subproc(self, proc):
        with self._subproc_lock:  # регистрируют сразу несколько параллельных рендеров
            self._active_subprocesses = [p for p in self._active_subprocesses if p.poll() is None] + [proc]

    def _terminate_active_subprocesses(self):
        for p in self._active_subprocesses:
            with suppress(Exception):
                if p and p.poll() is None:
                    p.terminate()
                    p.kill()
        self._active_subprocesses.clear()

    def _check_cancel(self):
        if self.cancel_requested:
            raise Cancelled()

    def _cancellable(self, fn, *args, **kwargs):
        """Выполняет блокирующий вызов в отдельном потоке, чтобы «Остановить» срабатывало сразу."""
        box = {}

        def _w():
            try:
                box["r"] = fn(*args, **kwargs)
            except BaseException as e:
                box["e"] = e

        t = threading.Thread(target=_w, daemon=True)
        t.start()
        while t.is_alive():
            t.join(0.2)
            self._check_cancel()
        if "e" in box:
            raise box["e"]
        return box.get("r")

    def _sleep_cancellable(self, sec: float):
        for _ in range(int(sec / 0.2)):
            self._check_cancel()
            time.sleep(0.2)

    def _begin_job(self, busy_text: str):
        self.is_running, self.cancel_requested = True, False
        self.start_btn.configure(state="disabled", text=busy_text)
        self.stop_btn.configure(state="normal", text="■  СТОП")
        self.stop_btn.grid()

    def _end_job(self):
        """Вызывается из рабочего потока по завершении задачи."""
        self.is_running = False

        def _ui():
            self.start_btn.configure(state="normal", text="▶   ЗАПУСТИТЬ НАРЕЗКУ")
            self.stop_btn.grid_remove()
            if getattr(self, "_auto_install", False) and self.updater.state == "ready":
                self.after(1500, lambda: self.install_update(auto=True))
        self.after(0, _ui)

    def _confirm_abort(self, closing: bool) -> bool:
        if closing:
            return ask_yes_no(self, "Процесс в работе",
                              "Сейчас идёт обработка или рендер видео!\n\nЗакрытие программы остановит текущий процесс, "
                              "и весь прогресс будет утерян.\n\nВы действительно хотите закрыть программу?")
        return ask_yes_no(self, "Остановить процесс?",
                          "Сейчас идёт обработка или рендер видео!\n\nПри отмене весь текущий прогресс будет утерян "
                          "(незавершённый клип не сохранится).\n\nВы действительно хотите остановить процесс?")

    def _on_stop_request(self):
        if not self.is_running or self.cancel_requested:
            return
        if self._confirm_abort(closing=False) and self.is_running:
            self.cancel_requested = True
            self.stop_btn.configure(state="disabled", text="Остановка...")
            self._terminate_active_subprocesses()
            self.log("[!] Остановка процесса по запросу пользователя...")

    # --- ОКНО: размер, положение, развёрнутость ---
    def _window_state_now(self) -> dict:
        st = {"zoomed": False}
        with suppress(Exception):
            st["zoomed"] = self.state() == "zoomed"
            if not st["zoomed"] and self.state() == "normal":
                st["geometry"] = self.geometry()
            elif getattr(self, "_normal_geometry", None):
                st["geometry"] = self._normal_geometry
        return st

    def _remember_normal_geometry(self, _e=None):
        with suppress(Exception):
            if self.state() == "normal":
                self._normal_geometry = self.geometry()  # обычный размер — чтобы вернуться к нему из развёрнутого

    def _restore_window(self):
        win = self.config_data.get("window") or {}
        m = re.fullmatch(r"(\d+)x(\d+)([+-]-?\d+)([+-]-?\d+)", str(win.get("geometry", "")))
        if m:
            w, h, x, y = int(m[1]), int(m[2]), int(m[3]), int(m[4])
            left, top, right, bottom = monitor_work_area(self, x + 60, y + 20)
            if left - 40 <= x <= right - 120 and top - 10 <= y <= bottom - 80:  # окно на видимом мониторе
                self.geometry(f"{max(1060, w)}x{max(640, h)}{m[3]}{m[4]}")
            else:
                self.geometry(f"{max(1060, w)}x{max(640, h)}")
        self._normal_geometry = self.geometry() if m else None
        if win.get("zoomed"):
            self.after(30, lambda: self.state("zoomed"))
        self.bind("<Configure>", lambda e: e.widget is self and self._remember_normal_geometry(), add="+")

    def _stop_and_save(self):
        """Перед выходом: остановить обработку (если идёт) и сохранить настройки с окном."""
        if self.is_running:
            self.cancel_requested = True
            self._terminate_active_subprocesses()
        with suppress(Exception):
            self.yt_bypass.stop()
        self.config_data["window"] = self._window_state_now()
        self.save_config()

    def _on_close_window_request(self):
        if self.is_running and not self._confirm_abort(closing=True):
            return
        self._stop_and_save()
        self.destroy()
        os._exit(0)

    def _enable_russian_clipboard(self):
        events = {86: "<<Paste>>", 67: "<<Copy>>", 88: "<<Cut>>", 65: "<<SelectAll>>"}

        def _on_key(event):
            if event.state & 0x4 and event.keycode in events:
                event.widget.event_generate(events[event.keycode])
                return "break"
        self.bind_all("<Key>", _on_key, "+")

    # --- КОНФИГ И ДАННЫЕ ---
    def load_config(self):
        d = read_json(CONFIG_FILE, None)
        if not isinstance(d, dict):
            return dict(DEFAULT_CONFIG)
        if d.get("sub_size") == 46:
            d["sub_size"] = 70
        if not d.get("asr_gigaam_default"):  # 5.2: GigaAM — модель речи по умолчанию (Whisper можно выбрать в списке)
            d["asr_gigaam_default"] = True
            d["whisper_size"] = GIGAAM
            for mp in (d.get("mode_params") or {}).values():
                if isinstance(mp, dict):
                    mp["whisper_size"] = GIGAAM
        return {**DEFAULT_CONFIG, **d}

    def save_config(self):
        with suppress(Exception):
            self.config_data.update({
                "api_key": self.api_key_var.get().strip(), "base_url": self.base_url_var.get().strip(),
                "model": self.model_var.get().strip(), "whisper_size": self.whisper_combo.get(),
                "max_clips": self.clips_count_entry.get().strip(), "boost_audio": self.boost_audio_var.get(),
                "face_track": self.face_track_var.get(), "smart_track": self.smart_track_var.get(), "subtitles": self.subtitles_var.get(),
                "sub_advanced": self.sub_advanced_var.get(), "sub_font": self.sub_font_combo.get(),
                "sub_size": int(round(self.sub_size_slider.get())), "sub_bg": self.sub_bg_var.get(),
                "sub_word_by_word": self.sub_wbw_var.get(), "sub_mirror": self.sub_mirror_var.get(),
                "sub_female_colors": self.sub_female_var.get(), "min_clip_sec": int(round(self.min_clip_slider.get())),
                "max_clip_sec": int(round(self.max_clip_slider.get())), "sub_fix": self.sub_fix_var.get(), "mode": self.mode, "cs2_crop": self.cs2_crop_var.get(), "cs2_boost": self.cs2_boost_var.get(),
                "cs2_cam": self.cs2_cam_var.get(), "cs2_subtitles": self.cs2_subtitles_var.get(),
                "cs2_sub_advanced": self.cs2_sub_advanced_var.get(),
                "last_tokens_balance": self.tokens_balance_var.get(),
                "banner": "" if self.banner_var.get() == BANNER_NONE else self.banner_var.get(),
                "banner_pos": next((k for k, v in BANNER_POSITIONS.items() if v == self.banner_pos_var.get()), "middle"),
                "banner_over_subs": bool(self.banner_over_var.get()),
            })
            with suppress(Exception):  # значения «Параметров видео» текущего режима (у каждого режима свои)
                self.config_data.setdefault("mode_params", {})[self.mode] = self._shared_params_get()
        write_json(CONFIG_FILE, self.config_data)

    # --- ХРАНИЛИЩЕ КЛИПОВ (локально / Google Drive) ---
    def local_root(self) -> Path:
        return Path(self.config_data.get("local_dir") or Path.home() / "Desktop")

    def cloud_mode(self) -> bool:
        return self.config_data.get("storage_mode") == "cloud" and self.drive.connected

    def set_storage_mode(self, mode: str):
        mode = "cloud" if mode == "cloud" and self.drive.connected else "local"
        if self.config_data.get("storage_mode") != mode:
            self.config_data["storage_mode"] = mode
            self.log("[*] Хранилище клипов: " + (f"Google Drive (/{self.config_data.get('gdrive_folder', 'Клипы')})"
                                                  if mode == "cloud" else f"локально ({self.local_root()})"))
        self.save_config()

    def _output_roots(self) -> list:
        roots = []
        for r in (Path.home() / "Desktop", self.local_root(), CLOUD_CACHE_DIR):
            with suppress(Exception):
                if r.exists() and r.resolve() not in [x.resolve() for x in roots]:
                    roots.append(r)
        return roots

    def _drive_owns(self, clip: dict) -> bool:
        """Копия клипа на Drive принадлежит подключённому сейчас аккаунту (иначе её не изменить)."""
        g = clip.get("gdrive") or {}
        return bool(g.get("id")) and self.drive.connected and g.get("account", "") in ("", self.drive.user.get("email", ""))

    def _drive_upload_clip(self, clip: dict, replace=False, progress=None, cancelled=None) -> bool:
        """Сохраняет клип на Google Drive. replace=True — обновить уже загруженный файл (после перерендера)."""
        path = Path(clip["file_path"])
        old = clip.get("gdrive") or {}
        folder = old.get("folder") if replace and old else self.config_data.get("gdrive_folder", "Клипы")
        try:
            try:
                res = self.drive.upload(path, path.name, folder, old.get("id") if replace and self._drive_owns(clip) else None,
                                        progress, cancelled)
            except DriveError as e:
                if not (replace and e.status == 404):
                    raise
                res = self.drive.upload(path, path.name, folder, None, progress, cancelled)  # файл удалён с Drive — заново
            clip["gdrive"] = {"id": res["id"], "link": res["link"], "folder": folder, "account": self.drive.user.get("email", "")}
            self._save_gallery_db()
            return True
        except Cancelled:
            raise
        except Exception as e:
            self.log(f"[-] Google Drive: не удалось сохранить «{clip['title']}» ({e}). Клип сохранён на ПК.")
            return False

    def _drive_upload_from_menu(self, clip: dict):
        if not self._require_file(clip):
            return
        self.log(f"[*] Сохранение «{clip['title']}» на Google Drive...")

        def _w():
            if self._drive_upload_clip(clip):
                self.log(f"[+] «{clip['title']}» сохранён на Google Drive: /{clip['gdrive']['folder']}")
        run_bg(_w)

    def _drive_trash_clips(self, items: list):
        """«Удалить полностью»: копии на Google Drive — в корзину Drive (в фоне)."""
        cloud = [c for c in items if (c.get("gdrive") or {}).get("id")]
        if not cloud:
            return
        foreign = [c for c in cloud if not self._drive_owns(c)]
        if foreign:
            why = "Google Drive не подключён" if not self.drive.connected else "клипы сохранены другим аккаунтом Google"
            self.log(f"[!] Не удалось удалить с Google Drive {len(foreign)} шт.: {why}. Удалите их вручную на drive.google.com.")
            messagebox.showwarning("Google Drive", f"Клипы удалены с ПК, но {len(foreign)} шт. не удалось удалить с Google Drive: "
                                                   f"{why}.\n\nУдалите их вручную на drive.google.com.", parent=self)
        own = [c for c in cloud if c not in foreign]

        def _w():
            ok = 0
            for c in own:
                try:
                    self.drive.trash(c["gdrive"]["id"])
                    ok += 1
                except Exception as e:
                    self.log(f"[-] Google Drive: не удалось удалить «{c['title']}»: {e}")
            if own:
                self.log(f"[*] Удалено с Google Drive (перемещено в корзину Drive): {ok} из {len(own)} шт.")
        run_bg(_w)

    def _save_hidden_clips(self):
        write_json(HIDDEN_CLIPS_FILE, list(self.hidden_clip_paths))

    def _save_gallery_db(self):
        write_json(GALLERY_DB_FILE, [{k: v for k, v in c.items() if k != "thumb_pil"} for c in self.created_clips])

    @staticmethod
    def _clip_from_file(mp4: Path) -> dict:
        stem = strip_num_prefix(mp4.stem)
        return {
            "title": stem, "yt_title": f"{stem} #Shorts", "yt_description": "#Shorts #рек #тренды",
            "file_path": str(mp4), "source_video": str(mp4), "start": 0.0, "end": get_video_duration_sec(mp4),
            "subs": [], "speakers_count": 1,
            "speaker_styles": {"0": {"color": DEFAULT_SPEAKER_HEX[0], "mode": "text", "is_female": False}},
            "font_name": "Arial", "font_size": 70, "default_bg": False, "word_by_word": False, "mirror": False,
            "female_colors": False, "num_tracks": 1, "boost_audio": True, "vertical": True, "use_tracker": True,
        }

    def _load_existing_clips_async(self):
        """Фоновая загрузка галереи и миниатюр — окно открывается мгновенно."""
        def _bg():
            loaded, known = [], set()

            def _accept(fp: Path) -> bool:
                r = str(fp.resolve())
                if r in self.hidden_clip_paths or r in known:
                    return False
                known.add(r)
                return True

            saved = read_json(GALLERY_DB_FILE, [])
            for item in saved if isinstance(saved, list) else []:
                with suppress(Exception):
                    fp = Path(item.get("file_path", ""))
                    if fp.exists() and _accept(fp):
                        item["title"] = strip_num_prefix(item.get("title", fp.stem))
                        loaded.append(item)

            mtime = lambda p: p.stat().st_mtime if p.exists() else 0
            out_dirs = (d for root in self._output_roots() for d in root.glob("Clips_Output_*") if d.is_dir())
            for odir in sorted(out_dirs, key=mtime, reverse=True):
                for mp4 in sorted(odir.glob("*.mp4"), key=mtime, reverse=True):
                    if mp4.name != "source_video.mp4" and not mp4.name.startswith(".tmp_") and _accept(mp4):
                        loaded.append(self._clip_from_file(mp4))
            for item in loaded:
                item["thumb_pil"] = get_cached_thumbnail(Path(item["file_path"]))

            if loaded:
                def _apply():
                    self.created_clips = loaded
                    self._save_gallery_db()
                    self._show_clips_section_after_job()
                    self.log(f"[*] Галерея загружена в фоне: готовых клипов — {len(loaded)} шт.")
                self.after(0, _apply)
        run_bg(_bg)

    # --- МЕНЕДЖЕР АККАУНТОВ (YOUTUBE + TIKTOK) ---
    def _load_yt_accounts(self) -> dict:
        YT_PROFILES_ROOT.mkdir(parents=True, exist_ok=True)
        d = read_json(YT_ACCOUNTS_FILE, None)
        if isinstance(d, dict) and isinstance(d.get("accounts"), list):
            for a in d["accounts"]:
                a.setdefault("platform", "youtube")
            return d
        return {"accounts": [], "active_id": None}

    def _save_yt_accounts(self):
        write_json(YT_ACCOUNTS_FILE, self.yt_state)

    def _get_active_account(self):
        accs = self.yt_state.get("accounts", [])
        if not accs:
            return None
        found = next((a for a in accs if a.get("id") == self.yt_state.get("active_id")), None)
        if found is None:
            self.yt_state["active_id"] = accs[0]["id"]
        return found or accs[0]

    @staticmethod
    def _plat_title(platform) -> str:
        return "TikTok" if platform == "tiktok" else "YouTube"

    def _avatar(self, path, platform, size):
        img = ctk_image(make_avatar_with_platform_badge(path, platform, size=size), (size, size))
        self._yt_avatar_refs.append(img)
        return img

    def _close_account_popups(self):
        Popover.close_current()

    def _render_account_top_right(self):
        self._close_account_popups()
        for w in self.yt_container.winfo_children():
            w.destroy()
        self._yt_avatar_refs.clear()
        acc = self._get_active_account()
        style = dict(corner_radius=18, font=F(12, True), height=36)
        if not acc:
            self.yt_prof_btn = button(self.yt_container, "👤  Менеджер аккаунтов  ▾", self._toggle_accounts_dropdown, "surface", **style)
        else:
            self.yt_prof_btn = button(self.yt_container, f"  {acc.get('name', 'Аккаунт')} · {self._plat_title(acc.get('platform'))}  ▾",
                                      self._toggle_accounts_dropdown, "surface",
                                      image=self._avatar(acc.get("avatar_path", ""), acc.get("platform", "youtube"), 28),
                                      compound="left", **style)
        self.yt_prof_btn.pack(side="top", anchor="e")

    def _open_platform_choice_popup(self, anchor=None):
        pop = Popover(self, anchor=self.yt_prof_btn, width=250)
        pop.caption("Добавить аккаунт")
        for plat in ("youtube", "tiktok"):
            pop.item(f"  {self._plat_title(plat)}", lambda p=plat: self._start_platform_login(p), image=self._avatar("", plat, 26))
        pop.show_under(self.yt_prof_btn)

    def _toggle_accounts_dropdown(self):
        if Popover.is_open_for(self.yt_prof_btn):
            return Popover.close_current()
        if Popover.just_closed_by(self.yt_prof_btn):
            return
        acc = self._get_active_account()
        if not acc:
            return self._open_platform_choice_popup()
        others = [a for a in self.yt_state.get("accounts", []) if a.get("id") != acc.get("id")]
        pop = Popover(self, anchor=self.yt_prof_btn, width=max(280, int(self.yt_prof_btn.winfo_width() / max(0.5, self._get_window_scaling()))))
        pop.item("➕  Добавить аккаунт", self._open_platform_choice_popup)
        if others:
            pop.separator()
            pop.caption("Переключить аккаунт")
            holder = pop.body
            if len(others) > 6:
                holder = ctk.CTkScrollableFrame(pop.body, fg_color="transparent", height=6 * 42, width=pop.width - 30)
                holder.pack(fill="x")
            for a in others:
                pop.item(f"  {a.get('name', 'Аккаунт')} · {self._plat_title(a.get('platform'))}", lambda aid=a["id"]: self._switch_account(aid),
                         image=self._avatar(a.get("avatar_path", ""), a.get("platform", "youtube"), 26), parent=holder)
        pop.separator()
        pop.item(f"Выйти из «{acc.get('name', 'Аккаунт')}»", self._logout_current_account, color=Popover.DANGER)
        pop.show_under(self.yt_prof_btn)

    def _switch_account(self, account_id: str):
        self._close_account_popups()
        self.yt_state["active_id"] = account_id
        self._save_yt_accounts()
        acc = self._get_active_account()
        self._render_account_top_right()
        if acc:
            self.log(f"[*] Рабочий аккаунт переключен на: {acc.get('name')} ({self._plat_title(acc.get('platform'))})")

    def _logout_current_account(self):
        self._close_account_popups()
        acc = self._get_active_account()
        if not acc:
            return
        remaining = [a for a in self.yt_state.get("accounts", []) if a.get("id") != acc.get("id")]
        self.yt_state.update(accounts=remaining, active_id=remaining[0]["id"] if remaining else None)
        self._save_yt_accounts()
        if acc.get("profile_dir"):
            shutil.rmtree(acc["profile_dir"], ignore_errors=True)
        self._render_account_top_right()
        self.log(f"[*] Вы вышли из аккаунта «{acc.get('name', 'Аккаунт')}».")

    def _start_platform_login(self, platform: str):
        self._close_account_popups()
        self.log(f"[*] Открытие окна браузера для авторизации в {self._plat_title(platform)}...")
        run_bg(self._platform_login_worker, platform)

    @staticmethod
    def _login_youtube(page, ctx):
        page.goto("https://accounts.google.com/ServiceLogin?service=youtube&continue=https://www.youtube.com/")
        for _ in range(360):
            if page.is_closed():
                break
            url = page.url
            if "youtube.com" in url and "accounts.google.com" not in url:
                with suppress(Exception):
                    av_btn = page.locator("button#avatar-btn, ytd-topbar-menu-button-renderer button#avatar-btn").first
                    if av_btn.count() > 0:
                        img = av_btn.locator("img").first
                        avatar = img.get_attribute("src") if img.count() > 0 else None
                        av_btn.click()
                        page.wait_for_timeout(1200)
                        name_loc = page.locator("yt-formatted-string#account-name, #channel-title").first
                        name = name_loc.inner_text().strip() if name_loc.count() > 0 else None
                        if name:
                            return name, avatar
            page.wait_for_timeout(1000)
        return None, None

    @staticmethod
    def _login_tiktok(page, ctx):
        page.goto("https://www.tiktok.com/login")
        for _ in range(360):
            if page.is_closed():
                break
            with suppress(Exception):
                logged = any(c.get("name") in ("sessionid", "sid_tt", "uid_tt") and c.get("value") for c in ctx.cookies())
                if logged and "/login" not in page.url:
                    page.wait_for_timeout(1800)
                    av = page.locator("[data-e2e='profile-icon'] img, header img[alt*='avatar'], header img").first
                    avatar = av.get_attribute("src") if av.count() > 0 else None
                    page.goto("https://www.tiktok.com/tiktokstudio/upload", wait_until="domcontentloaded", timeout=15000)
                    page.wait_for_timeout(2000)
                    nl = page.locator("[data-e2e='user-title'], [data-e2e='user-subtitle'], header span").first
                    name = nl.inner_text().strip() if nl.count() > 0 else ""
                    return name or "TikTok Аккаунт", avatar
            page.wait_for_timeout(1000)
        return None, None

    def _platform_login_worker(self, platform: str):
        acc_id = f"{platform}_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        prof_dir = YT_PROFILES_ROOT / acc_id
        prof_dir.mkdir(parents=True, exist_ok=True)
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                ctx = launch_browser_context(p, str(prof_dir), headless=False, width=540, height=700)
                page = ctx.pages[0] if ctx.pages else ctx.new_page()
                name, avatar_url = (self._login_tiktok if platform == "tiktok" else self._login_youtube)(page, ctx)
                ctx.close()
            if not name:
                shutil.rmtree(prof_dir, ignore_errors=True)
                self.log("[!] Окно авторизации закрыто без завершения входа.")
                return
            av_local = prof_dir / "avatar.png"
            if avatar_url and avatar_url.startswith("http"):
                with suppress(Exception):
                    import requests
                    r = requests.get(avatar_url, timeout=8)
                    if r.status_code == 200:
                        Image.open(BytesIO(r.content)).convert("RGBA").save(av_local)
            self.yt_state.setdefault("accounts", []).append({
                "id": acc_id, "platform": platform, "name": name,
                "avatar_path": str(av_local) if av_local.exists() else "", "profile_dir": str(prof_dir),
            })
            self.yt_state["active_id"] = acc_id
            self._save_yt_accounts()
            self.log(f"[+] Аккаунт {self._plat_title(platform)} «{name}» успешно добавлен и выбран активным!")
            self.after(0, self._render_account_top_right)
        except Exception as e:
            shutil.rmtree(prof_dir, ignore_errors=True)
            self.log(f"[-] Ошибка окна авторизации: {e}")

    # --- ЗАГРУЗКА КЛИПОВ НА ПЛАТФОРМЫ ---
    @staticmethod
    def _fill_youtube(page, title, desc, tags=()):
        boxes = page.locator("ytcp-social-suggestions-textbox #textbox, #textbox[contenteditable='true']")
        boxes.first.wait_for(state="visible", timeout=15000)
        for i, text, limit in ((0, title, 100), (1, desc, 4900)):
            if i == 1 and (not desc or boxes.count() < 2):
                break
            if i:
                page.wait_for_timeout(400)
            boxes.nth(i).click()
            page.keyboard.press("Control+A")
            page.keyboard.insert_text(text[:limit])
        if tags:  # теги спрятаны под «Развернуть»; если интерфейс Studio изменится — просто пропускаем
            with suppress(Exception):
                page.locator("ytcp-button#toggle-button, #toggle-button").first.click(timeout=4000)
                page.wait_for_timeout(700)
                inp = page.locator("#tags-container input, ytcp-free-text-chip-bar input#text-input").first
                inp.wait_for(state="visible", timeout=4000)
                inp.click()
                for t in tags:
                    page.keyboard.insert_text(t)
                    page.keyboard.press("Enter")
                    page.wait_for_timeout(80)

    @staticmethod
    def _fill_tiktok(page, caption):
        box = page.locator("div[contenteditable='true'], .public-DraftEditor-content").first
        box.wait_for(state="visible", timeout=15000)
        box.click()
        page.keyboard.press("Control+A")
        page.keyboard.press("Backspace")
        page.keyboard.insert_text(caption[:2100])

    def _wait_upload_done(self, page, tiktok: bool):
        dialog_seen = False
        while not page.is_closed():
            with suppress(Exception):
                if tiktok:
                    done = page.locator("div:has-text('Ваше видео загружается'), div:has-text('Видео опубликовано'), "
                                        "div:has-text('Your video is being uploaded'), div:has-text('Manage your posts')")
                    if "/tiktokstudio/content" in page.url or (done.count() > 0 and done.first.is_visible()):
                        self.log("[+] Видео успешно отправлено в TikTok! Закрываем окно браузера...")
                        page.wait_for_timeout(2500)
                        return True
                else:
                    dlg_count = page.locator("ytcp-uploads-dialog").count()
                    dialog_seen = dialog_seen or dlg_count > 0
                    share = page.locator("ytcp-video-share-dialog, ytcp-uploads-still-processing-dialog, "
                                         "tp-yt-paper-dialog:has-text('Видео опубликовано'), "
                                         "tp-yt-paper-dialog:has-text('Video published')")
                    if share.count() > 0 and share.first.is_visible():
                        self.log("[+] Видео опубликовано на YouTube! Закрываем окно браузера...")
                        page.wait_for_timeout(2200)
                        return True
                    if dialog_seen and dlg_count == 0:
                        self.log("[+] Загрузка на YouTube завершена! Закрываем окно браузера...")
                        page.wait_for_timeout(1500)
                        return True
            page.wait_for_timeout(1000)
        return False   # окно закрыли раньше — видео не отправлено

    def _mark_published(self, clip: dict, acc: dict):
        """Клип выложен: значок платформы на плитке, в подсказке — аккаунты, куда он выложен."""
        plat = acc.get("platform", "youtube")
        lst = clip.setdefault("published", {}).setdefault(plat, [])
        if not any(x.get("id") == acc.get("id") for x in lst):
            lst.append({"id": acc.get("id"), "name": acc.get("name") or self._plat_title(plat)})
            self._save_gallery_db()
            self._refresh_clips_list_ui()

    def _upload_clip_to_active_platform(self, clip: dict):
        acc = self._get_active_account()
        if not acc:
            messagebox.showwarning("Нет авторизации", "Сначала войдите в аккаунт через «Менеджер аккаунтов» в правом верхнем углу.")
            return
        fpath = self._require_file(clip, resolve=True)
        if not fpath:
            return
        tiktok = acc.get("platform", "youtube") == "tiktok"
        plat = self._plat_title(acc.get("platform"))
        name = acc.get("name", plat)
        if tiktok:
            title = strip_num_prefix(clip.get("title", ""))
            caption = f"{title}\n{clip.get('yt_description', '#fyp #рек #тренды').strip()}".strip()
            self.log(f"[*] Загрузка клипа «{title}» в TikTok («{name}»)...")
            url, size, timeout, settle = "https://www.tiktok.com/tiktokstudio/upload", (920, 780), 35000, 4000
            fill = lambda pg: self._fill_tiktok(pg, caption)
            ok_msg = f"[+] Видео, название, описание и хэштеги автоматически подставлены в TikTok Studio («{name}»)!"
        else:
            title = (clip.get("yt_title") or strip_num_prefix(clip.get("title", "Shorts")))[:SEO_TITLE_MAX]
            desc = clip.get("yt_description", "").strip()
            tags = seo_tags(clip.get("yt_tags", ""))
            self.log(f"[*] Загрузка клипа «{title}» на YouTube-канал «{name}»...")
            url, size, timeout, settle = "https://www.youtube.com/upload", (880, 760), 30000, 3500
            fill = lambda pg: self._fill_youtube(pg, title, desc, tags)
            ok_msg = (f"[+] Видео, название, описание с хэштегами{' и теги' if tags else ''} "
                      f"подставлены в YouTube Studio для «{name}»!")

        def _worker():
            try:
                from playwright.sync_api import sync_playwright
                with sync_playwright() as p:
                    ctx = launch_browser_context(p, str(acc["profile_dir"]), False, *size)
                    page = ctx.pages[0] if ctx.pages else ctx.new_page()
                    page.goto(url)
                    fi = page.locator("input[type='file']").first
                    fi.wait_for(state="attached", timeout=timeout)
                    fi.set_input_files(str(fpath))
                    page.wait_for_timeout(settle)
                    with suppress(Exception):
                        fill(page)
                    self.log(ok_msg)
                    done = self._wait_upload_done(page, tiktok)
                    ctx.close()
                if done:
                    self.after(0, lambda: self._mark_published(clip, acc))
            except Exception as e:
                self.log(f"[-] Ошибка загрузчика {plat}: {e}")
        run_bg(_worker)

    # --- ПОСТРОЕНИЕ ИНТЕРФЕЙСА ---
    # Шапка: значок обновления + название | менеджер аккаунтов.
    # Слева — настройки нарезки (прокручиваются), снизу всегда видны прогресс, «Запустить» и ⚙.
    # Справа — вкладки «Галерея / Журнал / Расшифровка» на всю высоту окна.
    LEFT_W = 470

    def _build_ui(self):
        cfg = self.config_data
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(1, weight=1)
        pill = dict(height=30, corner_radius=15)

        def section(parent, text):
            body = card(parent)
            body.pack(fill="x", pady=(0, 10))
            num, _, title = text.partition(". ")
            head = ctk.CTkFrame(body, fg_color="transparent")
            head.pack(fill="x", padx=14, pady=(12, 8))
            label(head, num, F(12, True), "on_primary", width=24, height=24, corner_radius=12, fg_color=MD3["primary"]).pack(side="left")
            label(head, title, F(15, True), anchor="w").pack(side="left", padx=(10, 0))
            inner = ctk.CTkFrame(body, fg_color="transparent")
            inner.pack(fill="x", padx=16, pady=(0, 14))
            return inner

        def caption(parent, text, top=6):
            lbl = label(parent, text, F(12), "on_surface_var", anchor="w")
            lbl.pack(fill="x", pady=(top, 3))
            return lbl

        def row(parent, top=0):
            r = ctk.CTkFrame(parent, fg_color="transparent")
            r.pack(fill="x", pady=(top, 0))
            return r

        def grid2(parent, top=6):
            g = ctk.CTkFrame(parent, fg_color="transparent")
            g.pack(fill="x", pady=(top, 0))
            g.grid_columnconfigure((0, 1), weight=1, uniform="c")
            return g

        # шапка
        head = ctk.CTkFrame(self, fg_color="transparent")
        head.grid(row=0, column=0, columnspan=2, sticky="ew", padx=16, pady=(10, 8))
        self.update_btn = button(head, "", self.updates_overlay.open, "ghost", width=34, height=34, corner_radius=17,
                                 image=ctk_image(make_download_icon(44), (22, 22)), hover_color=MD3["secondary_container"])
        self.api_title = label(head, "Clips Studio AI", F(20, True))
        self.api_title.pack(side="left", padx=(4, 0))
        label(head, f"v{APP_VERSION}", F(11, True), "on_secondary", height=22, corner_radius=11,
              fg_color=MD3["secondary_container"]).pack(side="left", padx=(10, 0), ipadx=6)
        self.yt_container = ctk.CTkFrame(head, fg_color="transparent")
        self.yt_container.pack(side="right")
        self._render_account_top_right()
        # режимы работы: обычные нарезки и матчи CS2 — у каждого свои «Параметры видео»
        self.mode = "cs2" if cfg.get("mode") == "cs2" else "clips"
        self.mode_tabs = ctk.CTkSegmentedButton(
            head, values=list(MODES.values()), command=self._on_mode_tab, font=F(13, True), height=34, corner_radius=17,
            fg_color=MD3["surface_high"], selected_color=MD3["secondary_container"], selected_hover_color=MD3["surface_highest"],
            unselected_color=MD3["surface_high"], unselected_hover_color=MD3["surface_highest"], text_color=MD3["on_surface"])
        self.mode_tabs.set(MODES[self.mode])
        self.mode_tabs.place(relx=0.5, rely=0.5, anchor="center")

        # левая колонка
        left = ctk.CTkFrame(self, fg_color="transparent")
        left.grid(row=1, column=0, sticky="nsew", padx=(16, 8), pady=(0, 12))
        left.grid_rowconfigure(0, weight=1)
        left.grid_columnconfigure(0, weight=1)
        side = ctk.CTkScrollableFrame(left, fg_color="transparent", width=self.LEFT_W - 20,
                                      scrollbar_button_color=MD3["surface_highest"])
        side.grid(row=0, column=0, sticky="nsew")

        # нейросеть настраивается в Настройках; значения живут в переменных
        self.api_key_var = tk.StringVar(value=cfg["api_key"])
        self.base_url_var = tk.StringVar(value=cfg["base_url"])
        self.model_var = tk.StringVar(value=cfg["model"])
        last_bal = str(cfg.get("last_tokens_balance", "—"))
        self.tokens_balance_var = tk.StringVar(value=last_bal if last_bal.startswith("Токены:") else f"Токены: {last_bal}")
        self._key_watch = None

        def _key_changed(*_a):  # новый ключ — проверить лимиты (с паузой, пока вставляют/печатают)
            if self._key_watch:
                self.after_cancel(self._key_watch)
            self._key_watch = self.after(1200, lambda: self.refresh_token_balance_async(silent=False))
        self.api_key_var.trace_add("write", _key_changed)

        # 2. Источник
        s = section(side, "1. Источник видео")
        caption(s, "Файл с компьютера или ссылка YouTube / Twitch", top=0)
        r = row(s)
        button(r, "Обзор...", self.pick_file, width=90, font=F(12, True), **pill).pack(side="right")
        self.source_entry = entry(r, placeholder_text="Путь к .mp4 или ссылка", height=34)
        self.source_entry.pack(side="left", fill="x", expand=True, padx=(0, 8))

        # 3. Параметры
        s = section(side, "2. Параметры видео")
        g = grid2(s, top=0)
        for col, (cap, make) in enumerate((("Модель речи", lambda p: combo(p, [GIGAAM, "tiny", "base", "small", "medium"], cfg["whisper_size"], corner_radius=8, height=32)),
                                           ("Макс. клипов", lambda p: entry(p, corner_radius=8, height=32)))):
            box = ctk.CTkFrame(g, fg_color="transparent")
            box.grid(row=0, column=col, sticky="ew", padx=(0, 6) if col == 0 else (6, 0))
            caption(box, cap, top=0)
            w = make(box)
            w.pack(fill="x")
            if col == 0:
                self.whisper_combo = w
            else:
                self.clips_count_entry = w
                w.insert(0, cfg["max_clips"])
        self.crop_var = ctk.BooleanVar(value=True)
        self.boost_audio_var = ctk.BooleanVar(value=cfg["boost_audio"])
        self.face_track_var = ctk.BooleanVar(value=cfg["face_track"])
        self.smart_track_var = ctk.BooleanVar(value=bool(cfg["smart_track"]) and bool(cfg["face_track"]))
        self.subtitles_var = ctk.BooleanVar(value=cfg["subtitles"])
        self.sub_advanced_var = ctk.BooleanVar(value=cfg["sub_advanced"])
        g = grid2(s, top=12)
        boxes = {}
        for i, (text, var, cmd) in enumerate((("9:16 (Shorts)", self.crop_var, None), ("Усиление звука", self.boost_audio_var, None),
                                              ("Трекинг", self.face_track_var, self._update_tracking_state),
                                              ("Умный трекинг", self.smart_track_var, None),
                                              ("Субтитры", self.subtitles_var, self._update_subtitles_visibility))):
            boxes[text] = checkbox(g, text, var, cmd, F(13))
            boxes[text].grid(row=i // 2, column=i % 2, sticky="w", pady=5)
        self.smart_track_cb = boxes["Умный трекинг"]
        self.sub_advanced_cb = checkbox(g, "Расширенные субтитры", self.sub_advanced_var, self._update_subtitles_visibility, F(13))
        self._update_tracking_state()
        self.params_grid_clips = g
        # CS2: вместо трекинга — «Стример/Каст» (веб-камера сверху, матч снизу); иначе кадр всегда по центру
        self.cs2_crop_var = ctk.BooleanVar(value=bool(cfg.get("cs2_crop", True)))
        self.cs2_boost_var = ctk.BooleanVar(value=bool(cfg.get("cs2_boost", True)))
        self.cs2_cam_var = ctk.BooleanVar(value=bool(cfg.get("cs2_cam", False)))
        self.cs2_subtitles_var = ctk.BooleanVar(value=bool(cfg.get("cs2_subtitles", False)))
        self.cs2_sub_advanced_var = ctk.BooleanVar(value=bool(cfg.get("cs2_sub_advanced", False)))
        g2 = ctk.CTkFrame(s, fg_color="transparent")
        g2.grid_columnconfigure((0, 1), weight=1, uniform="c")
        for i, (text, var, cmd) in enumerate((("9:16 (Shorts)", self.cs2_crop_var, self._update_cs2_state),
                                              ("Усиление звука", self.cs2_boost_var, None),
                                              ("Стример/Каст", self.cs2_cam_var, None))):
            boxes[text + " cs2"] = checkbox(g2, text, var, cmd, F(13))
            boxes[text + " cs2"].grid(row=i // 2, column=i % 2, sticky="w", pady=5)
        self.cs2_cam_cb = boxes["Стример/Каст cs2"]
        checkbox(g2, "Субтитры", self.cs2_subtitles_var, self._update_subtitles_visibility, F(13)).grid(
            row=2, column=0, sticky="w", pady=5)
        self.cs2_sub_advanced_cb = checkbox(g2, "Расширенные субтитры", self.cs2_sub_advanced_var,
                                            self._update_subtitles_visibility, F(13))
        self.params_grid_cs2 = g2
        self._params_grid_pack = dict(fill="x", pady=(12, 0))

        self.sub_adv_panel = ctk.CTkFrame(s, fg_color=MD3["surface_high"], corner_radius=12)
        sp = ctk.CTkFrame(self.sub_adv_panel, fg_color="transparent")
        sp.pack(fill="x", padx=12, pady=10)
        r = row(sp)
        label(r, "Шрифт", F(12), "on_surface_var").pack(side="left", padx=(0, 8))
        self.sub_font_combo = combo(r, list(FONT_MAP), cfg["sub_font"], 140, fg_color=MD3["surface_container"], height=30)
        self.sub_font_combo.pack(side="left")
        init_size = min(128, max(24, int(cfg["sub_size"])))
        self.sub_size_label = label(r, f"Размер: {init_size} px", F(12), "on_surface_var")
        self.sub_size_label.pack(side="right")
        self.sub_size_slider = slider(sp, 24, 128, init_size, 300, lambda v: self.sub_size_label.configure(text=f"Размер: {int(round(v))} px"))
        self.sub_size_slider.pack(fill="x", pady=(10, 4))
        self.sub_bg_var = ctk.BooleanVar(value=cfg["sub_bg"])
        self.sub_wbw_var = ctk.BooleanVar(value=cfg["sub_word_by_word"])
        self.sub_mirror_var = ctk.BooleanVar(value=cfg["sub_mirror"])
        self.sub_female_var = ctk.BooleanVar(value=cfg["sub_female_colors"])
        self.sub_fix_var = ctk.BooleanVar(value=bool(cfg.get("sub_fix", False)))
        g = grid2(sp, top=4)
        self.sub_bg_cb = checkbox(g, "Задний фон", self.sub_bg_var, self._on_bg_or_wbw_toggle, F(12))
        self.sub_wbw_cb = checkbox(g, "Окраска по слову", self.sub_wbw_var, self._on_bg_or_wbw_toggle, F(12))
        self.sub_female_cb = checkbox(g, "Женские персонажи", self.sub_female_var, font=F(12))
        for i, cb in enumerate((self.sub_bg_cb, self.sub_wbw_cb, checkbox(g, "Отзеркалить", self.sub_mirror_var, font=F(12)),
                                self.sub_female_cb)):
            cb.grid(row=i // 2, column=i % 2, sticky="w", pady=4)
        self.sub_fix_cb = checkbox(g, "Исправлять ошибки нейросетью", self.sub_fix_var, self.save_config, F(12))
        self.sub_fix_cb.grid(row=2, column=0, columnspan=2, sticky="w", pady=4)
        self._on_bg_or_wbw_toggle()

        init_min = max(5, min(60, int(cfg["min_clip_sec"])))
        self.clip_time_toggle_btn = button(s, "", self._toggle_clip_time_section, "ghost", anchor="w", height=30, corner_radius=10,
                                           text_color=MD3["primary"], font=F(12, True), hover_color=MD3["surface_high"])
        self.clip_time_toggle_btn.pack(fill="x", pady=(10, 0))
        self.clip_time_panel = ctk.CTkFrame(s, fg_color=MD3["surface_high"], corner_radius=12)
        tp = ctk.CTkFrame(self.clip_time_panel, fg_color="transparent")
        tp.pack(fill="x", padx=12, pady=10)
        label(tp, "Минимальная длительность клипа (5–60 сек)", F(12), "on_surface_var", anchor="w").pack(fill="x")
        self.min_clip_slider = slider(tp, 5, 60, init_min, 300, self._on_min_clip_sec_change)
        self.min_clip_slider.pack(fill="x", pady=(8, 4))
        self.min_clip_val_label = label(tp, "", F(12), "primary", anchor="w")
        self.min_clip_val_label.pack(fill="x")
        init_max = max(MAX_CLIP_LO, min(MAX_CLIP_HI, int(cfg.get("max_clip_sec", 60))))
        label(tp, "Максимальная длительность клипа (10 сек – 5 мин)", F(12), "on_surface_var", anchor="w").pack(fill="x", pady=(12, 0))
        self.max_clip_slider = slider(tp, MAX_CLIP_LO, MAX_CLIP_HI, init_max, 300, self._on_max_clip_sec_change)
        self.max_clip_slider.pack(fill="x", pady=(8, 4))
        self.max_clip_val_label = label(tp, "", F(12), "primary", anchor="w")
        self.max_clip_val_label.pack(fill="x")
        self._on_min_clip_sec_change(init_min)
        self._apply_mode(save=False)

        # 3. Баннер
        s = section(side, "3. Баннер")
        caption(s, "Баннер поверх каждого клипа (файлы из папки «banners»)", top=0)
        r = row(s)
        folder_img = ctk_image(make_folder_icon(40), (20, 20))
        button(r, "", self._open_banners_dir, "surface", width=34, height=32, corner_radius=16, image=folder_img).pack(side="left")
        self.banner_var = tk.StringVar(value=cfg.get("banner") or BANNER_NONE)
        self.banner_gear = button(r, "⚙", self.banner_overlay.open, "surface", width=34, height=32, corner_radius=16,
                                  font=("Segoe UI Symbol", 15))
        self.banner_combo = combo(r, [BANNER_NONE], self.banner_var.get(), variable=self.banner_var, corner_radius=10,
                                  height=32, command=lambda _v: self._on_banner_change())
        self.banner_combo.pack(side="left", fill="x", expand=True, padx=(8, 0))
        self.banner_opts = ctk.CTkFrame(s, fg_color="transparent")
        self.banner_over_var = ctk.BooleanVar(value=bool(cfg.get("banner_over_subs", False)))
        checkbox(self.banner_opts, "Поверх субтитров", self.banner_over_var, self.save_config, F(12)).pack(side="left")
        self.banner_pos_overlay = BannerPositionOverlay(
            self, lambda: (self.banner_var.get(), (self.config_data.get("banner_xy") or {}).get(self.banner_var.get())),
            self._set_banner_xy)
        button(self.banner_opts, "Положение", self.banner_pos_overlay.open, "surface", width=110, height=30,
               corner_radius=15, font=F(12, True)).pack(side="right")
        self._banner_time_label = caption(s, "Время баннера", top=10)
        pos_names = list(BANNER_POSITIONS.values())
        self.banner_pos_var = tk.StringVar(value=BANNER_POSITIONS.get(cfg.get("banner_pos"), BANNER_POSITIONS["middle"]))
        combo(s, pos_names, self.banner_pos_var.get(), variable=self.banner_pos_var, corner_radius=10, height=32,
              command=lambda _v: self.save_config()).pack(fill="x")
        self._refresh_banners()
        self.bind("<FocusIn>", self._refresh_banners, add="+")

        # низ левой колонки: прогресс, запуск/остановка, настройки
        bottom = ctk.CTkFrame(left, fg_color="transparent")
        bottom.grid(row=1, column=0, sticky="ew", pady=(8, 0))
        prog = card(bottom)
        prog.pack(fill="x")
        self.status_label = label(prog, "Ожидание запуска... (0%)", F(12, True), anchor="w", wraplength=self.LEFT_W - 50, justify="left")
        self.status_label.pack(fill="x", padx=14, pady=(8, 3))
        self.progress_bar = ctk.CTkProgressBar(prog, height=10, corner_radius=5, fg_color=MD3["surface_high"], progress_color=MD3["primary"])
        self.progress_bar.pack(fill="x", padx=14, pady=(0, 10))
        self.progress_bar.set(0.0)
        ctrl = ctk.CTkFrame(bottom, fg_color="transparent")
        ctrl.pack(fill="x", pady=(8, 2))
        ctrl.grid_columnconfigure(1, weight=1)
        button(ctrl, "⚙", self.settings.open, "surface", width=40, height=40, corner_radius=20,
               font=("Segoe UI Symbol", 17)).grid(row=0, column=0, padx=(0, 10))
        big = dict(height=40, corner_radius=20, font=F(13, True))
        self.start_btn = button(ctrl, "▶   ЗАПУСТИТЬ НАРЕЗКУ", self.start_pipeline, "primary", **big)
        self.start_btn.grid(row=0, column=1, sticky="ew")
        self.stop_btn = button(ctrl, "■  СТОП", self._on_stop_request, "danger", width=120, **big)
        self.stop_btn.grid(row=0, column=2, padx=(10, 0))
        self.stop_btn.grid_remove()

        # правая часть: вкладки
        self.tabs = ctk.CTkTabview(self, fg_color=MD3["surface_container"], border_width=1, border_color=MD3["outline"],
                                   segmented_button_fg_color=MD3["surface_high"], segmented_button_selected_color=MD3["secondary_container"],
                                   segmented_button_selected_hover_color=MD3["surface_highest"],
                                   segmented_button_unselected_color=MD3["surface_high"],
                                   segmented_button_unselected_hover_color=MD3["surface_highest"],
                                   text_color=MD3["on_surface"], corner_radius=16)
        self.tabs.grid(row=1, column=1, sticky="nsew", padx=(8, 16), pady=(0, 12))
        tab_g, tab_l, tab_t = (self.tabs.add(n) for n in (self._gallery_tab, "Журнал", "Расшифровка"))
        for t in (tab_g, tab_l, tab_t):
            t.grid_columnconfigure(0, weight=1)
            t.grid_rowconfigure(1, weight=1)
        self.clips_title_lbl = label(tab_g, "Готовые клипы (0)", F(13, True), "primary", anchor="w")
        self.clips_title_lbl.grid(row=0, column=0, sticky="ew", padx=6, pady=(0, 6))
        self.clips_scroll = ctk.CTkScrollableFrame(tab_g, fg_color=MD3["surface"], corner_radius=12)
        self.clips_scroll.grid(row=1, column=0, sticky="nsew")
        self.clips_scroll.bind("<Configure>", lambda _e: self._schedule_grid_check(), add="+")
        self._bind_lasso_events(self.clips_scroll)
        if hasattr(self.clips_scroll, "_parent_canvas"):
            self._bind_lasso_events(self.clips_scroll._parent_canvas)
        label(tab_l, "Журнал работы программы", F(12), "on_surface_var", anchor="w").grid(row=0, column=0, sticky="ew", padx=6, pady=(0, 6))
        th = ctk.CTkFrame(tab_t, fg_color="transparent")
        th.grid(row=0, column=0, sticky="ew", pady=(0, 6))
        label(th, "Распознанная речь с таймкодами", F(12), "on_surface_var").pack(side="left", padx=6)
        button(th, "Отдельное окно ↗", self.open_transcript_window, width=140, height=28, corner_radius=14).pack(side="right")
        boxes = []
        for t in (tab_l, tab_t):
            tb = ctk.CTkTextbox(t, font=("Consolas", 12), fg_color=MD3["surface"], text_color=MD3["on_surface"], corner_radius=12)
            tb.grid(row=1, column=0, sticky="nsew")
            boxes.append(tb)
        self.log_box, self.transcript_box = boxes

        self.log(f"Clips Studio v{APP_VERSION}. Список изменений — в окне обновления (значок слева вверху) и в настройках ⚙.")

    def _show_clips_section_after_job(self):
        if self._gallery_switch_pending:  # после первого клипа нового запуска показываем галерею
            self._gallery_switch_pending = False
            with suppress(Exception):
                self.tabs.set(self._gallery_tab)
        self._refresh_clips_list_ui()

    # --- ВЫДЕЛЕНИЕ ЛАССО ---
    def _bind_lasso_events(self, widget, clip_path: str = None):
        widget.bind("<ButtonPress-1>", lambda e: self._on_gallery_lmb_press(e, clip_path), add="+")
        widget.bind("<B1-Motion>", self._on_gallery_lmb_drag, add="+")
        widget.bind("<ButtonRelease-1>", lambda e: self._on_gallery_lmb_release(e, clip_path), add="+")

    def _on_gallery_lmb_press(self, event, clip_path=None):
        self._lasso_start_root, self._lasso_moved = (event.x_root, event.y_root), False
        if clip_path is None and not event.state & 0x4:
            self.selected_clip_paths.clear()
            self._update_tiles_selection_visuals()

    def _on_gallery_lmb_drag(self, event):
        if self._lasso_start_root is None:
            return
        sx, sy = self._lasso_start_root
        cx, cy = event.x_root, event.y_root
        if abs(cx - sx) < 8 and abs(cy - sy) < 8 and not self._lasso_moved:
            return
        self._lasso_moved = True
        x1, x2, y1, y2 = min(sx, cx), max(sx, cx), min(sy, cy), max(sy, cy)
        if self._lasso_popup is None or not self._lasso_popup.winfo_exists():
            pop = tk.Toplevel(self)
            pop.wm_overrideredirect(True)
            pop.attributes("-topmost", True)
            pop.attributes("-alpha", 0.28)
            pop.configure(bg=MD3["primary"], highlightbackground="#FFFFFF", highlightthickness=1)
            self._lasso_popup = pop
        self._lasso_popup.geometry(f"{max(2, x2 - x1)}x{max(2, y2 - y1)}+{x1}+{y1}")
        sel = set()
        for fp, tile in self.tile_widgets_map.items():
            if tile.winfo_exists():
                tx1, ty1 = tile.winfo_rootx(), tile.winfo_rooty()
                if not (tx1 + tile.winfo_width() < x1 or tx1 > x2 or ty1 + tile.winfo_height() < y1 or ty1 > y2):
                    sel.add(fp)
        if sel != self.selected_clip_paths:
            self.selected_clip_paths = sel
            self._update_tiles_selection_visuals()

    def _on_gallery_lmb_release(self, event, clip_path=None):
        if self._lasso_popup is not None and self._lasso_popup.winfo_exists():
            self._lasso_popup.destroy()
        self._lasso_popup = None
        if not self._lasso_moved and clip_path is not None:
            if event.state & 0x4:
                self.selected_clip_paths ^= {clip_path}
            else:
                self.selected_clip_paths = {clip_path}
            self._update_tiles_selection_visuals()
        self._lasso_start_root, self._lasso_moved = None, False

    def _tile_style(self, tile, path, hover=False):
        if path in self.selected_clip_paths:
            tile.configure(fg_color=MD3["selected_card"], border_color=MD3["selected_border"], border_width=2)
        elif hover:
            tile.configure(fg_color=MD3["surface_highest"], border_color=MD3["primary"])
        else:
            tile.configure(fg_color=MD3["surface_high"], border_color=MD3["outline"], border_width=1)

    def _update_tiles_selection_visuals(self):
        for fp, tile in self.tile_widgets_map.items():
            if tile.winfo_exists():
                self._tile_style(tile, fp)
        n, total = len(self.selected_clip_paths), len(self.created_clips)
        self.clips_title_lbl.configure(
            text=(f"Выделено: {n} · " if n else "") + "Протяните мышью, чтобы выделить несколько · правый клик — меню клипа"
            if total else "Здесь появятся готовые клипы — запустите нарезку слева")
        name = f"Готовые клипы ({total})" if total else "Готовые клипы"
        if name != self._gallery_tab:
            with suppress(Exception):
                self.tabs.rename(self._gallery_tab, name)
                self._gallery_tab = name

    # --- ПАРАМЕТРЫ ---
    def _on_bg_or_wbw_toggle(self):
        if self.sub_wbw_var.get():
            self.sub_bg_var.set(False)
        elif self.sub_bg_var.get():
            self.sub_wbw_var.set(False)
        self.sub_bg_cb.configure(state="disabled" if self.sub_wbw_var.get() else "normal")
        self.sub_wbw_cb.configure(state="disabled" if self.sub_bg_var.get() else "normal")

    def _update_tracking_state(self):
        """«Умный трекинг» доступен только вместе с обычным «Трекингом»."""
        if not self.face_track_var.get():
            self.smart_track_var.set(False)
        self.smart_track_cb.configure(state="normal" if self.face_track_var.get() else "disabled")

    # --- РЕЖИМЫ: «Нарезки» и «CS2» ---
    def _mv(self, name):
        """Переменная параметра текущего режима: crop, boost, subtitles, sub_advanced."""
        if self.mode == "cs2":
            return getattr(self, f"cs2_{name}_var")
        return {"crop": self.crop_var, "boost": self.boost_audio_var, "subtitles": self.subtitles_var,
                "sub_advanced": self.sub_advanced_var}[name]

    # общие поля блока «Параметры видео»: у каждого режима свои значения (сохраняются в config["mode_params"])
    def _shared_params_get(self) -> dict:
        return {"whisper_size": self.whisper_combo.get(), "max_clips": self.clips_count_entry.get().strip(),
                "sub_font": self.sub_font_combo.get(), "sub_size": int(round(self.sub_size_slider.get())),
                "sub_bg": bool(self.sub_bg_var.get()), "sub_word_by_word": bool(self.sub_wbw_var.get()),
                "sub_mirror": bool(self.sub_mirror_var.get()), "sub_female_colors": bool(self.sub_female_var.get()),
                "min_clip_sec": int(round(self.min_clip_slider.get())), "max_clip_sec": int(round(self.max_clip_slider.get())),
                "sub_fix": bool(self.sub_fix_var.get())}

    def _shared_params_set(self, v: dict):
        with suppress(Exception):
            self.whisper_combo.set(v["whisper_size"])
        if v.get("max_clips") is not None:
            self.clips_count_entry.delete(0, "end")
            self.clips_count_entry.insert(0, str(v["max_clips"]))
        with suppress(Exception):
            self.sub_font_combo.set(v["sub_font"])
        self.sub_size_slider.set(int(v["sub_size"]))
        self.sub_size_label.configure(text=f"Размер: {int(v['sub_size'])} px")
        self.sub_bg_var.set(bool(v["sub_bg"]))
        self.sub_wbw_var.set(bool(v["sub_word_by_word"]))
        self.sub_mirror_var.set(bool(v["sub_mirror"]))
        self.sub_female_var.set(bool(v["sub_female_colors"]))
        self.sub_fix_var.set(bool(v.get("sub_fix", False)))
        self.min_clip_slider.set(int(v["min_clip_sec"]))
        self.max_clip_slider.set(int(v.get("max_clip_sec", 60)))
        self._on_min_clip_sec_change(int(v["min_clip_sec"]))
        self._on_bg_or_wbw_toggle()

    def _on_mode_tab(self, value):
        mode = next((k for k, v in MODES.items() if v == value), "clips")
        if mode != self.mode:
            store = self.config_data.setdefault("mode_params", {})
            store[self.mode] = self._shared_params_get()
            # первый вход в режим — его начальные значения (как у новой программы), а не копия другого режима
            self._shared_params_set({**MODE_PARAM_DEFAULTS, **store.get(mode, {})})
            self.mode = mode
            self._apply_mode()

    def _apply_mode(self, save: bool = True):
        cs2 = self.mode == "cs2"
        show, hide = (self.params_grid_cs2, self.params_grid_clips) if cs2 else (self.params_grid_clips, self.params_grid_cs2)
        if not show.winfo_manager():  # новая сетка встаёт на место старой (перед панелью субтитров)
            anchor = hide if hide.winfo_manager() else self.clip_time_toggle_btn
            show.pack(**self._params_grid_pack, before=anchor)
        hide.pack_forget()
        if cs2:
            self.sub_female_cb.grid_remove()   # на матчах — только стандартные цвета голосов
        else:
            self.sub_female_cb.grid()
        self._update_cs2_state()
        self._update_subtitles_visibility()
        if save:
            self.save_config()

    def _update_cs2_state(self):
        """«Стример/Каст» имеет смысл только в вертикальном 9:16."""
        if not self.cs2_crop_var.get():
            self.cs2_cam_var.set(False)
        self.cs2_cam_cb.configure(state="normal" if self.cs2_crop_var.get() else "disabled")

    def _update_subtitles_visibility(self):
        cs2 = getattr(self, "mode", "clips") == "cs2"
        subs_var = self.cs2_subtitles_var if cs2 else self.subtitles_var
        adv_var = self.cs2_sub_advanced_var if cs2 else self.sub_advanced_var
        adv_cb = self.cs2_sub_advanced_cb if cs2 else self.sub_advanced_cb
        on = subs_var.get()
        if on:
            adv_cb.grid(row=2, column=1, sticky="w", pady=5)
        else:
            adv_var.set(False)
            adv_cb.grid_remove()
        if on and adv_var.get():
            self.sub_adv_panel.pack(fill="x", pady=(8, 0), before=self.clip_time_toggle_btn)
        else:
            self.sub_adv_panel.pack_forget()

    def _toggle_clip_time_section(self):
        self.clip_time_expanded = not self.clip_time_expanded
        self._on_min_clip_sec_change(self.min_clip_slider.get())
        if self.clip_time_expanded:
            self.clip_time_panel.pack(fill="x", pady=(6, 0))
        else:
            self.clip_time_panel.pack_forget()

    def _on_min_clip_sec_change(self, val, _from_max=False):
        sec = int(round(float(val)))
        mx = int(round(self.max_clip_slider.get()))
        if sec > mx:  # минимум не больше максимума: подвигаем второй ползунок
            if _from_max:
                sec = mx
                self.min_clip_slider.set(sec)
            else:
                mx = max(MAX_CLIP_LO, sec)
                self.max_clip_slider.set(mx)
        self.clip_time_toggle_btn.configure(
            text=f"{'▼' if self.clip_time_expanded else '▶'} Время клипа ({fmt_dur(sec)} – {fmt_dur(mx)})")
        self.min_clip_val_label.configure(text=f"{sec} сек (клипы короче {sec} с не сохраняются)")
        self.max_clip_val_label.configure(text=f"{fmt_dur(mx)} (длиннее — клип обрезается по концу фразы)")

    def _on_max_clip_sec_change(self, val):
        self._on_min_clip_sec_change(self.min_clip_slider.get(), _from_max=True)

    # --- ОБНОВЛЕНИЯ ---
    def _auto_check_updates(self):
        u = self.updater
        if u.enabled and u.state in ("idle", "error") and not u.checking:
            run_bg(u.check)
        self.after(UPDATE_INTERVAL_MS, self._auto_check_updates)

    def _on_update_state(self):
        u = self.updater
        show = u.available
        if show != getattr(self, "_update_btn_shown", False):
            self._update_btn_shown = show
            if show:
                self.update_btn.pack(side="left", padx=(0, 8), before=self.api_title)
                self.log(f"[*] Доступна новая версия {u.new_version} — нажмите значок загрузки слева вверху.")
            else:
                self.update_btn.pack_forget()
        sig = (u.checking, u.last_check, u.available, u.new_version)
        if sig != getattr(self, "_update_sig", None):  # настройки — только при смене статуса, не на каждый % загрузки
            self._update_sig = sig
            if self.settings.is_open:
                self.settings.render_section("updates")
        self.updates_overlay.refresh()
        if u.state == "ready" and not getattr(self, "_auto_install", False):
            self._auto_install = True  # скачали — сразу ставим, без лишних нажатий
            if self.is_running:
                self.log("[*] Обновление скачано — установится автоматически, когда закончится текущая обработка.")
            else:
                self.after(800, lambda: self.install_update(auto=True))

    def install_update(self, auto: bool = False):
        if auto and self.is_running:
            return  # дождёмся конца обработки (_end_job)
        if self.is_running:
            if not ask_yes_no(self, "Процесс в работе", "Сейчас идёт обработка или рендер видео!\n\nПерезапуск для обновления "
                                                        "остановит процесс, и текущий прогресс будет утерян.\n\nОбновить сейчас?"):
                return
        self._stop_and_save()
        if self.updater.install():
            self.destroy()
            os._exit(0)

    # --- БАЛАНС ТОКЕНОВ ---
    def _startup_balance_check(self):
        if self.api_key_var.get().strip():
            self.log("[*] Автопроверка лимитов ключа...")
            self.refresh_token_balance_async(silent=False, allow_browser=True)

    def refresh_token_balance_async(self, silent: bool = False, allow_browser: bool = True):
        api_key, base_url = self.api_key_var.get().strip(), self.base_url_var.get().strip()
        if not api_key:
            return
        self._balance_gen += 1
        gen = self._balance_gen
        if not silent:
            self.tokens_balance_var.set("Токены: проверка...")

        def _worker():
            txt = f"Токены: {TokifyBalanceChecker.fetch_remaining_tokens(api_key, base_url, allow_browser=allow_browser)}"

            def _apply():
                if gen != self._balance_gen:  # уже запущена более свежая проверка
                    return
                self.tokens_balance_var.set(txt)
                self.save_config()
                if not silent:
                    self.log(f"[*] Баланс ключа (https://tokify.sale/#dashboard): {txt}")
            self.after(0, _apply)
        run_bg(_worker)

    # --- СЕТКА ГАЛЕРЕИ ---
    def _calc_columns_count(self) -> int:
        scale = max(0.5, self._get_window_scaling())
        width = self.clips_scroll.winfo_width() / scale
        if width < 50:  # ещё не отрисована
            width = self.winfo_width() / scale - self.LEFT_W - 60
        return max(1, min(12, int(width - 20) // (TILE_W + 14)))

    def _on_window_resize(self, event):
        if event.widget is self:
            Popover.close_current()
            for ov in self.overlays:
                ov.on_resize()

    def _schedule_grid_check(self):
        if not self.created_clips:
            return
        if self._resize_after_id is not None:
            self.after_cancel(self._resize_after_id)
        self._resize_after_id = self.after(120, self._check_and_rearrange_grid)

    def _check_and_rearrange_grid(self):
        self._resize_after_id = None
        if self._calc_columns_count() != self._current_grid_cols:
            self._layout_tiles([t for _, t in (self._tiles.get(c["file_path"], (None, None)) for c in self.created_clips) if t])

    def _layout_tiles(self, tiles):
        cols = self._current_grid_cols = self._calc_columns_count()
        for c in range(12):
            self.clips_scroll.grid_columnconfigure(c, weight=1 if c < cols else 0)
        for i, tile in enumerate(tiles):
            pos = (i // cols, i % cols)
            if getattr(tile, "_cs_pos", None) != pos:  # двигаем только то, что сместилось
                tile.grid(row=pos[0], column=pos[1], padx=7, pady=7, sticky="n")
                tile._cs_pos = pos

    def _periodic_folder_sync(self):
        with suppress(Exception):
            before = len(self.created_clips)
            self.created_clips = [c for c in self.created_clips if Path(c["file_path"]).exists()]
            if len(self.created_clips) != before:
                self._save_gallery_db()
                self._refresh_clips_list_ui()
        self.after(180000, self._periodic_folder_sync)

    # --- ПЕРЕИМЕНОВАНИЕ ---
    def _start_inline_rename(self, tile, clip: dict):
        ent = entry(tile, width=TILE_W - 14, height=26, font=F(12, True), fg_color=MD3["surface_highest"],
                    border_color=MD3["primary"], corner_radius=8)
        ent.place(x=7, y=THUMB_SIZE[1] + 11)
        ent.insert(0, clip["title"])
        ent.select_range(0, tk.END)
        ent.focus_set()
        done = [False]

        def _finish(commit):
            if done[0]:
                return
            done[0] = True
            val = ent.get().strip()
            ent.destroy()
            if commit and val and val != clip["title"]:
                self._apply_clip_new_name(clip, val)
        ent.bind("<Return>", lambda _e: _finish(True))
        ent.bind("<FocusOut>", lambda _e: _finish(True))
        ent.bind("<Escape>", lambda _e: _finish(False))

    def _apply_clip_new_name(self, clip: dict, new_title: str):
        fpath = self._require_file(clip)
        if not fpath:
            return
        title = strip_num_prefix(safe_filename(new_title))
        if not title:
            return
        new_path = fpath.with_name(f"{title}{fpath.suffix}")
        try:
            if new_path != fpath:
                fpath.rename(new_path)
            if str(fpath) in self.selected_clip_paths:
                self.selected_clip_paths = (self.selected_clip_paths - {str(fpath)}) | {str(new_path)}
            if clip.get("yt_title", "") in ("", clip.get("title"), with_shorts(clip.get("title", ""))):
                clip["yt_title"] = with_shorts(title) if "#shorts" in clip.get("yt_title", "").lower() else title
            clip.update(title=title, file_path=str(new_path))
            self._save_gallery_db()
            self.log(f"[*] Клип переименован в: {new_path.name}")
            if self._drive_owns(clip):  # то же имя и на Google Drive
                fid = clip["gdrive"]["id"]

                def _w():
                    try:
                        self.drive.rename(fid, new_path.name)
                    except Exception as e:
                        self.log(f"[-] Google Drive: не удалось переименовать копию клипа: {e}")
                run_bg(_w)
            self._refresh_clips_list_ui()
        except Exception as e:
            messagebox.showerror("Ошибка переименования", f"Не удалось переименовать файл:\n{e}")

    def _rename_clip(self, clip: dict):
        val = ctk.CTkInputDialog(text=f"Введите новое название для клипа «{clip['title']}»:", title="Переименовать клип").get_input()
        if val and val.strip():
            self._apply_clip_new_name(clip, val.strip())

    # --- ПЛИТКИ ГАЛЕРЕИ ---
    @staticmethod
    def _tile_sig(clip: dict) -> tuple:
        return (clip["title"], id(clip.get("thumb_pil")), bool(clip.get("mirror")), clip.get("speakers_count", 1),
                round(float(clip["end"]) - float(clip["start"]), 1), bool((clip.get("gdrive") or {}).get("id")),
                tuple((p, len(v)) for p, v in sorted((clip.get("published") or {}).items()) if v))

    def _refresh_clips_list_ui(self):
        """Обновляет только изменившиеся плитки (без пересоздания всей галереи — без мигания)."""
        self.created_clips = [c for c in self.created_clips if Path(c["file_path"]).exists()]
        paths = [c["file_path"] for c in self.created_clips]
        self.selected_clip_paths &= set(paths)
        keep = {}
        for c in self.created_clips:
            c["title"] = strip_num_prefix(c["title"])
            if c.get("thumb_pil") is None:  # превью — до подписи плитки, иначе она каждый раз «новая»
                c["thumb_pil"] = get_cached_thumbnail(Path(c["file_path"]))
            old = self._tiles.get(c["file_path"])
            sig = self._tile_sig(c)
            if old and old[0] == sig and old[1].winfo_exists():
                keep[c["file_path"]] = old
            else:
                if old:
                    old[1].destroy()
                keep[c["file_path"]] = (sig, self._make_tile(c))
        for p, (_, t) in self._tiles.items():
            if p not in keep:
                t.destroy()
        self._tiles = keep
        self.tile_widgets_map = {p: t for p, (_, t) in keep.items()}
        self._layout_tiles([keep[p][1] for p in paths])
        self._update_tiles_selection_visuals()

    def _make_tile(self, clip: dict):
        path = clip["file_path"]
        tile = ctk.CTkFrame(self.clips_scroll, corner_radius=16, width=TILE_W, height=TILE_H)
        tile.grid_propagate(False)
        self._tile_style(tile, path)
        if clip.get("thumb_pil") is None:
            clip["thumb_pil"] = get_cached_thumbnail(Path(path))
        dur = max(1.0, float(clip["end"]) - float(clip["start"]))
        pub = [p for p in PUBLISH_PLATFORMS if (clip.get("published") or {}).get(p)]
        pil = decorate_thumb(clip["thumb_pil"], dur, clip.get("mirror"), bool((clip.get("gdrive") or {}).get("id")), pub)
        tile._thumb = ctk_image(pil, THUMB_SIZE)
        img_lbl = ctk.CTkLabel(tile, text="", image=tile._thumb, corner_radius=0, width=THUMB_SIZE[0], height=THUMB_SIZE[1],
                               fg_color="transparent")
        img_lbl.place(relx=0.5, y=8, anchor="n")  # ровно по центру плитки
        title = clip["title"] if len(clip["title"]) <= 13 else clip["title"][:12] + "…"
        title_lbl = label(tile, title, F(12, True), anchor="w", width=TILE_W - 40, cursor="xterm")
        title_lbl.place(x=9, y=THUMB_SIZE[1] + 13)
        title_lbl.bind("<Button-1>", lambda _e: self._start_inline_rename(tile, clip))
        sp = clip.get("speakers_count", 1)
        sub_lbl = label(tile, f"Персонажей: {sp}", F(11), "on_surface_var", anchor="w", width=TILE_W - 16)
        sub_lbl.place(x=9, y=THUMB_SIZE[1] + 35)
        dots = button(tile, "⋮", None, "ghost", width=26, height=26, corner_radius=13, font=F(16, True),
                      hover_color=MD3["surface_highest"])
        dots.configure(command=lambda: self._toggle_tile_menu(clip, dots))
        dots.place(x=TILE_W - 32, y=THUMB_SIZE[1] + 11)
        widgets = (tile, img_lbl, title_lbl, sub_lbl, dots)

        def _enter(_e):
            self._tile_style(tile, path, hover=True)

        def _leave(_e):
            under = tile.winfo_containing(*tile.winfo_pointerxy())
            if under is None or not str(under).startswith(str(tile)):
                self._tile_style(tile, path)

        for w in (tile, img_lbl, sub_lbl):
            self._bind_lasso_events(w, clip_path=path)
            w.bind("<Double-Button-1>", lambda _e: self._play_clip(clip))
        for w in widgets:
            w.bind("<Enter>", _enter)
            w.bind("<Leave>", _leave)
        if pub:  # подсказка над значком платформы: аккаунты, куда выложен клип
            def _badge_hover(e):
                k = img_lbl.winfo_width() / float(THUMB_SIZE[0]) or 1.0
                hit = next((p for p, (x0, y0, x1, y1) in publish_badge_rects(pub)
                            if x0 <= e.x / k <= x1 and y0 <= e.y / k <= y1), None)
                if hit is None:
                    return Tooltip.hide()
                names = ", ".join(x.get("name", "") for x in clip["published"][hit])
                Tooltip.show(img_lbl, f"{self._plat_title(hit)}: {names}", e.x_root, e.y_root, key=(path, hit))
            img_lbl.bind("<Motion>", _badge_hover, add="+")
            img_lbl.bind("<Leave>", lambda _e: Tooltip.hide(), add="+")
            w.bind("<Button-3>", lambda e: self._show_context_menu_at(clip, e.x_root, e.y_root))
        return tile

    # --- КОНТЕКСТНОЕ МЕНЮ ---
    def _delete_section(self, pop, items, expanded=False):
        """«Удалить ▸»: при наведении справа раскрывается вложенное меню с вариантами удаления."""
        on_drive = sum(1 for c in items if (c.get("gdrive") or {}).get("id"))
        others = list(pop.buttons)
        title = f"🗑  Удалить (выбрано: {len(items)})" if len(items) > 1 else "🗑  Удалить"
        head = pop.item(f"{title}  ▸", None, color=Popover.DANGER, keep_open=True)

        def _open(_e=None):
            if pop.child is not None or Popover.current is not pop:
                return
            fly = Popover(self, width=270, parent=pop)
            if on_drive:
                fly.caption("☁  Клип сохранён на Google Drive" if len(items) == 1 else f"☁  На Google Drive: {on_drive} из {len(items)}")
            fly.item("Удалить из галереи", lambda: self._batch_remove_from_gallery(items), color=Popover.DANGER)
            fly.item("Удалить полностью (с ПК и Google Drive)" if on_drive else "Удалить полностью",
                     lambda: self._batch_delete_completely(items), color=Popover.DANGER)
            fly.show_beside(head)

        def _close(_e=None):
            if pop.child is not None:
                pop.child.close()
        head.configure(command=_open)
        head.bind("<Enter>", _open, add="+")
        for b in others:  # навели на другой пункт — вложенное меню прячется
            b.bind("<Enter>", _close, add="+")
        if expanded:
            self.after(60, _open)

    def _toggle_tile_menu(self, clip: dict, btn):
        """Кнопка «⋮» на плитке: то же меню, что и по правому клику; повторное нажатие закрывает его."""
        if Popover.is_open_for(btn):
            return Popover.close_current()
        if Popover.just_closed_by(btn):
            return
        self._show_context_menu_at(clip, btn.winfo_rootx(), btn.winfo_rooty() + btn.winfo_height() + 4, anchor=btn)

    def _show_context_menu_at(self, clip: dict, x, y, anchor=None):
        path = clip["file_path"]
        pop = Popover(self, anchor=anchor, width=255)
        if path in self.selected_clip_paths and len(self.selected_clip_paths) > 1:
            items = [c for c in self.created_clips if c["file_path"] in self.selected_clip_paths]
            pop.caption(f"Выбрано клипов: {len(items)}")
            self._delete_section(pop, items, expanded=True)
            return pop.show(x, y)
        self.selected_clip_paths = {path}
        self._update_tiles_selection_visuals()
        pop.item("▶   Воспроизвести", lambda: self._play_clip(clip))
        acc = self._get_active_account()
        if acc is not None:
            target = "в TikTok" if acc.get("platform") == "tiktok" else "на YouTube"
            pop.item(f"📤  Загрузить {target}", lambda: self._upload_clip_to_active_platform(clip))
        pop.item("📂  Открыть в папке", lambda: self._open_clip_in_folder(clip))
        link = (clip.get("gdrive") or {}).get("link")
        if link:
            pop.item("☁   Открыть на Google Drive", lambda: __import__("webbrowser").open(link))
        elif self.drive.connected:
            pop.item("☁   Сохранить на Google Drive", lambda: self._drive_upload_from_menu(clip))
        pop.item("✏   Переименовать", lambda: self._rename_clip(clip))
        pop.item("🎬  Редактировать видео", lambda: self._edit_clip_video(clip))
        pop.separator()
        self._delete_section(pop, [clip])
        pop.show(x, y)

    def _require_file(self, clip: dict, resolve=False):
        p = Path(clip["file_path"])
        p = p.resolve() if resolve else p
        if p.exists():
            return p
        messagebox.showwarning(*NOT_FOUND_MSG)
        self._refresh_clips_list_ui()
        return None

    def _play_clip(self, clip: dict):
        if self._require_file(clip):
            self.player.open(clip)  # встроенный плеер, всегда с начала

    def _open_clip_in_folder(self, clip: dict):
        p = self._require_file(clip, resolve=True)
        if p:
            subprocess.Popen(["explorer.exe", f"/select,{p}"])

    def _edit_clip_video(self, clip: dict):
        if self._require_file(clip):
            VideoEditorWindow(self, clip)

    def _forget_clips(self, items):
        for c in items:
            if c in self.created_clips:
                self.created_clips.remove(c)
            self.selected_clip_paths.discard(c["file_path"])

    def _batch_remove_from_gallery(self, items: list):
        for c in items:
            with suppress(Exception):
                self.hidden_clip_paths.add(str(Path(c["file_path"]).resolve()))
        self._forget_clips(items)
        self._save_hidden_clips()
        self._save_gallery_db()
        self.log(f"[*] Удалено из галереи клипов: {len(items)} шт. (файлы в папке сохранены).")
        self._refresh_clips_list_ui()

    def _batch_delete_completely(self, items: list):
        self._forget_clips(items)
        deleted = 0
        for c in items:
            try:
                Path(c["file_path"]).unlink(missing_ok=True)
                deleted += 1
            except Exception as e:
                self.log(f"[!] Не удалось удалить файл {Path(c['file_path']).name}: {e}")
        self._save_gallery_db()
        self.log(f"[*] Полностью удалено клипов (из галереи и с диска): {deleted} шт.")
        self._refresh_clips_list_ui()
        self._drive_trash_clips(items)

    # --- ПЕРЕРЕНДЕР ОДНОГО КЛИПА ---
    def rerender_single_clip(self, clip: dict, on_done=None):
        if self.is_running:
            return
        self._begin_job("ИДЕТ ПЕРЕРЕНДЕР...")

        def _worker():
            ok = False
            try:
                out_file = Path(clip["file_path"])
                src = Path(clip["source_video"])
                src = src if src.exists() else out_file
                start_t = float(clip["start"])
                self.log(f"\n[*] Перерендер видео «{clip['title']}» с пользовательскими настройками...")
                self.set_progress(0.35, f"Перерендер видео: {clip['title']}...")
                renderer = SubtitleRenderer(
                    font_name=clip.get("font_name", "Arial"), font_size=int(clip.get("font_size", 70)),
                    bg_box=bool(clip.get("default_bg", False)), word_by_word=bool(clip.get("word_by_word", False)),
                    enable_female_colors=bool(clip.get("female_colors", False)), speaker_styles=clip.get("speaker_styles", {}))
                subs, sp_count, _ = self.speaker_tracker.render_clip(
                    video_path=src, start_t=start_t, duration=max(5.0, float(clip["end"]) - start_t), out_file=out_file,
                    num_tracks=int(clip.get("num_tracks", 1)), boost_audio=bool(clip.get("boost_audio", True)),
                    vertical=bool(clip.get("vertical", True)), use_tracker=bool(clip.get("use_tracker", True)),
                    smart_tracking=bool(clip.get("smart_tracking", False)), banner=clip.get("banner"),
                    layout=str(clip.get("layout", "")), log=self.log,
                    mirror_video=bool(clip.get("mirror", False)), enable_female_colors=bool(clip.get("female_colors", False)),
                    sub_segments=clip.get("subs", []), sub_renderer=renderer, keep_speakers=True,
                    cancel_check=lambda: self.cancel_requested, register_proc=self._register_subproc)
                clip["subs"] = subs
                clip["speakers_count"] = max(int(clip.get("speakers_count", 1)), sp_count)
                clip["thumb_pil"] = get_cached_thumbnail(out_file, force_refresh=True)
                self._save_gallery_db()
                if (clip.get("gdrive") or {}).get("id"):
                    if self._drive_owns(clip):
                        if self._drive_upload_clip(clip, replace=True,
                                                   progress=lambda f: self.set_progress(0.9 + f * 0.1, f"Обновление копии на Google Drive ({int(f * 100)}%)")):
                            self.log("    [+] Копия на Google Drive обновлена.")
                    else:
                        self.log("[!] Копия клипа на Google Drive не обновлена: подключите тот же аккаунт Google.")
                self.set_progress(1.0, f"Видео «{clip['title']}» успешно обновлено!")
                self.log(f"[+] Перерендер завершен! Файл перезаписан: {out_file.name}")
                self.after(0, self._refresh_clips_list_ui)
                ok = True
            except Cancelled:
                self.set_progress(0.0, "Перерендер остановлен пользователем")
                self.log("[!] Перерендер остановлен. Исходный файл клипа не изменён.")
            except Exception as e:
                self.log(f"[-] Ошибка перерендера клипа: {e}")
            finally:
                self._end_job()
                if on_done:
                    self.after(0, lambda: on_done(ok))
        run_bg(_worker)

    # --- ОКНО РАСШИФРОВКИ, ЛОГ, ПРОГРЕСС ---
    def open_transcript_window(self):
        if self.transcript_popup is not None and self.transcript_popup.winfo_exists():
            self.transcript_popup.focus()
            return
        self.transcript_popup = ctk.CTkToplevel(self)
        self.transcript_popup.title("Расшифровка текста видео (Живой просмотр)")
        self.transcript_popup.geometry("680x520")
        self.transcript_popup.configure(fg_color=MD3["bg"])
        self.popup_textbox = ctk.CTkTextbox(self.transcript_popup, font=("Consolas", 12), fg_color=MD3["surface_container"],
                                            text_color=MD3["on_surface"])
        self.popup_textbox.pack(fill="both", expand=True, padx=12, pady=12)
        if self.current_transcript_text:
            self.popup_textbox.insert(tk.END, self.current_transcript_text)
            self.popup_textbox.see(tk.END)

    def _transcript_boxes(self):
        popup_alive = self.transcript_popup is not None and self.transcript_popup.winfo_exists()
        return [self.transcript_box] + ([self.popup_textbox] if popup_alive else [])

    def append_transcript_line(self, line: str):
        self.current_transcript_text += line + "\n"

        def _upd():
            for box in self._transcript_boxes():
                box.insert(tk.END, f"{line}\n")
                box.see(tk.END)
        self.after(0, _upd)

    def clear_transcript(self):
        self.current_transcript_text = ""
        self.after(0, lambda: [box.delete("1.0", tk.END) for box in self._transcript_boxes()])

    def set_progress(self, fraction: float, status_text: str):
        fraction = max(0.0, min(1.0, fraction))

        def _upd():
            self.progress_bar.set(fraction)
            self.status_label.configure(text=f"[{int(fraction * 100)}%] {status_text}")
        self.after(0, _upd)

    def log(self, msg: str):
        def _append():
            self.log_box.insert(tk.END, f"{msg}\n")
            self.log_box.see(tk.END)
        self.after(0, _append)

    # --- БАННЕРЫ ---
    def _open_banners_dir(self):
        with suppress(Exception):
            BANNERS_DIR.mkdir(parents=True, exist_ok=True)
        with suppress(Exception):
            os.startfile(str(BANNERS_DIR)) if sys.platform == "win32" else subprocess.Popen(["xdg-open", str(BANNERS_DIR)])

    def _refresh_banners(self, _e=None):
        """Список файлов папки «banners»: обновляется при возврате в программу (например, из Проводника)."""
        now = time.time()
        if _e is not None and now - getattr(self, "_banner_scan_t", 0) < 1.0:
            return
        self._banner_scan_t = now
        with suppress(Exception):
            names = [BANNER_NONE] + list_banners()
            if names != getattr(self, "_banner_names", None):
                self._banner_names = names
                self.banner_combo.configure(values=names)
                if self.banner_var.get() not in names:
                    self.banner_var.set(BANNER_NONE)
                self._on_banner_change(save=False)

    def _on_banner_change(self, save: bool = True):
        on = self.banner_var.get() not in ("", BANNER_NONE)
        if on:
            self.banner_gear.pack(side="right", padx=(8, 0))
            self.banner_opts.pack(fill="x", pady=(8, 0), before=self._banner_time_label)
        else:
            self.banner_gear.pack_forget()
            self.banner_opts.pack_forget()
        if save:
            self.save_config()

    def _set_banner_xy(self, xy):
        name = self.banner_var.get()
        store = self.config_data.setdefault("banner_xy", {})
        if xy is None:
            store.pop(name, None)
        else:
            store[name] = banner_xy_value(xy)
        self.save_config()

    def banner_sound_for(self, name: str) -> bool:
        return bool((self.config_data.get("banner_sound") or {}).get(name, True))

    def _banner_spec(self, clip_dur: float):
        """Баннер для нового клипа: файл, начало (по выбранной трети), звук — или None."""
        name = self.banner_var.get()
        if name in ("", BANNER_NONE):
            return None
        info = probe_banner(name)
        if not info:
            return None
        pos = next((k for k, v in BANNER_POSITIONS.items() if v == self.banner_pos_var.get()), "middle")
        return {"file": name, "start": banner_auto_start(clip_dur, info["dur"], pos),
                "sound": bool(info.get("audio")) and self.banner_sound_for(name), "dur": round(info["dur"], 2),
                "xy": (self.config_data.get("banner_xy") or {}).get(name), "over_subs": bool(self.banner_over_var.get())}

    def pick_file(self):
        path = filedialog.askopenfilename(title="Выберите видеофайл", filetypes=[
            ("Video files", "*.mp4 *.mkv *.mov *.avi *.webm"), ("All files", "*.*")])
        if path:
            self.source_entry.delete(0, tk.END)
            self.source_entry.insert(0, path)

    # --- НЕЙРОСЕТЬ ---
    def _get_llm_client(self):
        from openai import OpenAI  # ленивый импорт для быстрого старта окна
        key = clean_api_key(self.api_key_var.get())
        if not key:
            raise ValueError("Поле API Ключ пустое!")
        return OpenAI(api_key=key, base_url=self.base_url_var.get().strip().rstrip("/"), timeout=180.0,
                      default_headers={"User-Agent": f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) ClipsStudio/{APP_VERSION}"})

    def _call_llm(self, messages, temperature=0.2, max_tokens=None) -> str:
        client = self._get_llm_client()
        kwargs = {"model": self.model_var.get().strip(), "messages": messages, "temperature": temperature}
        if max_tokens:
            kwargs["max_tokens"] = max_tokens
        with suppress(Exception):
            parts = [ch.choices[0].delta.content for ch in client.chat.completions.create(stream=True, **kwargs)
                     if ch.choices and ch.choices[0].delta and ch.choices[0].delta.content]
            result = "".join(parts).strip()
            if result:
                return result
        resp = client.chat.completions.create(stream=False, **kwargs)
        return (resp.choices[0].message.content or "").strip()

    def test_api(self):
        self.save_config()

        def _worker():
            try:
                self.log(f"[*] Проверка ключа (длина {len(self.api_key_var.get().strip())} симв.)...")
                ans = self._call_llm([{"role": "user", "content": "Ответь одним словом: Работает!"}], max_tokens=20)
                self.log(f"[+] УСПЕШНО! Профиль '{self.model_var.get().strip()}' ответил: {ans}")
                self.after(0, lambda: self.refresh_token_balance_async(silent=False))
            except Exception as e:
                self.log(f"[-] ОШИБКА API: {e}")
        run_bg(_worker)

    @staticmethod
    def _clean_json(raw: str):
        cleaned = re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL).strip()
        m = re.search(r"```(?:json)?\s*([\s\S]*?)```", cleaned)
        if m:
            cleaned = m.group(1).strip()
        s, e = cleaned.find("["), cleaned.rfind("]")
        if s != -1 and e > s:
            cleaned = cleaned[s:e + 1]
        return json.loads(cleaned)

    # --- КОНВЕЙЕР ОБРАБОТКИ ---
    def _run_proc(self, cmd) -> int:
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW_FLAG)
        self._register_subproc(proc)
        proc.wait()
        self._check_cancel()
        return proc.returncode

    @staticmethod
    def _probe_audio_streams(video_path) -> int:
        try:
            res = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=index",
                                  "-of", "csv=p=0", str(video_path)], capture_output=True, text=True, check=False,
                                 creationflags=NO_WINDOW_FLAG)
            return max(1, len([ln for ln in res.stdout.splitlines() if ln.strip()]))
        except Exception:
            return 1

    def _extract_clean_wav(self, video_path: Path, wav_path: Path, num_tracks: int):
        self.log(f"[*] Фоновое извлечение и усиление аудиодорожки (дорожек: {num_tracks})...")
        if num_tracks > 1:
            a_in = "".join(f"[0:a:{i}]" for i in range(num_tracks))
            af = ["-filter_complex", f"{a_in}amix=inputs={num_tracks}:duration=longest:dropout_transition=0,dynaudnorm=f=150:g=15"]
        else:
            af = ["-af", "dynaudnorm=f=150:g=15"]
        cmd = ["ffmpeg", "-y", "-i", str(video_path), *af, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(wav_path)]
        if self._run_proc(cmd) != 0:
            raise RuntimeError("Ошибка при извлечении аудиодорожки FFmpeg.")

    def _speech_is_russian(self, audio: np.ndarray):
        """Язык речи по первым минутам (Whisper tiny). None — определить не удалось (считаем, что русский)."""
        with suppress(Exception):
            from faster_whisper import WhisperModel
            m = _WHISPER_CACHE.get(("tiny", "cpu")) or WhisperModel(whisper_model("tiny"), device="cpu", compute_type="int8")
            lang, prob, *_ = m.detect_language(audio[:16000 * 180], vad_filter=True, language_detection_segments=3)
            self.log(f" -> Язык речи: {lang} ({prob:.0%}).")
            return lang == "ru" or prob < 0.6
        return None

    def _transcribe_gigaam(self, wav_path: Path):
        from types import SimpleNamespace
        audio = load_wav_for_whisper(wav_path)
        if isinstance(audio, str):
            raise RuntimeError("Не удалось прочитать звук для GigaAM.")
        self.log(" -> Инициализация GigaAM-v3 (русская речь, с пунктуацией)...")
        rec = self._cancellable(GigaAMRecognizer.get)
        spans = speech_chunks(audio)
        total = max(1.0, len(audio) / 16000.0)
        self.log(f" -> Длительность аудио: {total / 60:.1f} мин ({total:.0f} сек). Расшифровка началась...")
        lines, chunks, t0, last_pct = [], [], time.time(), -10
        for seg_no, (a, b) in enumerate(spans):
            self._check_cancel()
            words = rec.words(audio[a:b], a / 16000.0)
            if not words:
                continue
            text = " ".join(w["word"] for w in words)
            seg = SimpleNamespace(start=words[0]["start"], end=max(words[-1]["end"], b / 16000.0), text=text,
                                  words=[SimpleNamespace(**w) for w in words])
            sent = []  # строки транскрипции для нейросети — по предложениям (как короткие сегменты Whisper)
            for i, w in enumerate(words):
                sent.append(w)
                if w["word"].endswith((".", "!", "?", "…")) or i == len(words) - 1 or w["end"] - sent[0]["start"] > 12:
                    line = f"[{sent[0]['start']:.1f} - {sent[-1]['end']:.1f}] " + " ".join(x["word"] for x in sent)
                    lines.append(line)
                    self.append_transcript_line(line)
                    sent = []
            chunks += self._split_segment_words(seg, text, seg_no)
            ratio = min(1.0, b / 16000.0 / total)
            pct = int(ratio * 100)
            eta = int((time.time() - t0) / max(0.01, ratio) * (1.0 - ratio)) if ratio > 0.03 else 0
            self.set_progress(0.10 + ratio * 0.55, f"Распознавание речи: {pct}% ({b / 16000.0:.0f}с из {total:.0f}с)"
                                                   f"{f' | Осталось ~{eta} сек' if eta > 0 else ''}")
            if pct - last_pct >= 15:
                last_pct = pct
                self.log(f"   [Прогресс речи: {pct}%] распознано фраз: {len(lines)}")
        return lines, chunks

    def _transcribe_with_progress(self, wav_path: Path, w_size: str):
        if w_size == GIGAAM:
            if not gigaam_available():
                self.log(" [i] Модель GigaAM не установлена — распознаю Whisper (small).")
                w_size = "small"
            else:
                audio = load_wav_for_whisper(wav_path)
                if not isinstance(audio, str) and self._speech_is_russian(audio) is False:
                    self.log(" [i] Речь не на русском — GigaAM понимает только русский, распознаю Whisper (small).")
                    w_size = "small"
                else:
                    return self._transcribe_gigaam(wav_path)
        from faster_whisper import WhisperModel  # ленивый импорт при запуске задачи
        devices = ["cuda", "cpu"] if cuda_usable() else ["cpu"]
        if devices == ["cpu"] and _CUDA_STATE["why"]:
            self.log(f" [i] Распознавание на процессоре ({_CUDA_STATE['why']}).")
        for dev in devices:
            try:
                model = _WHISPER_CACHE.get((w_size, dev))
                if model is None:
                    self.log(f" -> Инициализация Whisper '{w_size}' ({dev.upper()})...")
                    model = WhisperModel(whisper_model(w_size), device=dev, compute_type="int8", cpu_threads=max(2, (os.cpu_count() or 4) - 1))
                    _WHISPER_CACHE.clear()  # держим в памяти только последнюю модель
                    _WHISPER_CACHE[(w_size, dev)] = model
                else:
                    self.log(f" -> Whisper '{w_size}' ({dev.upper()}) уже загружен.")
                self._check_cancel()
                segments, info = model.transcribe(load_wav_for_whisper(wav_path), vad_filter=True, vad_parameters=dict(min_silence_duration_ms=400),
                                                  beam_size=2, word_timestamps=True)
                total = max(1.0, float(info.duration or 1.0))
                self.log(f" -> Длительность аудио: {total / 60:.1f} мин ({total:.0f} сек). Расшифровка началась...")
                lines, chunks, t0, last_pct = [], [], time.time(), -10
                for seg_no, seg in enumerate(segments):
                    self._check_cancel()
                    text = seg.text.strip()
                    if not text:
                        continue
                    line = f"[{seg.start:.1f} - {seg.end:.1f}] {text}"
                    lines.append(line)
                    self.append_transcript_line(line)
                    chunks += self._split_segment_words(seg, text, seg_no)

                    ratio = min(1.0, seg.end / total)
                    pct = int(ratio * 100)
                    eta = int((time.time() - t0) / max(0.01, ratio) * (1.0 - ratio)) if ratio > 0.03 else 0
                    self.set_progress(0.10 + ratio * 0.55, f"Распознавание речи: {pct}% ({seg.end:.0f}с из {total:.0f}с)"
                                                           f"{f' | Осталось ~{eta} сек' if eta > 0 else ''}")
                    if pct - last_pct >= 15:
                        last_pct = pct
                        self.log(f"   [Прогресс речи: {pct}%] распознано фраз: {len(lines)}")
                return lines, chunks
            except Exception as e:
                if self.cancel_requested or isinstance(e, Cancelled) or dev == "cpu":
                    raise
                _CUDA_STATE.update(ok=False, why=str(e))  # до перезапуска CUDA больше не пробуем — повторная попытка может зависнуть
                _WHISPER_CACHE.pop((w_size, "cuda"), None)
                self.log(f" [i] Переключение с CUDA на процессор CPU ({e})...")

    @staticmethod
    def _split_segment_words(seg, text: str, seg_no: int = 0) -> list:
        """Нарезает сегмент Whisper на короткие субтитры (до 6 слов или до знака препинания).
        Каждый кусок помечается номером фразы «phrase»: персонаж определяется для фразы целиком.
        Новая фраза начинается после паузы > 0.6 с или после конца предложения с паузой > 0.25 с."""
        if not getattr(seg, "words", None):
            return [{"start": float(seg.start), "end": float(seg.end), "text": text, "phrase": f"{seg_no}:0"}]
        chunks, buf, phrase, prev = [], [], 0, None

        def _flush(end_t):
            if buf:
                chunks.append({"start": buf[0]["start"], "end": end_t, "text": " ".join(b["word"] for b in buf),
                               "words": list(buf), "phrase": f"{seg_no}:{phrase}"})
                buf.clear()

        for w in seg.words:
            wt = w.word.strip()
            if not wt:
                continue
            if prev is not None:
                gap = float(w.start) - prev["end"]
                if gap > 0.6 or (gap > 0.25 and prev["word"].endswith((".", "!", "?", "…"))):
                    _flush(prev["end"])
                    phrase += 1
            prev = {"word": wt, "start": float(w.start), "end": float(w.end)}
            buf.append(prev)
            if len(buf) >= 6 or wt.endswith((".", "!", "?", ",")):
                _flush(prev["end"])
        _flush(float(seg.end))
        return chunks

    def start_pipeline(self):
        if self.is_running:
            return
        self.save_config()
        source = self.source_entry.get().strip()
        if not source:
            messagebox.showwarning("Внимание", "Укажите путь к видеофайлу или ссылку!")
            return
        if not clean_api_key(self.api_key_var.get()):
            messagebox.showwarning("Нужен API ключ", "Укажите API ключ нейросети в Настройках → «Нейросеть».")
            return self.settings.open()
        self._active_subprocesses.clear()
        self.clear_transcript()
        self._gallery_switch_pending = True
        with suppress(Exception):
            self.tabs.set("Журнал")
        self._begin_job("ИДЁТ ОБРАБОТКА...")
        self.set_progress(0.02, "Подготовка...")
        run_bg(self._run_pipeline, source)

    def _sub_settings(self) -> dict:
        if self._mv("sub_advanced").get() and self._mv("subtitles").get():
            wbw = bool(self.sub_wbw_var.get())
            return dict(font=self.sub_font_combo.get(), size=int(round(self.sub_size_slider.get())), wbw=wbw,
                        bg=False if wbw else bool(self.sub_bg_var.get()), mirror=bool(self.sub_mirror_var.get()),
                        female=bool(self.sub_female_var.get()) and self.mode != "cs2", fix=bool(self.sub_fix_var.get()))
        return dict(font="Arial", size=70, wbw=False, bg=False, mirror=False, female=False, fix=False)

    def _ask_llm_for_clips(self, transcript: str, max_clips: int, min_sec: int, context: str = "", max_sec: int = 60) -> list:
        max_sec = max(min_sec, int(max_sec))
        prompt = (
            f"Проанализируй транскрипцию видео с таймкодами в секундах и выбери до {max_clips} самых интересных, "
            f"динамичных или смешных моментов для вертикальных Shorts/Reels длительностью от {min_sec} до {max_sec} секунд "
            f"каждый (строго не длиннее {max_sec} секунд; момент должен быть законченным).\n\n"
            + (CS2_PROMPT if getattr(self, "mode", "clips") == "cs2" else "")
            + f"Для каждого клипа подготовь SEO-оформление, чтобы его находили в поиске YouTube и Google и рекомендовали в ленте Shorts. "
            f"Пиши на языке видео. Опирайся только на то, что есть в транскрипции и сведениях об источнике, — ничего не выдумывай "
            f"(имена, названия игр, шоу, фильмов, мест бери только оттуда).\n"
            f"- title: до 70 символов. В начале — главное ключевое слово/фраза, которую человек ввёл бы в поиск "
            f"(тема, имя, название игры/шоу). Цепляет и интригует, но честно, без обмана и кликбейта. "
            f"Без хэштегов, номеров в начале, КАПСА и кавычек; максимум один эмодзи.\n"
            f"- description: 1–2 коротких предложения (до 200 символов). Не повторяй название слово в слово: "
            f"раскрой момент другими словами, добавь синонимы и уточняющие ключевые слова. Без хэштегов.\n"
            f"- hashtags: 2–4 тематических хэштега через пробел: один широкий (тема) и 1–3 узких (имя, игра, шоу, конкретная тема). "
            f"Не используй пустые общие теги вроде #рек #fyp #viral #тренды. #shorts добавлять не нужно.\n"
            f"- tags: 8–15 поисковых фраз через запятую (без #): главные ключевые слова, имена, название источника, "
            f"тема, варианты написания и запросы, по которым ищут такие моменты.\n"
            f"Верни СТРОГО JSON-массив без лишнего текста в формате:\n"
            f'[{{"start": 12.5, "end": 45.0, "title": "Ключевая фраза: суть момента", "description": "О чём момент другими словами", '
            f'"hashtags": "#тема #имя", "tags": "ключевая фраза, имя, название, тема"}}]\n\n'
            + (f"Сведения об источнике:\n{context[:1500]}\n\n" if context else "")
            + f"Транскрипция:\n{transcript[:65000]}"
        )
        messages = [{"role": "system", "content": "Ты профессиональный монтажёр вирусных Shorts/Reels и SEO-специалист YouTube. "
                                                  "Отвечай только валидным JSON."},
                    {"role": "user", "content": prompt}]
        for attempt in range(1, 4):
            self._check_cancel()
            try:
                return self._clean_json(self._cancellable(self._call_llm, messages=messages, temperature=0.2)) or []
            except Cancelled:
                raise
            except Exception as e:
                self.log(f"[!] Попытка {attempt}/3 не удалась ({e}). Повтор через 4 сек...")
                if attempt == 3:
                    raise
                self._sleep_cancellable(4)
        return []

    def _fix_subtitles(self, chunks: list, cs2: bool) -> int:
        """Исправление ошибок распознавания нейросетью: точечные правки, проверяемые программой (apply_sub_fix)."""
        gloss = set(cs2_dictionary()[1]) | {_norm_word(t) for t in CS2_TERMS_RU.split(", ")} if cs2 else set()
        done = 0
        for b0 in range(0, len(chunks), 60):
            self._check_cancel()
            batch = chunks[b0:b0 + 60]
            if not any(ch.get("words") for ch in batch):
                continue
            messages = [{"role": "system", "content": "Ты корректор субтитров. Исправляешь только явные ошибки "
                                                      "распознавания речи. Отвечай только валидным JSON."},
                        {"role": "user", "content": subfix_prompt(batch, cs2)}]
            try:
                edits = self._clean_json(self._cancellable(self._call_llm, messages=messages, temperature=0.0)) or []
            except Cancelled:
                raise
            except Exception as e:
                self.log(f" [!] Исправление субтитров пропущено ({e}).")
                continue
            per_line, limit = {}, max(3, sum(len(ch.get("words") or []) for ch in batch) // 4)
            for ed in edits if isinstance(edits, list) else []:
                with suppress(Exception):
                    li, frm, to = int(ed["line"]) - 1, str(ed["from"]).strip(), str(ed["to"]).strip()
                    if not (0 <= li < len(batch)) or per_line.get(li, 0) >= SUBFIX_MAX_PER_LINE or limit <= 0:
                        continue
                    ch = batch[li]
                    if ch.get("words") and apply_sub_fix(ch["words"], frm, to, gloss):
                        ch["text"] = " ".join(w["word"] for w in ch["words"])
                        per_line[li] = per_line.get(li, 0) + 1
                        limit -= 1
                        done += 1
        return done

    def _run_pipeline(self, source: str):
        temp_wav, out_dir, rendered, uploaded, source_ctx = None, None, 0, 0, ""
        try:
            cloud = self.cloud_mode()
            folder = self.config_data.get("gdrive_folder", "Клипы")
            out_dir = (CLOUD_CACHE_DIR if cloud else self.local_root()) / f"Clips_Output_{int(time.time())}"
            try:
                out_dir.mkdir(parents=True, exist_ok=True)
            except OSError as e:
                out_dir = Path.home() / "Desktop" / out_dir.name
                self.log(f"[!] Папка хранилища недоступна ({e}) — клипы будут сохранены на Рабочий стол.")
                out_dir.mkdir(parents=True, exist_ok=True)
            self.log("\n=== ЗАПУСК ОБРАБОТКИ ===\n" + (f"Клипы сохраняются на Google Drive: /{folder}" if cloud
                                                       else f"Папка для готовых клипов: {out_dir}"))

            if source.startswith(("http://", "https://")):
                self.set_progress(0.04, "Скачивание видео по ссылке в фоне...")
                self.log("[1/4] Скачивание видео через yt-dlp (без окон)...")
                video_path = out_dir / "source_video.mp4"
                proxy = self._cancellable(self.yt_bypass.proxy_for, source, lambda: self.cancel_requested)
                try:
                    code = self._run_proc(["yt-dlp", "-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
                                           *(["--proxy", proxy] if proxy else []), "--socket-timeout", "30",
                                           "--write-info-json", "-o", str(video_path), source])
                finally:
                    self.yt_bypass.stop()
                if code != 0:
                    raise RuntimeError("Не удалось скачать видео по ссылке."
                                       + ("" if proxy else " Если YouTube заблокирован — включите «Обход блокировок YouTube» "
                                                         "или укажите прокси в Настройках → «Сеть»."))
                for info_file in out_dir.glob("*.info.json"):  # название, автор и теги исходника — для SEO
                    with suppress(Exception):
                        info = json.loads(info_file.read_text(encoding="utf-8"))
                        source_ctx = "\n".join(x for x in (
                            f"Название: {info.get('title', '')}", f"Автор/канал: {info.get('uploader') or info.get('channel') or ''}",
                            f"Теги: {', '.join((info.get('tags') or [])[:20])}",
                            f"Описание: {str(info.get('description') or '')[:600]}") if x.split(": ", 1)[1])
                    with suppress(Exception):
                        info_file.unlink()
            else:
                video_path = Path(source)
                if not video_path.exists():
                    raise FileNotFoundError(f"Файл не найден: {video_path}")
                stem = re.sub(r"[_\.]+", " ", video_path.stem).strip()
                if len(re.findall(r"[^\W\d]{3,}", stem)) >= 2:  # осмысленное имя файла — подсказка для SEO
                    source_ctx = f"Имя файла: {stem}"
                self.log(f"[1/4] Открыт локальный файл: {video_path.name}")

            self.set_progress(0.07, "Извлечение и микширование аудиодорожек...")
            num_tracks = self._probe_audio_streams(video_path)
            temp_wav = Path(os.environ.get("TEMP", str(DATA_ROOT))) / f"temp_clip_audio_{int(time.time())}.wav"
            self._extract_clean_wav(video_path, temp_wav, num_tracks)

            w_size = self.whisper_combo.get()
            self.set_progress(0.10, f"Запуск распознавания речи Whisper ({w_size})...")
            self.log("[2/4] Распознавание речи и таймкодов слов...")
            lines, sub_chunks = self._cancellable(self._transcribe_with_progress, temp_wav, w_size)
            if not lines:
                raise RuntimeError("В видео не обнаружена речь для анализа.")
            if self.mode == "cs2":  # словарь CS2: ники и команды латиницей, термины по-русски
                n = apply_cs2_dictionary(sub_chunks)
                fixed = []
                for ln in lines:
                    m = re.match(r"^(\[[^\]]*\]\s*)(.*)$", ln)
                    head, body = (m.group(1), m.group(2)) if m else ("", ln)
                    tmp = [{"words": [{"word": w, "start": 0, "end": 0} for w in body.split()]}]
                    apply_cs2_dictionary(tmp)
                    fixed.append(head + tmp[0].get("text", body))
                lines = fixed
                if n:
                    self.log(f"[+] Словарь CS2: исправлено ников и терминов в субтитрах — {n}.")
            self.log(f"[+] Транскрипция завершена на 100% (фраз: {len(lines)}, субтитров: {len(sub_chunks)}).")

            max_clips = int(self.clips_count_entry.get().strip() or 5)
            min_sec = int(round(self.min_clip_slider.get()))
            max_sec = max(min_sec, int(round(self.max_clip_slider.get())))
            model_name = self.model_var.get().strip()
            self.set_progress(0.68, f"Нейросеть {model_name} выбирает моменты, генерирует названия, описания и хэштеги...")
            self.log(f"[3/4] Анализ текста моделью {model_name} (поиск топ-{max_clips} клипов, длительность: {fmt_dur(min_sec)} – {fmt_dur(max_sec)})...")
            raw_clips = self._ask_llm_for_clips("\n".join(lines), max_clips, min_sec, source_ctx, max_sec)
            clips_data = []
            for c in raw_clips:
                with suppress(Exception):
                    st, en = float(c.get("start", 0.0)), float(c.get("end", 0.0))
                    new_en = fit_clip_end(st, en, max_sec, min_sec, sub_chunks)
                    if new_en < en:
                        self.log(f" [Обрезка] Клип «{c.get('title', 'Без названия')}» ({en - st:.1f} сек) длиннее максимума "
                                 f"({fmt_dur(max_sec)}) — укорочен до {new_en - st:.1f} сек.")
                        c["end"] = new_en
                dur = float(c.get("end", 0.0)) - float(c.get("start", 0.0))
                if dur + 0.05 < min_sec:
                    self.log(f" [Пропуск] Клип «{c.get('title', 'Без названия')}» ({dur:.1f} сек) короче заданного минимума "
                             f"({min_sec} сек) — не сохраняется.")
                else:
                    clips_data.append(c)
            total = len(clips_data)
            self.log(f"[+] Подходящих по времени клипов: {total} (отсеяно слишком коротких: {len(raw_clips) - total}).")
            if total == 0:
                self.set_progress(1.0, "Нет клипов подходящей длительности")
                self.log(f"[!] Все найденные моделью клипы оказались короче {min_sec} сек. "
                         f"Попробуйте уменьшить порог в разделе 'Время клипа'.")
                return

            cs2 = self.mode == "cs2"
            s = self._sub_settings()
            if s.get("fix") and self._mv("subtitles").get():
                spans = [(float(c["start"]), float(c["end"])) for c in clips_data]
                todo = [x for x in sub_chunks if any(x["end"] >= a and x["start"] <= b for a, b in spans)]
                self.set_progress(0.70, "Нейросеть проверяет субтитры...")
                self.log(f"[*] Проверка субтитров нейросетью (строк: {len(todo)})...")
                n = self._fix_subtitles(todo, cs2)
                self.log(f"[+] Исправлено слов и фраз в субтитрах: {n} (в редакторе подсвечены красным).")
            vertical, boost = self._mv("crop").get(), self._mv("boost").get()
            use_tracker = False if cs2 else self.face_track_var.get()   # в CS2 кадр по центру либо раскладка «камера + матч»
            smart = use_tracker and self.smart_track_var.get()
            layout = "cam_top" if cs2 and vertical and self.cs2_cam_var.get() else ""
            enable_subs = self._mv("subtitles").get()
            s = self._sub_settings()
            mode = "word" if s["wbw"] else ("bg" if s["bg"] else "text")
            self.log("[4/4] Рендер видеоклипов" + (" (веб-камера сверху, матч снизу)..." if layout else " (по центру)..." if cs2 or not use_tracker else " (умный трекинг)..." if smart else " (статичные планы + Cut)..."))

            jobs, taken = [], set()  # имена файлов резервируются заранее: клипы могут рендериться параллельно
            for idx, clip in enumerate(clips_data, 1):
                start_t, end_t = float(clip["start"]), float(clip["end"])
                base = safe_filename(strip_num_prefix(clip.get("title", f"Клип {idx}").strip()))[:55] or f"Клип_{int(time.time())}"
                out_file, dup = out_dir / f"{base}.mp4", 2
                while out_file.exists() or out_file in taken:
                    out_file, dup = out_dir / f"{base} ({dup}).mp4", dup + 1
                taken.add(out_file)
                jobs.append((idx, clip, start_t, end_t, out_file))

            trackers, abort = threading.local(), threading.Event()  # abort: ошибка одного клипа останавливает второй
            stopped = lambda: self.cancel_requested or abort.is_set()

            banners = {}

            def render_job(job):
                idx, clip, start_t, end_t, out_file = job
                banners[idx] = self._banner_spec(end_t - start_t)
                if stopped():
                    raise Cancelled()
                title = out_file.stem
                self.log(f" -> [{idx}/{total}] Рендер: {title} ({start_t:.1f}с - {end_t:.1f}с, длина: {end_t - start_t:.1f}с)...")
                if not hasattr(trackers, "t"):  # у каждого потока свой детектор (YuNet не потокобезопасен)
                    trackers.t = self.speaker_tracker if workers == 1 else ActiveSpeakerTracker()
                renderer = SubtitleRenderer(s["font"], s["size"], s["bg"], s["wbw"], s["female"]) if enable_subs else None
                return trackers.t.render_clip(
                    video_path=video_path, start_t=start_t, duration=end_t - start_t, out_file=out_file,
                    num_tracks=num_tracks, boost_audio=boost, vertical=vertical, use_tracker=use_tracker,
                    smart_tracking=smart, layout=layout, log=self.log, mirror_video=s["mirror"], enable_female_colors=s["female"],
                    sub_segments=[dict(x) for x in sub_chunks if x["end"] >= start_t and x["start"] <= end_t],
                    sub_renderer=renderer, voice_wav=temp_wav, banner=banners[idx],
                    cancel_check=stopped, register_proc=self._register_subproc)

            # «Параллельный рендер» (Настройки, выкл. по умолчанию, нужно 6+ физических ядер): два клипа
            # одновременно. Результат каждого клипа тот же, что и при последовательном рендере.
            workers = 2 if self.config_data.get("parallel_render") and parallel_render_available() and len(jobs) > 1 else 1
            self.set_progress(0.72, f"Рендер клипов: 0 из {total}...")
            with ThreadPoolExecutor(max_workers=workers) as pool:
                futures = [pool.submit(render_job, j) for j in jobs]
                try:
                    for (idx, clip, start_t, end_t, out_file), fut in zip(jobs, futures):
                        subs, sp_count, genders = fut.result()
                        title = out_file.stem
                        yt_title = seo_title(clip.get("title")) or title
                        rendered += 1
                        self.set_progress(0.72 + idx / total * 0.28, f"Готово клипов: {idx} из {total}")
                        self.created_clips.insert(0, {
                            "title": title, "yt_title": yt_title,
                            "yt_description": seo_description(clip.get("description"), seo_hashtags(clip.get("hashtags"))),
                            "yt_tags": ", ".join(seo_tags(clip.get("tags"))),
                            "file_path": str(out_file), "source_video": str(video_path), "start": start_t, "end": end_t,
                            "subs": subs, "speakers_count": sp_count,
                            "speaker_styles": assign_speaker_colors(sp_count, genders, mode, enable_female_colors=s["female"]),
                            "font_name": s["font"], "font_size": s["size"], "default_bg": s["bg"], "word_by_word": s["wbw"],
                            "mirror": s["mirror"], "female_colors": s["female"], "num_tracks": num_tracks, "boost_audio": boost,
                            "vertical": vertical, "use_tracker": use_tracker, "smart_tracking": smart,
                            "banner": banners.get(idx), "mode": self.mode, "layout": layout,
                            "thumb_pil": get_cached_thumbnail(out_file, force_refresh=True),
                        })
                        self._save_gallery_db()
                        self.after(0, self._show_clips_section_after_job)
                        if cloud:
                            status = f"Загрузка на Google Drive {idx} из {total}: {title}"
                            if self._drive_upload_clip(self.created_clips[0], cancelled=lambda: self.cancel_requested,
                                                       progress=lambda f, st=status, i=idx: self.set_progress(
                                                           0.72 + (i - 1 + f) / total * 0.28, f"{st} ({int(f * 100)}%)")):
                                uploaded += 1
                                self.log(f"    [+] Сохранено на Google Drive: /{folder}/{out_file.name}")
                except BaseException:
                    abort.set()
                    for f in futures:
                        f.cancel()
                    raise

            self.set_progress(1.0, f"Готово! Сделано клипов: {total}")
            where = (f"на Google Drive в папку /{folder} ({uploaded} из {total} шт.), рабочие копии на ПК:" if cloud
                     else "в папку:")
            self.log(f"\n[100% ГОТОВО!] Все подходящие клипы сохранены {where}\n{out_dir}")
        except Cancelled:
            self.set_progress(0.0, "Остановлено пользователем")
            kept = f" Уже готовые клипы ({rendered} шт.) сохранены." if rendered else ""
            self.log(f"[!] Процесс остановлен пользователем. Прогресс текущей обработки утерян.{kept}")
            if out_dir and rendered == 0:
                shutil.rmtree(out_dir, ignore_errors=True)
        except Exception as e:
            self.set_progress(0.0, "Ошибка при выполнении")
            self.log(f"\n[КРИТИЧЕСКАЯ ОШИБКА]: {e}")
        finally:
            self._active_subprocesses.clear()
            if temp_wav:
                with suppress(Exception):
                    temp_wav.unlink(missing_ok=True)
            was_cancelled = self.cancel_requested
            self._end_job()
            if not was_cancelled:
                self.after(0, lambda: self.refresh_token_balance_async(silent=False, allow_browser=True))


def main():
    migrate_legacy_data()
    ClipsStudioSK().mainloop()


if __name__ == "__main__":
    main()
