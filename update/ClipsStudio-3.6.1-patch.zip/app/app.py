import os
import re
import sys
import json
import time
import wave
import uuid
import hashlib
import shutil
import subprocess
import threading
import textwrap
import tkinter as tk
from io import BytesIO
from pathlib import Path
from contextlib import suppress
from functools import lru_cache
import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import customtkinter as ctk
from tkinter import filedialog, messagebox, colorchooser

NO_WINDOW_FLAG = subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
LOCALAPPDATA = Path(os.environ.get("LOCALAPPDATA", "C:/"))
# Установленная программа: <папка>/ClipsStudio.exe, код в <папка>/app, FFmpeg и yt-dlp в <папка>/tools, модели в <папка>/models
INSTALL_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else None
LEGACY_ROOT = Path("C:/ClipsStudio_Build")  # данные старых сборок (до v3.6)
os.environ["PLAYWRIGHT_BROWSERS_PATH"] = str(LOCALAPPDATA / "ms-playwright")
os.environ["PATH"] = os.pathsep.join(
    [str(d / "tools") for d in (INSTALL_DIR, LEGACY_ROOT) if d] + [os.environ.get("PATH", "")])

# Быстрая инициализация путей CUDA только в папке site-packages
for _root in sys.path:
    if "site-packages" in _root:
        _nv = Path(_root) / "nvidia"
        if _nv.exists():
            for _bin in _nv.rglob("bin"):
                os.environ["PATH"] = str(_bin) + os.pathsep + os.environ.get("PATH", "")
                if hasattr(os, "add_dll_directory"):
                    with suppress(Exception):
                        os.add_dll_directory(str(_bin))
        break

ctk.set_appearance_mode("Dark")

APP_VERSION = "3.6.1"
MD3 = {
    "bg": "#141218", "surface": "#1D1B20", "surface_container": "#211F26", "surface_high": "#2B2930",
    "surface_highest": "#36343B", "primary": "#D0BCFF", "primary_hover": "#E8DEF8", "on_primary": "#381E72",
    "secondary_container": "#4A4458", "on_secondary": "#E8DEF8", "tertiary": "#EFB8C8", "on_surface": "#E6E0E9",
    "on_surface_var": "#CAC4D0", "outline": "#49454F", "error": "#F2B8B5", "error_container": "#8C1D18",
    "success_container": "#1E3A2F", "on_success": "#A6F4C5", "selected_card": "#3F3459", "selected_border": "#D0BCFF",
}

DATA_ROOT = LOCALAPPDATA / "ClipsStudio"  # настройки, галерея, аккаунты — не затрагиваются обновлениями и переустановкой
CONFIG_FILE = DATA_ROOT / "config_sk.json"
GALLERY_DB_FILE = DATA_ROOT / "clips_gallery_db.json"
HIDDEN_CLIPS_FILE = DATA_ROOT / "hidden_clips.json"
THUMBS_CACHE_DIR = DATA_ROOT / "thumbs_cache"
YT_PROFILES_ROOT = DATA_ROOT / "yt_profiles"
YT_ACCOUNTS_FILE = DATA_ROOT / "yt_accounts.json"
THUMB_SIZE = (198, 122)
LEGACY_DATA_FILES = ("config_sk.json", "clips_gallery_db.json", "hidden_clips.json", "yt_accounts.json",
                     "gdrive_auth.json", "google_client.json", "gdrive_avatar.png")


def migrate_legacy_data():
    """Однократный перенос настроек из C:\\ClipsStudio_Build (старые сборки) в папку данных пользователя."""
    if (DATA_ROOT / "config_sk.json").exists() or not (LEGACY_ROOT / "config_sk.json").exists():
        return
    DATA_ROOT.mkdir(parents=True, exist_ok=True)
    for name in LEGACY_DATA_FILES:
        with suppress(Exception):
            if (LEGACY_ROOT / name).exists():
                shutil.copy2(LEGACY_ROOT / name, DATA_ROOT / name)


def load_wav_for_whisper(wav_path: Path):
    """WAV 16 кГц моно → массив для Whisper напрямую (без PyAV: его новые версии ломают чтение файлов в faster-whisper)."""
    with suppress(Exception):
        with wave.open(str(wav_path), "rb") as wf:
            if wf.getframerate() == 16000 and wf.getnchannels() == 1 and wf.getsampwidth() == 2:
                return np.frombuffer(wf.readframes(wf.getnframes()), dtype=np.int16).astype(np.float32) / 32768.0
    return str(wav_path)


def whisper_model(size: str) -> str:
    """Модель Whisper из папки установки (работает без скачивания); иначе — имя для загрузки из интернета."""
    for base in (INSTALL_DIR, LEGACY_ROOT / "vendor"):
        if base and (base / "models" / f"faster-whisper-{size}" / "model.bin").exists():
            return str(base / "models" / f"faster-whisper-{size}")
    return size
STARTUP_BALANCE_DELAY_MS = 4000

TOKIFY_MODELS = [
    "claude-opus-5.5", "claude-opus-5", "claude-opus-5-thinking", "claude-fable-5.1", "claude-fable-5",
    "claude-opus-4.8", "claude-opus-4.7", "gpt-6-astra", "gpt-6-reasoning-pro", "gpt-6-sol", "gpt-5.6-sol",
    "gpt-5.6-luna",
]
DEFAULT_SPEAKER_HEX = ["#ebb521", "#eb7c21", "#e8e523", "#66d124", "#38a8e0", "#8938e0"]
FEMALE_SPEAKER_HEX = ["#f252c0", "#f5e23b", "#ed6461", "#ade85f"]
FONT_MAP = {
    "Arial": ["arialbd.ttf", "arial.ttf"], "Segoe UI": ["segoeuib.ttf", "segoeui.ttf"],
    "Impact": ["impact.ttf", "arialbd.ttf"], "Verdana": ["verdanab.ttf", "verdana.ttf"],
    "Tahoma": ["tahomabd.ttf", "tahoma.ttf"], "Trebuchet MS": ["trebucbd.ttf", "trebuc.ttf"],
    "Comic Sans MS": ["comicbd.ttf", "comic.ttf"], "Courier New": ["courbd.ttf", "cour.ttf"],
}
DEFAULT_CONFIG = {
    "api_key": "", "base_url": "https://tokify.sale/v1", "model": "claude-opus-5.5", "whisper_size": "small",
    "max_clips": "5", "boost_audio": True, "face_track": True, "subtitles": False, "sub_advanced": False,
    "sub_font": "Arial", "sub_size": 70, "sub_bg": False, "sub_word_by_word": False, "sub_mirror": False,
    "sub_female_colors": False, "min_clip_sec": 5, "last_tokens_balance": "—",
    "storage_mode": "local", "local_dir": "", "gdrive_folder": "Клипы",
}
NOT_FOUND_MSG = ("Файл не найден", "Этот клип был удален из папки на диске.")


class Cancelled(Exception):
    def __init__(self, msg="Остановлено пользователем."):
        super().__init__(msg)


# ---------------------------- ОБЩИЕ ХЕЛПЕРЫ ----------------------------
def run_bg(fn, *args):
    threading.Thread(target=fn, args=args, daemon=True).start()


def read_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default


def write_json(path: Path, data):
    with suppress(Exception):
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def clean_api_key(raw: str) -> str:
    key = str(raw or "").strip()
    if key.lower().startswith("bearer "):
        key = key[7:].strip()
    return re.sub(r"\d{1,2}:\d{2}$", "", key).strip("\"' ")


def strip_num_prefix(name) -> str:
    name = str(name).strip()
    return re.sub(r"^\d+[\s_\-]+", "", name) or name


def safe_filename(name: str) -> str:
    return re.sub(r'[\\/*?:"<>|]', "", name).strip()


def with_shorts(title: str) -> str:
    return title if "#shorts" in title.lower() else f"{title} #Shorts"


def hex_to_rgb(hex_str):
    h = str(hex_str).lstrip("#")
    with suppress(Exception):
        if len(h) == 6:
            return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))
    return (235, 181, 33)


def speaker_hex(idx: int) -> str:
    return DEFAULT_SPEAKER_HEX[idx % len(DEFAULT_SPEAKER_HEX)]


def format_token_number(val) -> str:
    try:
        num = float(val)
        if num >= 1e9:
            return f"{num / 1e9:.2f} млрд"
        if num >= 1e6:
            return f"{num / 1e6:.2f} млн"
        return f"{int(num):,}".replace(",", " ")
    except Exception:
        return str(val)


@lru_cache(maxsize=1)
def find_system_browser_exe() -> str:
    pf = Path(os.environ.get("ProgramFiles", "C:/Program Files"))
    pf86 = Path(os.environ.get("ProgramFiles(x86)", "C:/Program Files (x86)"))
    chrome = "Google/Chrome/Application/chrome.exe"
    edge = "Microsoft/Edge/Application/msedge.exe"
    for c in (pf / chrome, pf86 / chrome, LOCALAPPDATA / chrome, pf86 / edge, pf / edge):
        if c.exists():
            return str(c)
    pw_dir = LOCALAPPDATA / "ms-playwright"
    if pw_dir.exists():
        for exe in pw_dir.rglob("chrome.exe"):
            return str(exe)
    return ""


def launch_browser_context(pw, user_data_dir: str, headless: bool, width: int, height: int):
    kwargs = {
        "user_data_dir": user_data_dir, "headless": headless, "viewport": {"width": width, "height": height},
        "args": [f"--window-size={width + 20},{height + 40}", "--disable-blink-features=AutomationControlled",
                 "--no-first-run", "--no-default-browser-check"],
        "ignore_default_args": ["--enable-automation"],
    }
    exe_path = find_system_browser_exe()
    if exe_path:
        return pw.chromium.launch_persistent_context(executable_path=exe_path, **kwargs)
    for ch in ("msedge", "chrome"):
        with suppress(Exception):
            return pw.chromium.launch_persistent_context(channel=ch, **kwargs)
    return pw.chromium.launch_persistent_context(**kwargs)


def make_avatar_with_platform_badge(avatar_path: str, platform: str, size: int = 28) -> Image.Image:
    base = circle_avatar(avatar_path, size)
    draw = ImageDraw.Draw(base)
    b_sz = max(11, int(size * 0.44))
    bx1 = by1 = size - b_sz
    bx2 = by2 = size - 1
    if platform == "tiktok":
        draw.ellipse((bx1 - 1, by1 - 1, bx2, by2), fill=(16, 16, 20, 255), outline=(37, 244, 238, 255), width=1)
        cx, cy = (bx1 + bx2) // 2, (by1 + by2) // 2
        draw.line([(cx, cy - 3), (cx, cy + 2)], fill=(254, 44, 85, 255), width=2)
        draw.line([(cx - 1, cy - 3), (cx - 1, cy + 2)], fill=(255, 255, 255, 255), width=1)
        draw.ellipse((cx - 3, cy + 1, cx, cy + 3), fill=(37, 244, 238, 255))
    else:
        draw.ellipse((bx1 - 1, by1 - 1, bx2, by2), fill=(255, 0, 51, 255), outline=(20, 18, 24, 255), width=1)
        cx, cy = (bx1 + bx2) / 2.0, (by1 + by2) / 2.0
        r = b_sz * 0.24
        draw.polygon([(cx - r * 0.7, cy - r), (cx - r * 0.7, cy + r), (cx + r * 1.1, cy)], fill=(255, 255, 255, 255))
    return base


def get_cached_thumbnail(video_path: Path, size=THUMB_SIZE, force_refresh: bool = False) -> Image.Image:
    """Превью 1-й секунды клипа с дисковым кэшем (thumbs_cache) — видео не открывается повторно при старте."""
    try:
        THUMBS_CACHE_DIR.mkdir(parents=True, exist_ok=True)
        st = video_path.stat()
        key = hashlib.md5(f"{video_path.resolve()}_{st.st_size}_{int(st.st_mtime)}".encode("utf-8")).hexdigest()
        cache_file = THUMBS_CACHE_DIR / f"{key}.jpg"
        if not force_refresh and cache_file.exists():
            return Image.open(cache_file).convert("RGB")

        cap = cv2.VideoCapture(str(video_path))
        if cap.isOpened():
            frames = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 30
            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            cap.set(cv2.CAP_PROP_POS_MSEC, 1000.0 if frames / max(1.0, fps) >= 1.1 else 200.0)
            ret, frame = cap.read()
            if not ret or frame is None:
                cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                ret, frame = cap.read()
            cap.release()
            if ret and frame is not None:
                im = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
                im.thumbnail(size, Image.Resampling.LANCZOS)
                canvas = Image.new("RGB", size, (20, 18, 24))
                canvas.paste(im, ((size[0] - im.width) // 2, (size[1] - im.height) // 2))
                with suppress(Exception):
                    canvas.save(cache_file, "JPEG", quality=85)
                return canvas
    except Exception:
        pass
    return Image.new("RGB", size, (33, 31, 38))


def get_video_duration_sec(fpath: Path) -> float:
    with suppress(Exception):
        cap = cv2.VideoCapture(str(fpath))
        if cap.isOpened():
            fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
            cnt = cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0
            cap.release()
            if cnt > 0 and fps > 0:
                return float(cnt / fps)
    return 30.0


# ---------------------------- КТО ГОВОРИТ (ДИАРИЗАЦИЯ) И ПОЛ ПО ГОЛОСУ ----------------------------
# Персонаж определяется для целой ФРАЗЫ (а не для каждого куска субтитра из 6 слов), поэтому внутри
# одной реплики цвет больше не «прыгает». Голоса группируются статистически (MFCC + критерий BIC):
# две фразы сливаются в одного персонажа, если одна общая модель голоса описывает их лучше, чем две.
# Пол — по «базовой» высоте голоса (устойчивый трекер без октавных ошибок).
VOICE_MIN_FRAMES = 60        # ≥0.6 с речи — фраза годится для построения модели голоса
PITCH_VETO_OCT = 0.55        # голоса, отличающиеся по высоте больше чем на ~46%, не сливаются
MIN_SPEAKER_SPEECH = 1.2     # «персонаж» с речью короче 1.2 с считается ошибкой и сливается с ближайшим
FEMALE_F0_HZ = 165.0         # порог «базовой» высоты голоса (35-й перцентиль): выше — женский голос
BIC_LAMBDA = 2.0             # штраф за «нового персонажа»: больше — осторожнее с разделением голосов


def read_wav_mono(wav_path: Path, start_t: float, end_t: float):
    with wave.open(str(wav_path), "rb") as wf:
        sr, n, ch = wf.getframerate(), wf.getnframes(), wf.getnchannels()
        s = max(0, min(n, int(start_t * sr)))
        wf.setpos(s)
        raw = wf.readframes(max(0, min(n, int(end_t * sr)) - s))
    audio = np.frombuffer(raw, dtype=np.int16).astype(np.float32) / 32768.0
    return (audio.reshape(-1, ch).mean(axis=1) if ch > 1 else audio), sr


@lru_cache(maxsize=4)
def _mel_dct(sr: int, n_fft: int, n_mels: int = 26, n_ceps: int = 13):
    mel = lambda f: 2595.0 * np.log10(1.0 + f / 700.0)
    pts = 700.0 * (10 ** (np.linspace(mel(80.0), mel(min(7600.0, sr / 2 - 1)), n_mels + 2) / 2595.0) - 1.0)
    freqs = np.fft.rfftfreq(n_fft, 1.0 / sr)
    fb = np.zeros((n_mels, len(freqs)), dtype=np.float32)
    for m in range(n_mels):
        lo, c, hi = pts[m], pts[m + 1], pts[m + 2]
        fb[m] = np.clip(np.minimum((freqs - lo) / (c - lo), (hi - freqs) / (hi - c)), 0, None)
    dct = np.cos(np.pi / n_mels * (np.arange(n_mels) + 0.5)[None, :] * np.arange(n_ceps)[:, None]).astype(np.float32)
    return fb, dct


def _frames(x: np.ndarray, win: int, hop: int) -> np.ndarray:
    return np.lib.stride_tricks.sliding_window_view(x, win)[::hop] if len(x) >= win else np.zeros((0, win), np.float32)


def estimate_background(audio: np.ndarray, sr: int):
    """Спектр фона (музыка игры, шум, гул) по паузам между репликами — потом вычитается из речи."""
    if len(audio) < int(0.3 * sr):
        return None
    x = (audio - np.mean(audio)).astype(np.float32)
    hop = int(0.010 * sr)
    pre = np.append(x[0], x[1:] - 0.97 * x[:-1])
    out = {}
    for key, sig, win, nf in (("mel", pre, int(0.025 * sr), 512), ("pitch", x, int(0.040 * sr), None)):
        fr = _frames(sig, win, hop)
        if key == "mel":
            fr = fr * np.hamming(win).astype(np.float32)
        else:
            fr = fr - fr.mean(axis=1, keepdims=True)
            nf = 1 << int(np.ceil(np.log2(2 * win)))
        out[key] = np.mean(np.abs(np.fft.rfft(fr, nf)) ** 2, axis=0)
    return out


def _denoise(power: np.ndarray, noise) -> np.ndarray:
    return power if noise is None else np.maximum(power - 1.5 * noise, 0.05 * power)


def _drop_flat_pitch(f0: np.ndarray, frame_idx: np.ndarray) -> np.ndarray:
    """Убирает «слишком ровные» участки тона (ноты музыки/синтезатора): живой голос всё время плавает."""
    if len(f0) < 12:
        return f0
    keep = np.ones(len(f0), dtype=bool)
    run = 0
    for i in range(1, len(f0) + 1):
        steady = i < len(f0) and frame_idx[i] == frame_idx[i - 1] + 1 and abs(np.log2(f0[i] / f0[i - 1])) < 0.004
        if steady:
            run += 1
            continue
        if run >= 9:  # ≥ 0.1 с почти идеально постоянного тона
            keep[i - run - 1:i] = False
        run = 0
    return f0[keep]


def analyze_voice(audio: np.ndarray, sr: int, background=None) -> dict:
    """MFCC речевых кадров и высота голоса (Гц) по кадрам; фон (если известен) вычитается из спектра."""
    res = {"mfcc": np.zeros((0, 12), np.float32), "f0": np.zeros(0, np.float32), "speech_sec": 0.0}
    if len(audio) < int(0.3 * sr):
        return res
    x = (audio - np.mean(audio)).astype(np.float32)
    hop, win, n_fft = int(0.010 * sr), int(0.025 * sr), 512
    pre = np.append(x[0], x[1:] - 0.97 * x[:-1])
    fr = _frames(pre, win, hop) * np.hamming(win).astype(np.float32)
    e_db = 10 * np.log10(np.mean(fr ** 2, axis=1) + 1e-10)
    speech = e_db > max(float(np.max(e_db)) - 30.0, -60.0)
    fb, dct = _mel_dct(sr, n_fft)
    spec = _denoise(np.abs(np.fft.rfft(fr[speech], n_fft)) ** 2, background and background.get("mel"))
    res["mfcc"] = (np.log(spec @ fb.T + 1e-10) @ dct.T)[:, 1:13].astype(np.float32)
    res["speech_sec"] = float(speech.sum()) * hop / sr

    # Высота голоса: нормированная автокорреляция; из близких к максимуму пиков берётся ПЕРВЫЙ
    # (самый высокий тон) — это убирает типичную ошибку «женский голос услышан на октаву ниже».
    pw = int(0.040 * sr)
    p = _frames(x, pw, hop)
    p = p - p.mean(axis=1, keepdims=True)
    p_db = 10 * np.log10(np.mean(p ** 2, axis=1) + 1e-10)
    loud_idx = np.nonzero(p_db > max(float(np.max(p_db)) - 25.0, -55.0))[0] if len(p) else np.zeros(0, int)
    p = p[loud_idx]
    if len(p):
        nf = 1 << int(np.ceil(np.log2(2 * pw)))
        power = _denoise(np.abs(np.fft.rfft(p, nf)) ** 2, background and background.get("pitch"))
        r = np.fft.irfft(power, nf)[:, :pw]
        cs = np.cumsum(p ** 2, axis=1)
        lags = np.arange(int(sr / 420.0), int(sr / 65.0) + 1)
        ncc = r[:, lags] / np.sqrt(cs[:, pw - 1 - lags] * (cs[:, -1:] - cs[:, lags - 1]) + 1e-12)
        best = ncc.max(axis=1)
        peak = np.zeros_like(ncc, dtype=bool)
        peak[:, 1:-1] = (ncc[:, 1:-1] >= ncc[:, :-2]) & (ncc[:, 1:-1] >= ncc[:, 2:])
        cand = peak & (ncc >= 0.86 * best[:, None])
        ok = cand.any(axis=1) & (best > 0.55 if background else best > 0.62)
        f0 = _drop_flat_pitch(sr / lags[np.argmax(cand, axis=1)][ok].astype(np.float32), loud_idx[ok])
        if len(f0) >= 5:  # отбрасываем одиночные выбросы (полуоктавные скачки)
            f0 = f0[np.abs(np.log2(f0 / np.median(f0))) < 0.6]
        res["f0"] = f0
    return res


def voice_gender(f0_all: np.ndarray):
    """True — женский, False — мужской, None — мало данных. Берётся 35-й перцентиль высоты голоса:
    в эмоциональной речи (крик, смех) верхние значения у мужчин сильно растут, а «база» почти нет."""
    if len(f0_all) < 25:
        return None
    return bool(np.percentile(f0_all, 35) >= FEMALE_F0_HZ)


class _VoiceCluster:
    def __init__(self, mfcc, f0, speech_sec, phrases):
        self.n, self.s, self.ss = len(mfcc), mfcc.sum(0, dtype=np.float64), mfcc.T.astype(np.float64) @ mfcc
        self.f0, self.speech_sec, self.phrases = f0, speech_sec, phrases

    def merged(self, o):
        c = _VoiceCluster.__new__(_VoiceCluster)
        c.n, c.s, c.ss = self.n + o.n, self.s + o.s, self.ss + o.ss
        c.f0, c.speech_sec, c.phrases = np.concatenate([self.f0, o.f0]), self.speech_sec + o.speech_sec, self.phrases + o.phrases
        return c

    def gauss(self):
        mu = self.s / self.n
        cov = self.ss / self.n - np.outer(mu, mu)
        cov += np.eye(len(mu)) * (1e-3 + 0.01 * np.trace(cov) / len(mu))
        return mu, cov

    def logdet(self):
        return np.linalg.slogdet(self.gauss()[1])[1]

    def pitch(self):
        return float(np.median(self.f0)) if len(self.f0) >= 20 else None


def _merge_cost(a: _VoiceCluster, b: _VoiceCluster) -> float:
    d = len(a.s)
    m = a.merged(b)
    cost = 0.5 * (m.n * m.logdet() - a.n * a.logdet() - b.n * b.logdet()) - BIC_LAMBDA * 0.5 * (d + d * (d + 1) / 2) * np.log(m.n)
    pa, pb = a.pitch(), b.pitch()
    if pa and pb and abs(np.log2(pa / pb)) > PITCH_VETO_OCT:
        cost += 1e6
    return cost


def _avg_loglik(mfcc: np.ndarray, cl: _VoiceCluster) -> float:
    mu, cov = cl.gauss()
    diff = mfcc - mu
    return float(-0.5 * (np.mean(np.sum(diff @ np.linalg.inv(cov) * diff, axis=1)) + np.linalg.slogdet(cov)[1]))


def cluster_voices(feats: list, max_speakers: int) -> list:
    """feats — признаки фраз по времени. Возвращает номер персонажа для каждой фразы (0 — кто заговорил первым)."""
    n = len(feats)
    if n == 0:
        return []
    strong = [i for i, f in enumerate(feats) if len(f["mfcc"]) >= VOICE_MIN_FRAMES]
    if max_speakers <= 1 or not strong:
        return [0] * n
    cls = [_VoiceCluster(feats[i]["mfcc"], feats[i]["f0"], feats[i]["speech_sec"], [i]) for i in strong]

    def _merge_best(force=False, only=None):
        best = None
        for i in range(len(cls)):
            for j in range(i + 1, len(cls)):
                if only is not None and only not in (i, j):
                    continue
                c = _merge_cost(cls[i], cls[j])
                if best is None or c < best[0]:
                    best = (c, i, j)
        if best is None or (not force and best[0] >= 0):
            return False
        _, i, j = best
        cls[i] = cls[i].merged(cls[j])
        del cls[j]
        return True

    while len(cls) > 1 and _merge_best(force=len(cls) > max_speakers):
        pass
    while len(cls) > 1:  # слишком «короткие» персонажи — почти всегда ошибка
        tiny = min(range(len(cls)), key=lambda k: cls[k].speech_sec)
        if cls[tiny].speech_sec >= MIN_SPEAKER_SPEECH:
            break
        _merge_best(force=True, only=tiny)

    labels = [-1] * n
    for k, c in enumerate(cls):
        for i in c.phrases:
            labels[i] = k
    for i, f in enumerate(feats):  # короткие фразы — к самому похожему голосу
        if labels[i] == -1 and len(f["mfcc"]) >= 10:
            scores = []
            for c in cls:
                s = _avg_loglik(f["mfcc"], c)
                pc, pf = c.pitch(), (float(np.median(f["f0"])) if len(f["f0"]) >= 8 else None)
                if pc and pf and abs(np.log2(pc / pf)) > PITCH_VETO_OCT:
                    s -= 50.0
                scores.append(s)
            labels[i] = int(np.argmax(scores))
    for i in range(n):  # совсем без речи — как соседняя фраза
        if labels[i] == -1:
            labels[i] = next((labels[j] for j in list(range(i - 1, -1, -1)) + list(range(i + 1, n)) if labels[j] != -1), 0)
    for i in range(1, n - 1):  # короткая вставка между репликами одного голоса — тот же голос
        if feats[i]["speech_sec"] < 0.8 and labels[i - 1] == labels[i + 1] != labels[i]:
            labels[i] = labels[i - 1]
    order = {}
    return [order.setdefault(l, len(order)) for l in labels]


def diarize_segments(sub_segments: list, wav_path: Path, max_speakers: int, detect_gender: bool) -> tuple:
    """Назначает speaker_id всем кускам субтитров (одинаковый внутри фразы). Возвращает (subs, кол-во, {id: женский?})."""
    subs = [dict(s) for s in (sub_segments or [])]
    if not subs:
        return subs, 1, {0: False}
    groups = {}
    for i, s in enumerate(subs):
        groups.setdefault(s.get("phrase", f"_{i}"), []).append(i)
    phrases = sorted(groups.values(), key=lambda idx: subs[idx[0]]["start"])
    have_wav = bool(wav_path) and Path(wav_path).exists()
    background = None
    if have_wav:  # фон — из пауз между фразами (и до/после них) в пределах клипа
        with suppress(Exception):
            spans = sorted((min(subs[i]["start"] for i in idx), max(subs[i]["end"] for i in idx)) for idx in phrases)
            t0, gaps = spans[0][0] - 1.5, []
            for s, e in spans + [(spans[-1][1] + 1.5, None)]:
                if s - t0 > 0.15:
                    gaps.append(read_wav_mono(Path(wav_path), max(0.0, t0 + 0.05), s - 0.05))
                t0 = max(t0, e) if e is not None else t0
            if gaps and sum(len(g[0]) for g in gaps) >= 0.4 * gaps[0][1]:
                background = estimate_background(np.concatenate([g[0] for g in gaps]), gaps[0][1])
    feats = []
    for idx in phrases:
        f = {"mfcc": np.zeros((0, 12), np.float32), "f0": np.zeros(0, np.float32), "speech_sec": 0.0}
        if have_wav:
            with suppress(Exception):
                audio, sr = read_wav_mono(Path(wav_path), min(subs[i]["start"] for i in idx) - 0.05,
                                          max(subs[i]["end"] for i in idx) + 0.05)
                f = analyze_voice(audio, sr, background)
        feats.append(f)

    labels = cluster_voices(feats, max(1, min(6, int(max_speakers))))
    for idx, lab in zip(phrases, labels):
        for i in idx:
            subs[i]["speaker_id"] = lab
    count = max(labels) + 1 if labels else 1
    genders = {}
    for sp in range(count):
        g = None
        if detect_gender:
            mine = [f for f, l in zip(feats, labels) if l == sp]
            g = voice_gender(np.concatenate([f["f0"] for f in mine]) if mine else np.zeros(0))
        genders[sp] = bool(g)
    return subs, count, genders


def assign_speaker_colors(speakers_count, speaker_genders, default_mode, enable_female_colors=False) -> dict:
    styles, fem_i, def_i = {}, 0, 0
    for sp in range(speakers_count):
        is_fem = bool(speaker_genders.get(sp, False))
        if is_fem and enable_female_colors:
            col, fem_i = FEMALE_SPEAKER_HEX[fem_i % len(FEMALE_SPEAKER_HEX)], fem_i + 1
        else:
            col, def_i = DEFAULT_SPEAKER_HEX[def_i % len(DEFAULT_SPEAKER_HEX)], def_i + 1
        styles[str(sp)] = {"color": col, "mode": default_mode, "is_female": is_fem}
    return styles


# ---------------------------- БАЛАНС ТОКЕНОВ ----------------------------
class TokifyBalanceChecker:
    HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
        "Accept": "application/json, text/plain, */*",
        "Origin": "https://tokify.sale",
        "Referer": "https://tokify.sale/#dashboard",
    }
    PRIORITY_KEYS = (
        "remaining_tokens", "tokens_remaining", "tokens_left", "left_tokens", "available_tokens", "token_balance",
        "tokens_balance", "balance_tokens", "remaining", "quota_remaining", "remain_quota", "tokens", "balance", "quota",
    )

    @classmethod
    def _extract_tokens_from_json(cls, data) -> str:
        if not isinstance(data, dict):
            return ""
        candidates = [data] + [data[k] for k in ("data", "key", "quota", "usage", "balance", "account", "info", "result", "user")
                               if isinstance(data.get(k), dict)]
        for obj in candidates:
            total = obj.get("total_tokens") or obj.get("max_tokens") or obj.get("quota_limit") or obj.get("limit")
            used = obj.get("used_tokens") or obj.get("tokens_used") or obj.get("used_quota") or obj.get("used")
            if isinstance(total, (int, float)) and isinstance(used, (int, float)) and total >= used:
                return format_token_number(total - used)
            for pk in cls.PRIORITY_KEYS:
                val = obj.get(pk)
                if val is None or isinstance(val, (dict, list)):
                    continue
                if isinstance(val, (int, float)) or (isinstance(val, str) and any(ch.isdigit() for ch in val)):
                    return format_token_number(val)
        return ""

    @classmethod
    def _check_via_headless_dashboard(cls, key: str) -> str:
        try:
            from playwright.sync_api import sync_playwright
            exe_path = find_system_browser_exe()
            if not exe_path:
                return ""
            captured = []
            with sync_playwright() as p:
                browser = p.chromium.launch(executable_path=exe_path, headless=True,
                                            args=["--disable-blink-features=AutomationControlled"])
                page = browser.new_page()

                def _on_response(resp):
                    with suppress(Exception):
                        if "application/json" in resp.headers.get("content-type", "").lower():
                            t = cls._extract_tokens_from_json(resp.json())
                            if t:
                                captured.append(t)

                page.on("response", _on_response)
                page.goto("https://tokify.sale/#dashboard", wait_until="domcontentloaded", timeout=15000)
                page.wait_for_timeout(1200)
                inp = page.locator("input[type='password'], input[placeholder*='sk-'], input[placeholder*='ключ'], "
                                   "input[placeholder*='key'], #dashboard input").first
                if inp.count() > 0:
                    inp.fill(key)
                    page.wait_for_timeout(300)
                    btn = page.locator("button:has-text('Проверить ключ'), button:has-text('Проверить'), #dashboard button").first
                    btn.click() if btn.count() > 0 else inp.press("Enter")
                    page.wait_for_timeout(2500)
                body_text = "" if captured else page.locator("body").inner_text()
                browser.close()
            if captured:
                return captured[-1]
            for pat in (r"(?:остаток|осталось|доступно|баланс|remaining)[^\d\n]{0,25}([\d][\d\s.,]*\s*(?:млн|млрд|тыс|k|m|b)?)",
                        r"([\d][\d\s.,]+\s*(?:млн|млрд|тыс)?)\s*(?:токен|tokens)"):
                for m in re.finditer(pat, body_text, re.IGNORECASE):
                    cand = m.group(1).strip()
                    if "372" not in cand and "383" not in cand and cand:
                        return cand
        except Exception:
            pass
        return ""

    @classmethod
    def fetch_remaining_tokens(cls, api_key: str, base_url: str, allow_browser: bool = True) -> str:
        import requests  # ленивый импорт — не замедляет старт окна
        key = clean_api_key(api_key)
        if not key:
            return "ключ не указан"

        if "openrouter.ai" in base_url:
            with suppress(Exception):
                r = requests.get("https://openrouter.ai/api/v1/auth/key", headers={"Authorization": f"Bearer {key}"}, timeout=8)
                if r.status_code == 200:
                    d = r.json().get("data", {})
                    usage = float(d.get("usage", 0))
                    if d.get("limit") is not None:
                        return f"${max(0.0, float(d['limit']) - usage):.3f}"
                    return f"Исп.: ${usage:.3f}"

        m = re.match(r"^(https?://[^/]+)", base_url.strip())
        base_host = m.group(1) if m else "https://tokify.sale"
        headers = {**cls.HEADERS, "Authorization": f"Bearer {key}", "X-API-Key": key}
        for path in ("/api/key", "/v1/key", "/api/quota", "/api/balance", "/v1/usage"):
            with suppress(Exception):
                resp = requests.get(f"{base_host.rstrip('/')}{path}", headers=headers, timeout=4)
                if resp.status_code == 200 and "application/json" in resp.headers.get("Content-Type", ""):
                    tok = cls._extract_tokens_from_json(resp.json())
                    if tok:
                        return tok
        if allow_browser:
            tok = cls._check_via_headless_dashboard(key)
            if tok:
                return tok
        return "активен"


# ---------------------------- СУБТИТРЫ ----------------------------
@lru_cache(maxsize=32)
def load_pil_font(font_name: str, font_size: int):
    win_fonts = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
    for fname in FONT_MAP.get(font_name, []) + ["arialbd.ttf", "arial.ttf", "segoeui.ttf"]:
        with suppress(Exception):
            if (win_fonts / fname).exists():
                return ImageFont.truetype(str(win_fonts / fname), font_size)
    return ImageFont.load_default()


class SubtitleRenderer:
    """
    Рендерер субтитров v3.3: текст фразы (или фразы с подсвеченным словом) рисуется в PIL ОДИН раз
    и кэшируется как прозрачный оверлей. На каждом кадре он лишь смешивается с кадром в пределах
    области текста — вместо полной отрисовки PIL на каждом кадре.
    """

    def __init__(self, font_name="Arial", font_size=70, bg_box=False, word_by_word=False,
                 enable_female_colors=False, speaker_styles=None):
        self.font_name, self.font_size = font_name, font_size
        self.bg_box, self.word_by_word = bg_box, word_by_word
        self.enable_female_colors = enable_female_colors
        self.speaker_styles = speaker_styles or {}
        self._cache = {}

    @property
    def default_mode(self) -> str:
        return "word" if self.word_by_word else ("bg" if self.bg_box else "text")

    def _style(self, sp_id: int):
        st = self.speaker_styles.get(sp_id) or self.speaker_styles.get(str(sp_id))
        if st:
            c = st.get("color", speaker_hex(sp_id))
            color, mode = (hex_to_rgb(c) if isinstance(c, str) else tuple(c)), st.get("mode", self.default_mode)
        else:
            color, mode = hex_to_rgb(speaker_hex(sp_id)), self.default_mode
        return color, ("word" if self.word_by_word else mode)

    @staticmethod
    def _active_word(seg: dict, tokens: list, t: float) -> int:
        words = seg.get("words") or []
        if words and len(words) == len(tokens):
            for i, w in enumerate(words):
                if float(w["start"]) <= t <= float(w["end"]):
                    return i
            return max([-1] + [i for i, w in enumerate(words) if t >= float(w["start"])])
        s = float(seg.get("start", 0.0))
        e = max(s + 0.1, float(seg.get("end", s + 1.0)))
        return int(max(0.0, min(0.999, (t - s) / (e - s))) * len(tokens))

    def _build_overlay(self, text, w, h, color, mode, active_idx):
        scale = h / 1920.0 if h > w else h / 1080.0
        fs = max(18, int(round(self.font_size * scale)))
        font = load_pil_font(self.font_name, fs)
        roi_y1, roi_y2 = int(h * 0.58), int(h * 0.96)
        roi_h = roi_y2 - roi_y1
        img = Image.new("RGBA", (w, roi_h), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        max_chars = max(12, int((w * 0.88) / max(1, fs * 0.56)))
        spacing = int(fs * 0.20)
        stroke = dict(stroke_width=max(2, int(fs * 0.09)), stroke_fill=(0, 0, 0))
        bbox_wh = lambda s: (lambda b: (b[2] - b[0], b[3] - b[1]))(draw.textbbox((0, 0), s, font=font))

        if mode == "word":
            lines, cur, cur_len = [], [], 0
            for i, tok in enumerate(text.split()):
                if cur and cur_len + 1 + len(tok) > max_chars:
                    lines.append(cur)
                    cur, cur_len = [(i, tok)], len(tok)
                else:
                    cur.append((i, tok))
                    cur_len += (1 if cur_len > 0 else 0) + len(tok)
            if cur:
                lines.append(cur)
            space_w = draw.textbbox((0, 0), " ", font=font)[2]
            metrics = []
            for ln in lines[:3]:
                sizes = [bbox_wh(t) for _, t in ln]
                metrics.append((ln, [s[0] for s in sizes], sum(s[0] for s in sizes) + space_w * max(0, len(ln) - 1),
                                max(s[1] for s in sizes)))
            total_h = sum(m[3] for m in metrics) + spacing * max(0, len(metrics) - 1)
            y = max(10, int(h * 0.85) - roi_y1 - total_h)
            for ln, widths, tot_w, max_h in metrics:
                x = int((w - tot_w) * 0.5)
                for (ti, tok), ww in zip(ln, widths):
                    draw.text((x, y), tok, font=font, fill=color if ti == active_idx else (255, 255, 255), **stroke)
                    x += ww + space_w
                y += max_h + spacing
        else:
            lines = [(ln, *bbox_wh(ln)) for ln in textwrap.wrap(text, width=max_chars)[:3]]
            total_h = sum(l[2] for l in lines) + spacing * max(0, len(lines) - 1)
            max_w = max([l[1] for l in lines] or [0])
            y = max(12, int(h * 0.85) - roi_y1 - total_h)
            if mode == "bg":
                px, py, rad = int(fs * 0.42), int(fs * 0.25), max(8, int(fs * 0.28))
                bx1, by1 = max(8, int((w - max_w) * 0.5) - px), max(4, y - py)
                bx2, by2 = min(w - 8, int((w + max_w) * 0.5) + px), min(roi_h - 4, y + total_h + py)
                draw.rounded_rectangle([bx1 - 2, by1 - 2, bx2 + 2, by2 + 2], radius=rad, fill=(15, 15, 15))
                draw.rounded_rectangle([bx1, by1, bx2, by2], radius=rad, fill=color)
            for ln, lw, lh in lines:
                lx = int((w - lw) * 0.5)
                if mode == "bg":
                    draw.text((lx + 2, y + 2), ln, font=font, fill=(20, 20, 20))
                    draw.text((lx, y), ln, font=font, fill=(255, 255, 255))
                else:
                    draw.text((lx, y), ln, font=font, fill=color, **stroke)
                y += lh + spacing

        arr = np.asarray(img)
        ys, xs = np.nonzero(arr[:, :, 3])
        if len(ys) == 0:
            return None
        y1, y2, x1, x2 = ys.min(), ys.max() + 1, xs.min(), xs.max() + 1
        crop = arr[y1:y2, x1:x2].astype(np.float32)
        alpha = crop[:, :, 3:4] / 255.0
        premul = crop[:, :, 2::-1] * alpha + 0.5  # RGB -> BGR, +0.5 для округления
        return roi_y1 + y1, roi_y1 + y2, x1, x2, premul, 1.0 - alpha

    def draw_subtitle(self, frame_bgr: np.ndarray, seg: dict, speaker_id: int, abs_time: float) -> np.ndarray:
        text = seg.get("text", "").strip()
        if not text:
            return frame_bgr
        h, w = frame_bgr.shape[:2]
        color, mode = self._style(int(speaker_id))
        active = self._active_word(seg, text.split(), abs_time) if mode == "word" else -1
        key = (seg.get("start"), seg.get("end"), text, w, h, color, mode, active)
        if key not in self._cache:
            if len(self._cache) >= 8:
                self._cache.clear()
            self._cache[key] = self._build_overlay(text, w, h, color, mode, active)
        ov = self._cache[key]
        if ov is not None:
            y1, y2, x1, x2, premul, inv_a = ov
            roi = frame_bgr[y1:y2, x1:x2]
            roi[:] = (roi * inv_a + premul).astype(np.uint8)
        return frame_bgr


# ---------------------------- ТРЕКЕР ГОВОРЯЩЕГО + РЕНДЕР ----------------------------
def build_ffmpeg_render_cmd(out_w, out_h, fps, start_t, duration, video_path, num_tracks, boost_audio, out_path):
    a_norm = "dynaudnorm=f=150:g=15,loudnorm=I=-14:TP=-1.5:LRA=11,volume=1.5" if boost_audio else "volume=1.0"
    cmd = ["ffmpeg", "-y", "-f", "rawvideo", "-vcodec", "rawvideo", "-s", f"{out_w}x{out_h}", "-pix_fmt", "bgr24",
           "-r", f"{fps:.3f}", "-i", "-", "-ss", str(start_t), "-t", str(duration), "-i", str(video_path)]
    if num_tracks > 1:
        a_in = "".join(f"[1:a:{i}]" for i in range(num_tracks))
        cmd += ["-filter_complex", f"{a_in}amix=inputs={num_tracks}:duration=longest:dropout_transition=0,{a_norm}[aout]",
                "-map", "0:v:0", "-map", "[aout]"]
    else:
        cmd += ["-af", a_norm, "-map", "0:v:0", "-map", "1:a:0?"]
    return cmd + ["-c:v", "libx264", "-preset", "fast", "-crf", "22", "-c:a", "aac", "-ac", "2", "-ar", "48000",
                  "-b:a", "192k", "-shortest", str(out_path)]


class ActiveSpeakerTracker:
    """Ленивая загрузка каскадов OpenCV — детекторы инициализируются только при первом рендере."""
    CASCADES = {"frontal": "haarcascade_frontalface_default.xml", "profile": "haarcascade_profileface.xml",
                "upperbody": "haarcascade_upperbody.xml", "fullbody": "haarcascade_fullbody.xml"}

    def __init__(self):
        self._initialized = False
        self.det = {}
        self.hog = None

    def _ensure_initialized(self):
        if self._initialized:
            return
        self._initialized = True
        with suppress(Exception):
            haar = getattr(getattr(cv2, "data", None), "haarcascades", "")
            if not haar or not os.path.exists(haar):
                haar = os.path.join(os.path.dirname(cv2.__file__), "data")
            for name, fname in self.CASCADES.items():
                if os.path.exists(os.path.join(haar, fname)):
                    self.det[name] = cv2.CascadeClassifier(os.path.join(haar, fname))
            self.hog = cv2.HOGDescriptor()
            self.hog.setSVMDetector(cv2.HOGDescriptor_getDefaultPeopleDetector())

    @staticmethod
    def _upscale(rects, scale, flip_w=None):
        return [(int((flip_w - x - w if flip_w else x) / scale), int(y / scale), int(w / scale), int(h / scale))
                for (x, y, w, h) in rects]

    @staticmethod
    def _dedupe(boxes, check_y: bool):
        uniq = []
        for b in sorted(boxes, key=lambda b: b[2] * b[3], reverse=True):
            cx, cy = b[0] + b[2] * 0.5, b[1] + b[3] * 0.5
            if not any(abs(cx - (u[0] + u[2] * 0.5)) < u[2] * 0.65 and
                       (not check_y or abs(cy - (u[1] + u[3] * 0.5)) < u[3] * 0.65) for u in uniq):
                uniq.append(b)
        return sorted(uniq, key=lambda b: b[0])

    def _detect_faces(self, g, scale):
        self._ensure_initialized()
        frontal, profile = self.det.get("frontal"), self.det.get("profile")
        if frontal is None:
            return []
        kw = dict(scaleFactor=1.12, minNeighbors=4, minSize=(24, 24))
        try:
            faces = self._upscale(frontal.detectMultiScale(g, **kw), scale)
            if profile is not None:
                faces += self._upscale(profile.detectMultiScale(g, **kw), scale)
                faces += self._upscale(profile.detectMultiScale(cv2.flip(g, 1), **kw), scale, flip_w=g.shape[1])
        except Exception:
            return []
        return self._dedupe(faces, True)

    def _detect_silhouettes(self, g, scale):
        self._ensure_initialized()
        found = []
        with suppress(Exception):
            for name, min_size in (("upperbody", (36, 36)), ("fullbody", (36, 60))):
                det = self.det.get(name)
                if not found and det is not None:
                    found = self._upscale(det.detectMultiScale(g, scaleFactor=1.12, minNeighbors=3, minSize=min_size), scale)
            if not found and self.hog is not None:
                found = self._upscale(self.hog.detectMultiScale(g, winStride=(8, 8), padding=(16, 16), scale=1.08)[0], scale)
        return self._dedupe(found, False)

    @staticmethod
    def _mouth_activity(prev_gray, curr_gray, box) -> float:
        x, y, w, h = box
        H, W = curr_gray.shape[:2]
        mx1, mx2 = max(0, int(x + w * 0.20)), min(W, int(x + w * 0.80))
        my1, my2 = max(0, int(y + h * 0.60)), min(H, int(y + h * 0.96))
        if mx2 - mx1 < 6 or my2 - my1 < 6:
            return 0.0
        return float(np.mean(cv2.absdiff(curr_gray[my1:my2, mx1:mx2], prev_gray[my1:my2, mx1:mx2])))

    @staticmethod
    def _is_partially_in_frame(px, pw, cam_x, crop_w) -> bool:
        if abs(px - cam_x) <= crop_w * 0.44:
            return True
        overlap = min(cam_x + crop_w * 0.5, px + pw * 0.45) - max(cam_x - crop_w * 0.5, px - pw * 0.45)
        return pw > 0 and overlap >= pw * 0.25

    def _analyze_pass(self, cap, fps, total_frames, orig_w, orig_h, crop_w, mirror, cancelled):
        """Проход 1: быстрый последовательный проход (cap.grab без тяжёлых seek), ~5 замеров в секунду."""
        scale = min(1.0, 480.0 / max(1, orig_w))
        step = max(3, int(fps // 5))
        prev_small, last_people = None, []
        counts, targets, mouth_ema = [], {}, {}
        active_slot = slot_hold = 0

        for f_idx in range(total_frames):
            if cancelled():
                raise Cancelled()
            if f_idx % step:
                if not cap.grab():
                    break
                continue
            ret, frm = cap.retrieve() if f_idx > 0 else cap.read()
            if not ret or frm is None:
                ret, frm = cap.read()
                if not ret or frm is None:
                    break
            if mirror:
                frm = cv2.flip(frm, 1)
            gray = cv2.cvtColor(frm, cv2.COLOR_BGR2GRAY)
            small = cv2.resize(gray, (0, 0), fx=scale, fy=scale)

            is_cut = prev_small is not None and float(np.mean(cv2.absdiff(small, prev_small))) > 33.0
            if is_cut:
                last_people, slot_hold = [], 0
                mouth_ema.clear()

            faces = self._detect_faces(small, scale)
            people = faces or self._detect_silhouettes(small, scale)
            if people:
                last_people = people
                counts.append(len(people))
            elif last_people and not is_cut:
                people = last_people

            if people:
                if len(people) == 1:
                    active_slot = 0
                else:
                    best_sl = active_slot if 0 <= active_slot < len(people) else 0
                    best_sc = -1.0
                    if prev_small is not None:
                        prev_full = cv2.resize(prev_small, (orig_w, orig_h))
                        for sl, bx in enumerate(people):
                            sc = mouth_ema.get(sl, 0.0) * 0.65 + self._mouth_activity(prev_full, gray, bx) * 0.35
                            mouth_ema[sl] = sc
                            if sc > best_sc:
                                best_sl, best_sc = sl, sc
                    if slot_hold <= 0:
                        if best_sl != active_slot and best_sc > 1.9:
                            active_slot, slot_hold = best_sl, 3
                    else:
                        slot_hold -= 1
                    active_slot = max(0, min(len(people) - 1, active_slot))
                box = people[active_slot]
                targets[f_idx] = (box[0] + box[2] * 0.5, float(box[2]), is_cut, active_slot)
            else:
                targets[f_idx] = (orig_w * 0.5, crop_w * 0.4, is_cut, 0)
            prev_small = small

        if counts:
            max_people = int(np.percentile(counts, 90))
            if max(counts) >= 2 and max_people < 2 and sum(c >= 2 for c in counts) >= 2:
                max_people = 2
            max_people = max(1, min(4, max_people))
        else:
            max_people = 1
        return targets, max_people

    def render_clip(self, video_path: Path, start_t: float, duration: float, out_file: Path, num_tracks: int,
                    boost_audio: bool, vertical: bool, use_tracker: bool, mirror_video: bool, enable_female_colors: bool,
                    sub_segments: list, sub_renderer: SubtitleRenderer = None, voice_wav: Path = None,
                    cancel_check=None, register_proc=None, keep_speakers: bool = False):
        """keep_speakers=True — персонажи берутся из субтитров как есть (ручные правки из редактора не затираются)."""
        self._ensure_initialized()
        cancelled = lambda: bool(cancel_check and cancel_check())
        cap = cv2.VideoCapture(str(video_path))
        if not cap.isOpened():
            raise RuntimeError(f"Не удалось открыть видео: {video_path}")

        fps = cap.get(cv2.CAP_PROP_FPS) or 30.0
        orig_w = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH) or 1920)
        orig_h = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT) or 1080)
        if vertical:
            out_w, out_h = 1080, 1920
            crop_w = int(orig_h * 9 / 16)
            crop_w = min(orig_w, max(64, crop_w - crop_w % 2))
        else:
            out_w, out_h = orig_w - orig_w % 2, orig_h - orig_h % 2
            crop_w = out_w
        total_frames = int(duration * fps)

        try:
            cap.set(cv2.CAP_PROP_POS_MSEC, start_t * 1000.0)
            targets, max_people = self._analyze_pass(cap, fps, total_frames, orig_w, orig_h, crop_w, mirror_video, cancelled)
        except BaseException:
            cap.release()
            raise

        if keep_speakers:
            subs = [dict(s) for s in (sub_segments or [])]
            sp_count = max([1] + [int(s.get("speaker_id", 0)) + 1 for s in subs])
            genders = {}
        else:
            subs, sp_count, genders = diarize_segments(sub_segments, voice_wav, max_people, enable_female_colors)
        if sub_renderer is not None and not sub_renderer.speaker_styles:
            sub_renderer.speaker_styles = assign_speaker_colors(sp_count, genders, sub_renderer.default_mode, enable_female_colors)

        # --- ПРОХОД 2: ФИНАЛЬНЫЙ РЕНДЕР С ЧИСТЫМ МОНТАЖНЫМ CUT ---
        cap.set(cv2.CAP_PROP_POS_MSEC, start_t * 1000.0)
        temp_out = out_file.with_name(f".tmp_{int(time.time() * 1000)}_{out_file.name}")
        proc = subprocess.Popen(build_ffmpeg_render_cmd(out_w, out_h, fps, start_t, duration, video_path, num_tracks,
                                                        boost_audio, temp_out),
                                stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                creationflags=NO_WINDOW_FLAG)
        if register_proc:
            register_proc(proc)

        first = targets.get(0, (orig_w * 0.5, crop_w * 0.4, False, 0))
        cam_x = max(crop_w * 0.5, min(orig_w - crop_w * 0.5, first[0]))
        cur_slot, prev_tx, stationary = first[3], first[0], 0
        finished = False
        try:
            for fi in range(total_frames):
                if cancelled():
                    break
                ret, frame = cap.read()
                if not ret or frame is None:
                    break
                if mirror_video:
                    frame = cv2.flip(frame, 1)
                abs_time = start_t + fi / fps

                if use_tracker and vertical and fi in targets:
                    tx, tw, is_cut, t_slot = targets[fi]
                    ctx_x = max(crop_w * 0.5, min(orig_w - crop_w * 0.5, tx))
                    stationary = stationary + 1 if abs(tx - prev_tx) < orig_w * 0.018 else 0
                    prev_tx = tx
                    if is_cut:
                        cam_x, cur_slot, stationary = ctx_x, t_slot, 0
                    elif t_slot != cur_slot:
                        if not self._is_partially_in_frame(ctx_x, tw, cam_x, crop_w):
                            cam_x = ctx_x
                        cur_slot = t_slot
                    elif not self._is_partially_in_frame(ctx_x, tw, cam_x, crop_w) and stationary >= 2:
                        cam_x, stationary = ctx_x, 0

                if vertical:
                    x1 = max(0, min(orig_w - crop_w, int(round(cam_x - crop_w * 0.5))))
                    out_frame = cv2.resize(frame[:, x1:x1 + crop_w], (out_w, out_h), interpolation=cv2.INTER_LINEAR)
                else:
                    out_frame = frame[:out_h, :out_w]

                if sub_renderer is not None and subs:
                    seg = next((s for s in subs if s["start"] <= abs_time <= s["end"]), None)
                    if seg is not None:
                        out_frame = sub_renderer.draw_subtitle(out_frame, seg, int(seg.get("speaker_id", 0)), abs_time)
                try:
                    proc.stdin.write(out_frame.tobytes())
                except OSError:
                    if cancelled():
                        break
                    raise
            finished = not cancelled()
        finally:
            cap.release()
            with suppress(Exception):
                proc.stdin.close()
            proc.wait()  # сначала дожидаемся ffmpeg (иначе Windows не даст удалить файл)
            if not finished:
                with suppress(Exception):
                    temp_out.unlink(missing_ok=True)

        if cancelled():
            raise Cancelled()
        if temp_out.exists():
            shutil.move(str(temp_out), str(out_file))
        return subs, sp_count, genders


# ---------------------------- GOOGLE DRIVE ----------------------------
# Отдельный от YouTube/TikTok вход: свой токен, временный профиль браузера, ничего общего с аккаунтами загрузки.
# Права drive.file — программа видит и меняет ТОЛЬКО файлы и папки, которые создала сама.
GOOGLE_CLIENT_FILE = DATA_ROOT / "google_client.json"   # OAuth-клиент «Desktop app» из Google Cloud Console
GDRIVE_AUTH_FILE = DATA_ROOT / "gdrive_auth.json"
GDRIVE_AVATAR_FILE = DATA_ROOT / "gdrive_avatar.png"
CLOUD_CACHE_DIR = DATA_ROOT / "cloud_cache"             # рабочие копии клипов при облачном хранении
GDRIVE_SCOPES = "openid email profile https://www.googleapis.com/auth/drive.file"
GDRIVE_FOLDER_MIME = "application/vnd.google-apps.folder"


class DriveError(RuntimeError):
    def __init__(self, msg, status=0):
        super().__init__(msg)
        self.status = status


class GoogleDrive:
    API = "https://www.googleapis.com/drive/v3/files"
    UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"
    TOKEN_URL = "https://oauth2.googleapis.com/token"
    CHUNK = 8 * 1024 * 1024  # кратно 256 КиБ, как требует Drive

    def __init__(self):
        auth = read_json(GDRIVE_AUTH_FILE, {})
        self.auth = auth if isinstance(auth, dict) else {}
        self._lock = threading.Lock()
        self._folders = {}

    # --- состояние ---
    @property
    def connected(self) -> bool:
        return bool(self.auth.get("refresh_token"))

    @property
    def user(self) -> dict:
        return self.auth.get("user", {})

    @staticmethod
    def has_client() -> bool:
        return bool(GoogleDrive._client())

    @staticmethod
    def _client() -> dict:
        d = read_json(GOOGLE_CLIENT_FILE, {})
        c = (d.get("installed") or d.get("web") or d) if isinstance(d, dict) else {}
        return c if c.get("client_id") and c.get("client_secret") else {}

    @staticmethod
    def import_client(path: str):
        d = read_json(Path(path), None)
        c = (d.get("installed") or d.get("web") or d) if isinstance(d, dict) else {}
        if not (c.get("client_id") and c.get("client_secret")):
            raise ValueError("В файле нет client_id / client_secret. Нужен JSON OAuth-клиента типа «Desktop app».")
        write_json(GOOGLE_CLIENT_FILE, {"installed": {"client_id": c["client_id"], "client_secret": c["client_secret"]}})

    # --- вход / выход ---
    def login(self, timeout_sec: int = 360) -> dict:
        """Окно браузера со входом Google → локальный redirect с кодом → токены. Блокирующий вызов (в потоке)."""
        import base64, secrets, tempfile, webbrowser
        import requests
        from http.server import BaseHTTPRequestHandler, HTTPServer
        from urllib.parse import urlencode, urlparse, parse_qs
        client = self._client()
        if not client:
            raise DriveError("Не настроен OAuth-клиент Google (файл google_client.json).")
        verifier = secrets.token_urlsafe(64)
        challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode()
        state, result = secrets.token_urlsafe(16), {}

        class _Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                q = {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()}
                if q.get("state") == state:
                    result.update(q)
                body = ("<html><body style='background:#141218;color:#E6E0E9;font-family:Segoe UI;text-align:center;"
                        "padding-top:80px'><h2>Готово! Окно можно закрыть.</h2><script>window.close()</script></body></html>")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.end_headers()
                self.wfile.write(body.encode("utf-8"))

            def log_message(self, *a):
                pass

        server = HTTPServer(("127.0.0.1", 0), _Handler)
        server.timeout = 0.5
        redirect = f"http://127.0.0.1:{server.server_port}/"
        url = "https://accounts.google.com/o/oauth2/v2/auth?" + urlencode({
            "client_id": client["client_id"], "redirect_uri": redirect, "response_type": "code", "scope": GDRIVE_SCOPES,
            "code_challenge": challenge, "code_challenge_method": "S256", "state": state,
            "access_type": "offline", "prompt": "consent select_account"})
        stop = threading.Event()

        def _serve():
            while not stop.is_set() and not result:
                server.handle_request()
        threading.Thread(target=_serve, daemon=True).start()

        deadline = time.time() + timeout_sec
        profile = tempfile.mkdtemp(prefix="gdrive_login_")
        try:
            try:
                from playwright.sync_api import sync_playwright
                with sync_playwright() as p:
                    ctx = launch_browser_context(p, profile, headless=False, width=520, height=680)
                    page = ctx.pages[0] if ctx.pages else ctx.new_page()
                    page.goto(url)
                    while not result and time.time() < deadline and not page.is_closed():
                        page.wait_for_timeout(400)
                    with suppress(Exception):
                        ctx.close()
            except Exception:
                webbrowser.open(url)  # запасной вариант — обычный браузер (вкладку закроет страница «Готово»)
                while not result and time.time() < deadline:
                    time.sleep(0.4)
        finally:
            stop.set()
            with suppress(Exception):
                server.server_close()
            shutil.rmtree(profile, ignore_errors=True)

        if "code" not in result:
            raise DriveError("Вход отменён." if "error" not in result else f"Google отклонил вход: {result['error']}")
        tok = requests.post(self.TOKEN_URL, timeout=20, data={
            "code": result["code"], "client_id": client["client_id"], "client_secret": client["client_secret"],
            "redirect_uri": redirect, "code_verifier": verifier, "grant_type": "authorization_code"}).json()
        if "refresh_token" not in tok:
            raise DriveError(f"Не удалось получить токен: {tok.get('error_description') or tok.get('error') or tok}")
        info = requests.get("https://openidconnect.googleapis.com/v1/userinfo", timeout=15,
                            headers={"Authorization": f"Bearer {tok['access_token']}"}).json()
        avatar = ""
        with suppress(Exception):
            r = requests.get(info["picture"], timeout=10)
            Image.open(BytesIO(r.content)).convert("RGBA").save(GDRIVE_AVATAR_FILE)
            avatar = str(GDRIVE_AVATAR_FILE)
        self.auth = {"refresh_token": tok["refresh_token"], "access_token": tok["access_token"],
                     "expires_at": time.time() + float(tok.get("expires_in", 3600)),
                     "user": {"name": info.get("name") or info.get("email", "Google"), "email": info.get("email", ""),
                              "avatar": avatar}}
        self._folders.clear()
        write_json(GDRIVE_AUTH_FILE, self.auth)
        return self.user

    def logout(self):
        token = self.auth.get("refresh_token")
        self.auth, self._folders = {}, {}
        for f in (GDRIVE_AUTH_FILE, GDRIVE_AVATAR_FILE):
            with suppress(Exception):
                f.unlink(missing_ok=True)
        if token:  # отзыв доступа у Google — в фоне, результат не важен
            def _revoke():
                import requests
                with suppress(Exception):
                    requests.post("https://oauth2.googleapis.com/revoke", data={"token": token}, timeout=10)
            run_bg(_revoke)

    # --- HTTP ---
    def _access_token(self) -> str:
        import requests
        with self._lock:
            if not self.connected:
                raise DriveError("Google Drive не подключён.")
            if time.time() < float(self.auth.get("expires_at", 0)) - 60:
                return self.auth["access_token"]
            c = self._client()
            r = requests.post(self.TOKEN_URL, timeout=20, data={
                "client_id": c.get("client_id"), "client_secret": c.get("client_secret"),
                "refresh_token": self.auth["refresh_token"], "grant_type": "refresh_token"})
            d = r.json()
            if "access_token" not in d:
                raise DriveError(f"Сессия Google Drive истекла — подключите аккаунт заново ({d.get('error', r.status_code)}).", 401)
            self.auth.update(access_token=d["access_token"], expires_at=time.time() + float(d.get("expires_in", 3600)))
            write_json(GDRIVE_AUTH_FILE, self.auth)
            return d["access_token"]

    def _req(self, method: str, url: str, ok=(200, 201, 204), **kw):
        import requests
        for attempt in range(2):
            headers = {**kw.pop("headers", {}), "Authorization": f"Bearer {self._access_token()}"}
            r = requests.request(method, url, headers=headers, timeout=kw.pop("timeout", 30), **kw)
            if r.status_code == 401 and attempt == 0:
                self.auth["expires_at"] = 0
                kw["headers"] = {k: v for k, v in headers.items() if k != "Authorization"}
                continue
            if r.status_code not in ok:
                with suppress(Exception):
                    msg = r.json()["error"]["message"]
                    raise DriveError(f"Google Drive: {msg}", r.status_code)
                raise DriveError(f"Google Drive: ошибка HTTP {r.status_code}", r.status_code)
            return r

    # --- папки и файлы ---
    @staticmethod
    def normalize_folder(path: str) -> str:
        return "/".join(p.strip() for p in str(path or "").replace("\\", "/").split("/") if p.strip()) or "Клипы"

    def ensure_folder(self, path: str) -> str:
        """id папки по пути вида «Клипы/Shorts» (от корня «Мой диск»); недостающие папки создаются."""
        path = self.normalize_folder(path)
        if path in self._folders:
            return self._folders[path]
        parent = "root"
        for part in path.split("/"):
            esc = part.replace("\\", "\\\\").replace("'", "\\'")
            q = f"name = '{esc}' and mimeType = '{GDRIVE_FOLDER_MIME}' and '{parent}' in parents and trashed = false"
            found = self._req("GET", self.API, params={"q": q, "fields": "files(id)", "pageSize": 1}).json().get("files", [])
            parent = found[0]["id"] if found else self._req(
                "POST", self.API, params={"fields": "id"}, json={"name": part, "mimeType": GDRIVE_FOLDER_MIME, "parents": [parent]}).json()["id"]
        self._folders[path] = parent
        return parent

    def upload(self, local: Path, name: str = None, folder: str = "Клипы", file_id: str = None, progress=None, cancelled=None) -> dict:
        """Возобновляемая загрузка по частям. file_id — заменить содержимое существующего файла (перерендер)."""
        import requests
        size = local.stat().st_size
        hdr = {"X-Upload-Content-Type": "video/mp4", "X-Upload-Content-Length": str(size)}
        params = {"uploadType": "resumable", "fields": "id,webViewLink"}
        try:
            if file_id:
                r = self._req("PATCH", f"{self.UPLOAD}/{file_id}", params=params, json={}, headers=hdr)
            else:
                r = self._req("POST", self.UPLOAD, params=params, headers=hdr,
                              json={"name": name or local.name, "parents": [self.ensure_folder(folder)]})
        except DriveError as e:
            if e.status == 404 and not file_id:  # папку удалили вручную — создаём заново
                self._folders.clear()
                r = self._req("POST", self.UPLOAD, params=params, headers=hdr,
                              json={"name": name or local.name, "parents": [self.ensure_folder(folder)]})
            else:
                raise
        session, pos, fails = r.headers["Location"], 0, 0
        with open(local, "rb") as f:
            while True:
                if cancelled and cancelled():
                    raise Cancelled()
                f.seek(pos)
                data = f.read(self.CHUNK)
                try:
                    resp = requests.put(session, data=data, timeout=120,
                                        headers={"Content-Range": f"bytes {pos}-{pos + len(data) - 1}/{size}"})
                except requests.RequestException:
                    fails += 1
                    if fails > 4:
                        raise
                    time.sleep(2 * fails)
                    resp = requests.put(session, headers={"Content-Range": f"bytes */{size}"}, timeout=30)
                if resp.status_code in (200, 201):
                    if progress:
                        progress(1.0)
                    d = resp.json()
                    return {"id": d["id"], "link": d.get("webViewLink", f"https://drive.google.com/file/d/{d['id']}/view")}
                if resp.status_code != 308:
                    raise DriveError(f"Google Drive: загрузка прервана (HTTP {resp.status_code})", resp.status_code)
                rng = resp.headers.get("Range")
                pos = int(rng.rsplit("-", 1)[1]) + 1 if rng else 0
                if progress:
                    progress(pos / max(1, size))

    def rename(self, file_id: str, name: str):
        self._req("PATCH", f"{self.API}/{file_id}", params={"fields": "id"}, json={"name": name})

    def trash(self, file_id: str) -> bool:
        """В корзину Google Drive (восстановима 30 дней). False — файла уже нет."""
        try:
            self._req("PATCH", f"{self.API}/{file_id}", params={"fields": "id"}, json={"trashed": True})
            return True
        except DriveError as e:
            if e.status == 404:
                return False
            raise


def circle_avatar(path: str, size: int) -> Image.Image:
    base = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    mask = Image.new("L", (size, size), 0)
    ImageDraw.Draw(mask).ellipse((0, 0, size - 1, size - 1), fill=255)
    try:
        base.paste(Image.open(path).convert("RGBA").resize((size, size), Image.Resampling.LANCZOS), (0, 0), mask)
    except Exception:
        ImageDraw.Draw(base).ellipse((0, 0, size - 1, size - 1), fill=(74, 68, 88, 255))
    return base


@lru_cache(maxsize=4)
def make_logout_icon(size: int = 20, color=(242, 84, 84, 255)) -> Image.Image:
    """Красная «дверь со стрелкой» (рисуется в 4× и уменьшается — края гладкие)."""
    s = size * 4
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    w = max(2, s // 11)
    d.rounded_rectangle((s * 0.10, s * 0.08, s * 0.56, s * 0.92), radius=s * 0.06, outline=color, width=w)
    d.rectangle((s * 0.50, s * 0.38, s * 0.62, s * 0.62), fill=(0, 0, 0, 0))   # проём для стрелки
    d.line((s * 0.30, s * 0.50, s * 0.80, s * 0.50), fill=color, width=w)
    d.polygon([(s * 0.96, s * 0.50), (s * 0.74, s * 0.33), (s * 0.74, s * 0.67)], fill=color)
    return im.resize((size, size), Image.Resampling.LANCZOS)


# ---------------------------- ОБНОВЛЕНИЯ «ПО ВОЗДУХУ» (GITHUB RELEASES) ----------------------------
# В каждом выпуске на GitHub лежит manifest.json: версия, «отпечаток» библиотек (runtime), список изменений
# и два пакета: patch — только код программы (сотни КБ), full — программа целиком без моделей (нужен, если
# изменились библиотеки). Программа берёт patch, если её runtime совпадает с новым, иначе full.
UPDATE_REPO = "Quiltonn/clips-studio"           # «владелец/репозиторий» — подставляет сборщик
UPDATE_FIRST_CHECK_MS = 10_000
UPDATE_INTERVAL_MS = 15 * 60_000
UPDATES_DIR = DATA_ROOT / "updates"


def parse_version(v) -> tuple:
    return tuple(int(x) for x in re.findall(r"\d+", str(v))[:4]) or (0,)


def fmt_mb(n: float) -> str:
    return f"{n / 1048576:.1f} МБ" if n >= 1048576 else f"{max(1, round(n / 1024))} КБ"


class Updater:
    STATES = ("idle", "downloading", "paused", "ready", "installing", "error")

    def __init__(self, notify):
        self.notify = notify                      # notify() — вызывается (из любого потока) при смене состояния/прогресса
        self.runtime = read_json(INSTALL_DIR / "runtime.json", {}).get("runtime", "") if INSTALL_DIR else ""
        self.manifest = None
        self.state, self.error, self.done, self.total, self.speed = "idle", "", 0, 0, 0.0
        self.checking = False
        self.last_check = None                    # None | "latest" | "available" | "error"
        self._resume, self._cancel = threading.Event(), threading.Event()
        self._thread = None
        self.zip_path = None

    # --- состояние ---
    @property
    def enabled(self) -> bool:
        return bool(INSTALL_DIR and self.runtime and re.fullmatch(r"[\w.-]+/[\w.-]+", UPDATE_REPO))

    @property
    def disabled_reason(self) -> str:
        if not INSTALL_DIR or not self.runtime:
            return "Обновления работают в установленной программе"
        return "Сервер обновлений не настроен в этой сборке"

    @property
    def available(self) -> bool:
        return bool(self.manifest) and parse_version(self.manifest.get("version")) > parse_version(APP_VERSION)

    @property
    def new_version(self) -> str:
        return str((self.manifest or {}).get("version", ""))

    @property
    def package(self) -> dict:
        """Какой пакет скачивать: маленький patch (тот же набор библиотек) или full."""
        m = self.manifest or {}
        kind = "patch" if m.get("runtime") == self.runtime and m.get("patch") else "full"
        return {"kind": kind, **(m.get(kind) or {})}

    def changelog(self) -> list:
        entries = [e for e in (self.manifest or {}).get("changelog", []) if isinstance(e, dict)]
        return sorted(entries, key=lambda e: parse_version(e.get("version")), reverse=True)

    def _emit(self):
        with suppress(Exception):
            self.notify()

    # --- проверка ---
    def check(self) -> bool:
        """Блокирующий запрос manifest.json последнего выпуска. True — есть новая версия."""
        import requests
        if not self.enabled or self.checking:
            return self.available
        self.checking = True
        try:
            r = requests.get(f"https://github.com/{UPDATE_REPO}/releases/latest/download/manifest.json", timeout=15)
            if r.status_code == 404:
                self.manifest = None  # выпусков ещё нет
            else:
                r.raise_for_status()
                m = r.json()
                if self.state in ("idle", "error") or m.get("version") == self.new_version:
                    self.manifest = m
            self.last_check = "available" if self.available else "latest"
        except Exception as e:
            self.last_check, self.error = "error", f"Не удалось проверить обновления: {e}"
        finally:
            self.checking = False
            self._emit()
        return self.available

    # --- скачивание: пауза / продолжить / прервать ---
    def start(self):
        if not self.available or self.state in ("downloading", "paused", "ready", "installing"):
            return
        pkg = self.package
        if not pkg.get("url") or not pkg.get("sha256"):
            self.state, self.error = "error", "В выпуске нет пакета обновления."
            return self._emit()
        UPDATES_DIR.mkdir(parents=True, exist_ok=True)
        self.zip_path = UPDATES_DIR / f"ClipsStudio-{self.new_version}-{pkg['kind']}.zip"
        part = self.zip_path.with_suffix(".part")
        self.total = int(pkg.get("size") or 0)
        self.done = part.stat().st_size if part.exists() else 0  # докачка после перезапуска программы
        self.state, self.error, self.speed = "downloading", "", 0.0
        if self._thread and self._thread.is_alive():  # дождаться остановки прерванной загрузки
            self._thread.join(timeout=5)
        self._cancel, self._resume = threading.Event(), threading.Event()  # свои флаги у каждой загрузки
        self._resume.set()
        self._thread = threading.Thread(target=self._download, args=(pkg, part, self._cancel, self._resume), daemon=True)
        self._thread.start()
        self._emit()

    def pause(self):
        if self.state == "downloading":
            self._resume.clear()
            self.state = "paused"
            self._emit()

    def resume(self):
        if self.state == "paused":
            self.state = "downloading"
            self._resume.set()
            self._emit()

    def abort(self):
        """Прервать без вопросов: загрузка останавливается, частично скачанный файл удаляется."""
        if self.state in ("downloading", "paused", "ready", "error"):
            self._cancel.set()
            self._resume.set()
            if self.state != "downloading" or not (self._thread and self._thread.is_alive()):
                self._cleanup()
            self.state, self.done, self.speed, self.error = "idle", 0, 0.0, ""
            self._emit()

    def _cleanup(self):
        for p in (self.zip_path, self.zip_path.with_suffix(".part") if self.zip_path else None):
            if p:
                with suppress(Exception):
                    p.unlink(missing_ok=True)

    def _download(self, pkg: dict, part: Path, cancel: threading.Event, resume: threading.Event):
        import requests
        fails, last_emit, t0, d0 = 0, 0.0, time.time(), self.done
        while not cancel.is_set():
            resume.wait()
            if cancel.is_set():
                break
            try:
                have = part.stat().st_size if part.exists() else 0
                hdr = {"Range": f"bytes={have}-"} if have else {}
                with requests.get(pkg["url"], headers=hdr, stream=True, timeout=(15, 60)) as r:
                    if r.status_code == 416:  # уже скачано целиком
                        break
                    r.raise_for_status()
                    mode = "ab" if have and r.status_code == 206 else "wb"
                    self.done = have if mode == "ab" else 0
                    self.total = self.total or self.done + int(r.headers.get("Content-Length", 0))
                    with open(part, mode) as f:
                        for chunk in r.iter_content(256 * 1024):
                            if cancel.is_set() or not resume.is_set():
                                break
                            f.write(chunk)
                            self.done += len(chunk)
                            now = time.time()
                            if now - last_emit > 0.15:
                                self.speed = (self.done - d0) / max(0.001, now - t0)
                                last_emit = now
                                self._emit()
                if cancel.is_set():
                    break
                if not resume.is_set():  # пауза: соединение закрыто, ждём «Продолжить»
                    t0, d0 = time.time(), self.done
                    continue
                break
            except Exception as e:
                fails += 1
                if cancel.is_set():
                    break
                if fails > 5:
                    self.state, self.error = "error", f"Загрузка не удалась: {e}"
                    return self._emit()
                time.sleep(min(10, 2 * fails))
        if cancel.is_set():
            with suppress(Exception):
                part.unlink(missing_ok=True)
            return
        try:
            h = hashlib.sha256()
            with open(part, "rb") as f:
                for block in iter(lambda: f.read(1 << 20), b""):
                    h.update(block)
            if h.hexdigest().lower() != str(pkg["sha256"]).lower():
                part.unlink(missing_ok=True)
                raise RuntimeError("файл повреждён при загрузке (не совпала контрольная сумма) — скачайте ещё раз")
            part.replace(self.zip_path)
            self.state, self.speed = "ready", 0.0
        except Exception as e:
            self.state, self.error = "error", f"Ошибка проверки обновления: {e}"
        self._emit()

    # --- установка ---
    def install(self):
        """Ставит скачанный пакет и перезапускает программу. Код (patch) меняется сразу; полный пакет
        копирует отдельный помощник после закрытия программы. Предыдущий код сохраняется в app_prev."""
        import zipfile
        if self.state != "ready" or not INSTALL_DIR:
            return
        self.state = "installing"
        self._emit()
        exe = Path(sys.executable)
        try:
            if self.package["kind"] == "patch":
                new, cur, prev = INSTALL_DIR / "app_new", INSTALL_DIR / "app", INSTALL_DIR / "app_prev"
                shutil.rmtree(new, ignore_errors=True)
                with zipfile.ZipFile(self.zip_path) as z:
                    for m in z.namelist():
                        if m.startswith("app/") and not m.endswith("/"):
                            (new / m[4:]).parent.mkdir(parents=True, exist_ok=True)
                            (new / m[4:]).write_bytes(z.read(m))
                compile((new / "app.py").read_text(encoding="utf-8"), "app.py", "exec")  # битый код не ставим
                shutil.rmtree(prev, ignore_errors=True)
                if cur.exists():
                    cur.rename(prev)
                new.rename(cur)
                self.zip_path.unlink(missing_ok=True)
                subprocess.Popen([str(exe)], cwd=str(INSTALL_DIR), creationflags=getattr(subprocess, "DETACHED_PROCESS", 0))
            else:
                staging = UPDATES_DIR / "staging"
                shutil.rmtree(staging, ignore_errors=True)
                with zipfile.ZipFile(self.zip_path) as z:
                    z.extractall(staging)
                if not (staging / exe.name).exists():
                    raise RuntimeError("в пакете нет файла программы")
                helper = UPDATES_DIR / "apply_update.ps1"
                helper.write_text(
                    "param([int]$ProcId, [string]$Src, [string]$Dst, [string]$Exe, [string]$Zip)\n"
                    "Wait-Process -Id $ProcId -Timeout 90 -ErrorAction SilentlyContinue\n"
                    "Start-Sleep -Milliseconds 700\n"
                    "robocopy $Src $Dst /MIR /XD models app_prev /R:5 /W:1 /NFL /NDL /NJH /NJS /NP | Out-Null\n"
                    "if ($LASTEXITCODE -lt 8) { Remove-Item $Src -Recurse -Force -ErrorAction SilentlyContinue; "
                    "Remove-Item $Zip -Force -ErrorAction SilentlyContinue }\n"
                    "Start-Process -FilePath $Exe -WorkingDirectory $Dst\n", encoding="utf-8-sig")
                subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden",
                                  "-File", str(helper), "-ProcId", str(os.getpid()), "-Src", str(staging),
                                  "-Dst", str(INSTALL_DIR), "-Exe", str(exe), "-Zip", str(self.zip_path)],
                                 creationflags=NO_WINDOW_FLAG)
            return True
        except Exception as e:
            self.state, self.error = "error", f"Не удалось установить обновление: {e}"
            self._emit()
            return False


# ---------------------------- UI-ХЕЛПЕРЫ ----------------------------
def F(size=12, bold=False):
    return ("Segoe UI", size, "bold") if bold else ("Segoe UI", size)


BTN_STYLES = {
    "primary": dict(fg_color=MD3["primary"], hover_color=MD3["primary_hover"], text_color=MD3["on_primary"]),
    "secondary": dict(fg_color=MD3["secondary_container"], hover_color=MD3["surface_highest"], text_color=MD3["on_secondary"]),
    "surface": dict(fg_color=MD3["surface_high"], hover_color=MD3["surface_highest"], text_color=MD3["on_surface"],
                    border_width=1, border_color=MD3["outline"]),
    "ghost": dict(fg_color="transparent", hover_color=MD3["surface_highest"], text_color=MD3["on_surface"]),
    "danger": dict(fg_color=MD3["error_container"], hover_color="#A8241E", text_color="#FFDAD6"),
    "success": dict(fg_color=MD3["success_container"], hover_color="#284D3E", text_color=MD3["on_success"]),
}
DISABLED_BTN = dict(state="disabled", fg_color=MD3["surface_highest"], text_color=MD3["on_surface_var"])


def button(parent, text, command=None, style="secondary", **kw):
    return ctk.CTkButton(parent, text=text, command=command, **{**BTN_STYLES[style], **kw})


def card(parent, **kw):
    return ctk.CTkFrame(parent, **{"fg_color": MD3["surface_container"], "corner_radius": 16, "border_width": 1,
                                   "border_color": MD3["outline"], **kw})


def label(parent, text="", font=None, color="on_surface", **kw):
    if font is not None:
        kw["font"] = font
    return ctk.CTkLabel(parent, text=text, text_color=MD3.get(color, color), **kw)


def entry(parent, **kw):
    return ctk.CTkEntry(parent, **{"fg_color": MD3["surface_high"], "border_color": MD3["outline"],
                                   "text_color": MD3["on_surface"], "corner_radius": 10, **kw})


def checkbox(parent, text, variable, command=None, font=None):
    kw = {"font": font} if font else {}
    return ctk.CTkCheckBox(parent, text=text, variable=variable, command=command, fg_color=MD3["primary"],
                           checkmark_color=MD3["on_primary"], **kw)


def combo(parent, values, value, width=None, **kw):
    kw = {"fg_color": MD3["surface_high"], "border_color": MD3["outline"], "button_color": MD3["secondary_container"], **kw}
    if width:
        kw["width"] = width
    c = ctk.CTkComboBox(parent, values=values, **kw)
    c.set(value)
    return c


def slider(parent, lo, hi, value, width, command):
    s = ctk.CTkSlider(parent, from_=lo, to=hi, number_of_steps=hi - lo, width=width, button_color=MD3["primary"],
                      progress_color=MD3["primary"], command=command)
    s.set(value)
    return s


def ctk_image(pil_img, size):
    return ctk.CTkImage(light_image=pil_img, dark_image=pil_img, size=size)


def ask_yes_no(parent, title: str, message: str) -> bool:
    """Модальное окно-предупреждение в стиле программы с кнопками «Да» / «Нет»."""
    result = {"yes": False}
    dlg = ctk.CTkToplevel(parent)
    dlg.title(title)
    dlg.configure(fg_color=MD3["bg"])
    dlg.resizable(False, False)
    dlg.transient(parent)
    body = card(dlg)
    body.pack(fill="both", expand=True, padx=12, pady=12)
    label(body, "⚠", font=F(34, True), color="tertiary").pack(pady=(14, 0))
    label(body, message, font=F(13), wraplength=430, justify="center").pack(padx=22, pady=(4, 16))
    row = ctk.CTkFrame(body, fg_color="transparent")
    row.pack(pady=(0, 18))

    def _close(val):
        result["yes"] = val
        with suppress(Exception):
            dlg.grab_release()
        dlg.destroy()

    style = dict(width=140, height=38, corner_radius=19, font=F(13, True))
    button(row, "Да", lambda: _close(True), "danger", **style).pack(side="left", padx=8)
    no_btn = button(row, "Нет", lambda: _close(False), "primary", **style)
    no_btn.pack(side="left", padx=8)
    dlg.protocol("WM_DELETE_WINDOW", lambda: _close(False))
    dlg.bind("<Escape>", lambda _e: _close(False))
    dlg.update_idletasks()
    w, h = dlg.winfo_reqwidth(), dlg.winfo_reqheight()
    x = parent.winfo_rootx() + (parent.winfo_width() - w) // 2
    y = parent.winfo_rooty() + (parent.winfo_height() - h) // 3
    dlg.geometry(f"+{max(0, x)}+{max(0, y)}")
    dlg.lift()
    dlg.attributes("-topmost", True)
    with suppress(Exception):
        dlg.wait_visibility()
        dlg.grab_set()
    no_btn.focus_set()
    parent.wait_window(dlg)
    return result["yes"]


# ---------------------------- ВСПЛЫВАЮЩИЕ ОКНА ПОВЕРХ ИНТЕРФЕЙСА ----------------------------
class Overlay:
    """
    Окно по центру поверх размытого интерфейса: крестик справа вверху, закрытие кликом мимо окна или Esc.
    Наследники задают TITLE и метод build(body); render() перестраивает содержимое.
    """
    WIDTH, TITLE, SCROLL_HEIGHT = 540, "", 0

    def __init__(self, app):
        self.app = app
        self.backdrop = self.panel = self.body = None
        self._photo = self._resize_job = None
        self._refs = []

    @property
    def is_open(self) -> bool:
        return self.panel is not None

    def open(self):
        if self.is_open:
            return
        for other in self.app.overlays:  # одновременно открыто только одно окно
            if other is not self:
                other.close()
        self._show_backdrop()
        self.panel = card(self.app, corner_radius=20, border_color=MD3["secondary_container"])
        self.panel.place(relx=0.5, rely=0.5, anchor="center")
        head = ctk.CTkFrame(self.panel, fg_color="transparent")
        head.pack(fill="x", padx=(22, 12), pady=(14, 4))
        label(head, self.TITLE, F(18, True)).pack(side="left")
        button(head, "✕", self.close, "ghost", width=34, height=34, corner_radius=17, font=F(15, True)).pack(side="right")
        ctk.CTkFrame(self.panel, fg_color="transparent", width=self.WIDTH, height=1).pack()  # фиксирует ширину окна
        if self.SCROLL_HEIGHT:
            h = max(260, min(self.SCROLL_HEIGHT, int(self.app.winfo_height() / max(0.5, self.app._get_window_scaling())) - 200))
            self.body = ctk.CTkScrollableFrame(self.panel, fg_color="transparent", height=h, width=self.WIDTH - 20)
        else:
            self.body = ctk.CTkFrame(self.panel, fg_color="transparent")
        self.body.pack(fill="both", expand=True, padx=22 if not self.SCROLL_HEIGHT else (14, 8), pady=(0, 22))
        self.build_footer(self.panel)
        self.app.bind("<Escape>", lambda _e: self.close(), add="+")
        self.render()

    def close(self):
        for w in (self.panel, self.backdrop):
            if w is not None:
                with suppress(Exception):
                    w.destroy()
        self.panel = self.backdrop = self.body = None
        self._photo = None
        self.on_close()
        with suppress(Exception):
            self.app.unbind("<Escape>")

    def render(self):
        if not self.is_open:
            return
        for w in self.body.winfo_children():
            w.destroy()
        self._refs.clear()
        self.build(self.body)

    # для наследников
    def build(self, body):
        pass

    def build_footer(self, panel):
        pass

    def on_close(self):
        pass

    # --- размытый фон ---
    def _blurred_screenshot(self):
        try:
            from PIL import ImageGrab, ImageFilter, ImageEnhance, ImageTk
            a = self.app
            a.update_idletasks()
            x, y, w, h = a.winfo_rootx(), a.winfo_rooty(), a.winfo_width(), a.winfo_height()
            img = ImageGrab.grab(bbox=(x, y, x + w, y + h), all_screens=True).convert("RGB")
            small = img.resize((max(1, w // 3), max(1, h // 3)), Image.Resampling.BILINEAR).filter(ImageFilter.GaussianBlur(2))
            self._photo = ImageTk.PhotoImage(ImageEnhance.Brightness(small.resize((w, h), Image.Resampling.BILINEAR)).enhance(0.72))
            return self._photo
        except Exception:
            return None  # нет снимка — просто затемнённый фон

    def _show_backdrop(self):
        photo = self._blurred_screenshot()
        if self.backdrop is None:
            self.backdrop = tk.Label(self.app, bd=0, highlightthickness=0, bg="#0d0c10")
            self.backdrop.bind("<Button-1>", lambda _e: self.close())
        self.backdrop.configure(image=photo or "")
        self.backdrop.place(x=0, y=0, relwidth=1, relheight=1)

    def on_resize(self):
        if self.is_open:
            if self._resize_job:
                self.app.after_cancel(self._resize_job)
            self._resize_job = self.app.after(250, self._reblur)

    def _reblur(self):
        self._resize_job = None
        if not self.is_open:
            return
        self.backdrop.place_forget()
        self.panel.place_forget()
        self.app.update()
        self._show_backdrop()
        self.panel.place(relx=0.5, rely=0.5, anchor="center")

    @staticmethod
    def _title(parent, text, top=10):
        label(parent, text, F(14, True), "primary", anchor="w").pack(fill="x", pady=(top, 6))


# ---------------------------- ОКНО НАСТРОЕК ----------------------------
class SettingsOverlay(Overlay):
    """Настройки. Новый раздел = метод self._section_<имя>(parent) + его имя в SECTIONS."""
    TITLE = "Настройки"
    SECTIONS = ("gdrive", "storage", "updates")

    def __init__(self, app):
        super().__init__(app)
        self.login_busy = self.editing_folder = False

    def on_close(self):
        self.editing_folder = False

    def build(self, body):
        for name in self.SECTIONS:
            getattr(self, f"_section_{name}")(body)

    def build_footer(self, panel):
        label(panel, f"v{APP_VERSION}", F(11), "outline").place(relx=1.0, rely=1.0, x=-16, y=-8, anchor="se")

    def _section_gdrive(self, parent):
        self._title(parent, "Интеграция с Google Drive", top=4)
        row = ctk.CTkFrame(parent, fg_color=MD3["surface_high"], corner_radius=14)
        row.pack(fill="x")
        drive = self.app.drive
        if drive.connected:
            u = drive.user
            av = ctk_image(circle_avatar(u.get("avatar", ""), 72), (36, 36))
            self._refs.append(av)
            ctk.CTkLabel(row, text="", image=av).pack(side="left", padx=(12, 10), pady=10)
            names = ctk.CTkFrame(row, fg_color="transparent")
            names.pack(side="left", fill="x", expand=True)
            label(names, u.get("name", "Google"), F(13, True), anchor="w").pack(fill="x")
            if u.get("email"):
                label(names, u["email"], F(11), "on_surface_var", anchor="w").pack(fill="x")
            door = ctk_image(make_logout_icon(40), (20, 20))
            self._refs.append(door)
            button(row, "", self._logout, "ghost", image=door, width=36, height=36, corner_radius=10,
                   hover_color="#4A1F1F").pack(side="right", padx=10)
        else:
            text = "Ожидание входа в окне браузера..." if self.login_busy else "Подключить аккаунт"
            b = button(row, text, self._connect, "primary", height=36, corner_radius=18, font=F(13, True))
            if self.login_busy:
                b.configure(state="disabled")
            b.pack(side="left", padx=12, pady=12)
            label(row, "Отдельный аккаунт — не связан с YouTube", F(11), "on_surface_var").pack(side="left", padx=(4, 12))

    def _radio(self, parent, text, value, enabled=True):
        rb = ctk.CTkRadioButton(parent, text=text, value=value, variable=self.mode_var, command=self._on_mode,
                                font=F(13, True), fg_color=MD3["primary"], hover_color=MD3["primary_hover"],
                                border_color=MD3["on_surface_var"], text_color=MD3["on_surface"],
                                text_color_disabled=MD3["outline"], state="normal" if enabled else "disabled")
        rb.pack(fill="x", anchor="w", pady=(8, 2))
        return rb

    def _path_row(self, parent, caption, value, command):
        row = ctk.CTkFrame(parent, fg_color=MD3["surface_high"], corner_radius=12)
        row.pack(fill="x", padx=(28, 0), pady=(2, 4))
        label(row, caption, F(11), "on_surface_var", anchor="w").pack(fill="x", padx=12, pady=(6, 0))
        line = ctk.CTkFrame(row, fg_color="transparent")
        line.pack(fill="x", padx=12, pady=(0, 8))
        shown = value if len(value) <= 52 else "…" + value[-50:]
        label(line, shown, F(12, True), anchor="w").pack(side="left", fill="x", expand=True)
        button(line, "Изменить...", command, width=100, height=28, corner_radius=14).pack(side="right")

    def _section_storage(self, parent):
        app, drive = self.app, self.app.drive
        self._title(parent, "Хранилище клипов", top=16)
        mode = app.config_data.get("storage_mode", "local")
        if mode == "cloud" and not drive.connected:
            mode = app.config_data["storage_mode"] = "local"
        self.mode_var = tk.StringVar(value=mode)
        self._radio(parent, "Локальное хранилище", "local")
        if mode == "local":
            self._path_row(parent, "Клипы сохраняются в папку (для каждого запуска — подпапка Clips_Output_…):",
                           str(app.local_root()), self._change_local_dir)
        self._radio(parent, "Облачное хранилище (Google Drive)", "cloud", enabled=drive.connected)
        if not drive.connected:
            label(parent, "Станет доступно после подключения Google Drive", F(11), "outline", anchor="w").pack(fill="x", padx=28)
        elif mode == "cloud":
            folder = app.config_data.get("gdrive_folder", "Клипы")
            if self.editing_folder:
                self._folder_editor(parent, folder)
            else:
                self._path_row(parent, "Папка на Google Drive («Мой диск»), создаётся при первом сохранении:",
                               f"/{folder}", self._start_edit_folder)
            label(parent, "Рабочая копия клипа остаётся на ПК — для просмотра, редактирования и загрузки на YouTube/TikTok.",
                  F(11), "on_surface_var", anchor="w", justify="left", wraplength=480).pack(fill="x", padx=28, pady=(2, 0))

    def _section_updates(self, parent):
        u = self.app.updater
        self._title(parent, "Обновления", top=16)
        row = ctk.CTkFrame(parent, fg_color="transparent")
        row.pack(fill="x")
        b = button(row, "Проверить обновления", self._check_updates, height=32, corner_radius=16, font=F(12, True))
        if not u.enabled or u.checking:
            b.configure(state="disabled")
        b.pack(side="left")
        if not u.enabled:
            status, color = u.disabled_reason, "outline"
        elif u.checking:
            status, color = "Проверка...", "on_surface_var"
        elif u.available:
            status, color = f"Доступна версия {u.new_version}", "primary"
        elif u.last_check == "latest":
            status, color = "Установлена последняя версия", "on_success"
        elif u.last_check == "error":
            status, color = "Не удалось проверить — нет связи с GitHub", "error"
        else:
            status, color = "", "on_surface_var"
        label(row, status, F(12, True), color).pack(side="left", padx=12)
        if u.enabled and u.available and not u.checking:
            button(row, "Обновить", self.app.updates_overlay.open, "primary", width=96, height=32, corner_radius=16,
                   font=F(12, True)).pack(side="left")

    def _check_updates(self):
        run_bg(self.app.updater.check)
        self.app.after(50, self.render)

    def _folder_editor(self, parent, folder):
        row = ctk.CTkFrame(parent, fg_color=MD3["surface_high"], corner_radius=12)
        row.pack(fill="x", padx=(28, 0), pady=(2, 4))
        label(row, "Путь от «Мой диск», вложенные папки через «/» (например: Клипы/Shorts):", F(11), "on_surface_var",
              anchor="w").pack(fill="x", padx=12, pady=(6, 2))
        line = ctk.CTkFrame(row, fg_color="transparent")
        line.pack(fill="x", padx=12, pady=(0, 8))
        ent = entry(line, height=30)
        ent.insert(0, folder)
        ent.pack(side="left", fill="x", expand=True, padx=(0, 8))
        save = lambda *_: self._save_folder(ent.get())
        ent.bind("<Return>", save)
        button(line, "✓", save, "primary", width=34, height=30, corner_radius=15, font=F(13, True)).pack(side="left", padx=(0, 4))
        button(line, "✕", self._cancel_edit_folder, width=34, height=30, corner_radius=15).pack(side="left")
        ent.focus_set()

    # --- действия ---
    def _on_mode(self):
        self.app.set_storage_mode(self.mode_var.get())
        self.editing_folder = False
        self.render()

    def _change_local_dir(self):
        path = filedialog.askdirectory(title="Папка для сохранения клипов", initialdir=str(self.app.local_root()), parent=self.app)
        if path:
            self.app.config_data["local_dir"] = path
            self.app.save_config()
            self.app.log(f"[*] Клипы будут сохраняться в: {path}")
        self.render()

    def _start_edit_folder(self):
        self.editing_folder = True
        self.render()

    def _cancel_edit_folder(self):
        self.editing_folder = False
        self.render()

    def _save_folder(self, value):
        folder = GoogleDrive.normalize_folder(value)
        self.app.config_data["gdrive_folder"] = folder
        self.app.save_config()
        self.app.log(f"[*] Папка на Google Drive для клипов: /{folder}")
        self.editing_folder = False
        self.render()

    def _connect(self):
        if self.login_busy:
            return
        if not GoogleDrive.has_client():
            if not ask_yes_no(self.app, "Настройка Google Drive",
                              "Для входа нужен файл OAuth-клиента Google (client_secret_….json, тип «Desktop app»), "
                              "его создают один раз в Google Cloud Console.\n\nВыбрать этот файл сейчас?"):
                return
            path = filedialog.askopenfilename(title="Файл OAuth-клиента Google", parent=self.app,
                                              filetypes=[("JSON", "*.json"), ("Все файлы", "*.*")])
            if not path:
                return
            try:
                GoogleDrive.import_client(path)
            except Exception as e:
                messagebox.showerror("Google Drive", str(e), parent=self.app)
                return
        self.login_busy = True
        self.render()
        self.app.log("[*] Открытие окна браузера для входа в Google Drive...")

        def _worker():
            err = None
            try:
                user = self.app.drive.login()
                self.app.log(f"[+] Google Drive подключён: {user.get('name')} ({user.get('email')})")
            except Exception as e:
                err = str(e)
                self.app.log(f"[-] Google Drive: {err}")

            def _done():
                self.login_busy = False
                self.render()
                if err and err != "Вход отменён.":
                    messagebox.showwarning("Google Drive", err, parent=self.app)
            self.app.after(0, _done)
        run_bg(_worker)

    def _logout(self):
        name = self.app.drive.user.get("name", "Google")
        if not ask_yes_no(self.app, "Выход из аккаунта",
                          f"Выйти из аккаунта Google Drive «{name}»?\n\nКлипы, уже сохранённые на Google Drive, останутся там. "
                          "Новые клипы будут сохраняться в локальное хранилище."):
            return
        self.app.drive.logout()
        self.app.set_storage_mode("local")
        self.app.log(f"[*] Выполнен выход из Google Drive ({name}).")
        self.render()


# ---------------------------- ОКНО ОБНОВЛЕНИЯ ----------------------------
@lru_cache(maxsize=4)
def make_download_icon(size: int = 22, color=(208, 188, 255, 255)) -> Image.Image:
    s = size * 4
    im = Image.new("RGBA", (s, s), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    w = max(2, s // 10)
    d.line((s * 0.5, s * 0.10, s * 0.5, s * 0.62), fill=color, width=w)
    d.polygon([(s * 0.5, s * 0.74), (s * 0.27, s * 0.47), (s * 0.73, s * 0.47)], fill=color)
    d.line((s * 0.14, s * 0.70, s * 0.14, s * 0.88, s * 0.86, s * 0.88, s * 0.86, s * 0.70), fill=color, width=w, joint="curve")
    return im.resize((size, size), Image.Resampling.LANCZOS)


class UpdateOverlay(Overlay):
    TITLE = "Обновление программы"
    SCROLL_HEIGHT = 600

    def __init__(self, app):
        super().__init__(app)
        self.expanded = set()
        self.pbar = self.ptext = None
        self._shown_state = None

    def on_close(self):
        self.pbar = self.ptext = None

    def refresh(self):
        """Смена состояния — перестроить окно; идёт загрузка — обновить только шкалу (без мерцания)."""
        if not self.is_open:
            return
        u = self.app.updater
        if u.state != self._shown_state or self.pbar is None:
            return self.render()
        self.pbar.set(u.done / u.total if u.total else 0)
        self.ptext.configure(text=self._progress_text())

    def _progress_text(self) -> str:
        u = self.app.updater
        if u.state == "ready":
            return f"Загружено {fmt_mb(u.total)} — обновление готово к установке"
        if u.state == "installing":
            return "Установка обновления — программа перезапустится..."
        base = f"{fmt_mb(u.done)} из {fmt_mb(u.total)}" if u.total else fmt_mb(u.done)
        if u.state == "paused":
            return f"{base} · на паузе"
        return f"{base} · {fmt_mb(u.speed)}/с" if u.speed > 0 else base

    def build(self, body):
        u = self.app.updater
        self._shown_state = u.state
        self.pbar = self.ptext = None
        W = self.WIDTH - 60
        vers = ctk.CTkFrame(body, fg_color=MD3["surface_high"], corner_radius=14)
        vers.pack(fill="x", pady=(2, 10))
        for i, (cap, val, col) in enumerate((("Текущая версия", APP_VERSION, "on_surface"),
                                              ("Новая версия", u.new_version or "—", "primary"))):
            box = ctk.CTkFrame(vers, fg_color="transparent")
            box.pack(side="left", expand=True, fill="x", padx=14, pady=10)
            label(box, cap, F(11), "on_surface_var").pack()
            label(box, val, F(20, True), col).pack()
            if i == 0:
                label(vers, "→", F(20, True), "on_surface_var").pack(side="left")
        if not u.available:
            label(body, "Установлена последняя версия программы.", F(13), "on_success").pack(anchor="w", pady=6)
            return

        pkg = u.package
        if pkg.get("size"):
            kind = "только код программы" if pkg["kind"] == "patch" else "полное обновление — изменились библиотеки"
            label(body, f"Размер загрузки: {fmt_mb(pkg['size'])} ({kind})", F(11), "on_surface_var", anchor="w").pack(fill="x")
        if u.state in ("downloading", "paused", "ready", "installing"):
            self.pbar = ctk.CTkProgressBar(body, height=12, corner_radius=6, fg_color=MD3["surface_high"], progress_color=MD3["primary"])
            self.pbar.pack(fill="x", pady=(10, 4))
            self.pbar.set(1.0 if u.state in ("ready", "installing") else (u.done / u.total if u.total else 0))
            self.ptext = label(body, self._progress_text(), F(11), "on_surface_var", anchor="w")
            self.ptext.pack(fill="x")
        if u.state == "error" and u.error:
            label(body, u.error, F(12), "error", anchor="w", justify="left", wraplength=W).pack(fill="x", pady=(8, 0))

        row = ctk.CTkFrame(body, fg_color="transparent")
        row.pack(fill="x", pady=(10, 4))
        big = dict(height=38, corner_radius=19, font=F(13, True))
        if u.state in ("idle", "error"):
            button(row, f"Обновить до версии {u.new_version}", u.start, "primary", **big).pack(side="left")
        elif u.state == "downloading":
            button(row, "Пауза", u.pause, width=130, **big).pack(side="left", padx=(0, 8))
            button(row, "Прервать", u.abort, "danger", width=130, **big).pack(side="left")
        elif u.state == "paused":
            button(row, "Продолжить", u.resume, "primary", width=130, **big).pack(side="left", padx=(0, 8))
            button(row, "Прервать", u.abort, "danger", width=130, **big).pack(side="left")
        elif u.state == "ready":
            button(row, "Перезапустить и установить", self.app.install_update, "primary", **big).pack(side="left", padx=(0, 8))
            button(row, "Прервать", u.abort, "danger", width=130, **big).pack(side="left")
        else:
            button(row, "Установка...", None, "primary", state="disabled", **big).pack(side="left")

        log = u.changelog()
        latest = next((e for e in log if str(e.get("version")) == u.new_version), None)
        if latest:
            self._title(body, f"Что нового в версии {u.new_version}" + (f" · {latest['date']}" if latest.get("date") else ""), top=16)
            self._changes(body, latest, W)
        older = [e for e in log if parse_version(e.get("version")) < parse_version(u.new_version)]
        if older:
            self._title(body, "Предыдущие версии", top=18)
        for e in older:
            v = str(e.get("version"))
            is_open = v in self.expanded
            button(body, f"{'▼' if is_open else '▶'}  Версия {v}" + (f"  ·  {e['date']}" if e.get("date") else ""),
                   lambda v=v: self._toggle(v), "ghost", anchor="w", height=30, corner_radius=10, font=F(12, True),
                   text_color=MD3["on_surface"]).pack(fill="x", pady=1)
            if is_open:
                self._changes(body, e, W, indent=18)

    def _changes(self, parent, entry, width, indent=0):
        box = ctk.CTkFrame(parent, fg_color=MD3["surface_high"], corner_radius=12)
        box.pack(fill="x", padx=(indent, 0), pady=(0, 6))
        groups = entry.get("changes") or {}
        if isinstance(groups, list):
            groups = {"": groups}
        for group, items in groups.items():
            if group:
                label(box, group, F(12, True), "tertiary", anchor="w").pack(fill="x", padx=12, pady=(8, 2))
            for item in items:
                label(box, f"•  {item}", F(12), anchor="w", justify="left", wraplength=width - indent - 30).pack(fill="x", padx=(16, 12), pady=1)
        ctk.CTkFrame(box, fg_color="transparent", height=6).pack()

    def _toggle(self, v):
        self.expanded ^= {v}
        self.render()


# ---------------------------- ОКНО РЕДАКТОРА КЛИПА ----------------------------
class VideoEditorWindow(ctk.CTkToplevel):
    ADV_TEXT = "Дополнительно (Отзеркаливание, персонажи, цвета и окраска по слову)"
    SUB_RE = re.compile(r"^\s*\[?\s*(\d+(?:\.\d+)?)\s*-\s*(\d+(?:\.\d+)?)\s*\]?\s*(?:\(\s*Персонаж\s*№?\s*(\d+)\s*\))?\s*(.+)$",
                        re.IGNORECASE)

    def __init__(self, app, clip: dict):
        super().__init__(app)
        self.app, self.clip = app, clip
        self.title(f"Редактировать видео — {clip['title']}")
        self.geometry("840x840")
        self.minsize(750, 650)
        self.configure(fg_color=MD3["bg"])
        self.is_dirty = self.adv_expanded = False
        self.orig_subs_text = self._format_subs_to_text(clip.get("subs", []), clip["start"])
        self.styles = json.loads(json.dumps(clip.get("speaker_styles", {})))
        self.font_size = int(clip.get("font_size", 70))
        self.word_by_word = bool(clip.get("word_by_word", False))
        self.mirror = bool(clip.get("mirror", False))
        self._build_ui()
        self.transient(app)
        self.focus()

    @staticmethod
    def _format_subs_to_text(subs, clip_start) -> str:
        out = []
        for s in subs:
            rs = max(0.0, float(s["start"]) - clip_start)
            re_ = max(rs + 0.3, float(s["end"]) - clip_start)
            out.append(f"[{rs:.1f} - {re_:.1f}] (Персонаж №{int(s.get('speaker_id', 0)) + 1}) {s.get('text', '').strip()}")
        return "\n".join(out)

    def _parse_text_to_subs(self, raw: str) -> list:
        c0 = float(self.clip["start"])
        orig = self.clip.get("subs", [])
        parsed = []
        for idx, line in enumerate(raw.splitlines()):
            line = line.strip()
            if not line:
                continue
            m = self.SUB_RE.match(line)
            if m:
                rs, txt = float(m.group(1)), m.group(4).strip()
                item = {"start": c0 + rs, "end": c0 + max(rs + 0.2, float(m.group(2))),
                        "speaker_id": max(0, int(m.group(3)) - 1 if m.group(3) else 0), "text": txt}
                if idx < len(orig) and orig[idx].get("text", "").strip() == txt:
                    item["words"] = orig[idx].get("words")
            elif idx < len(orig):
                item = {"start": orig[idx]["start"], "end": orig[idx]["end"],
                        "speaker_id": orig[idx].get("speaker_id", 0), "text": line}
            else:
                item = {"start": c0 + idx * 2.5, "end": c0 + (idx + 1) * 2.5, "speaker_id": 0, "text": line}
            parsed.append(item)
        return parsed

    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        meta = card(self)
        meta.grid(row=0, column=0, padx=16, pady=(14, 6), sticky="ew")
        meta.grid_columnconfigure(1, weight=1)
        label(meta, "Название ролика:", F(12, True)).grid(row=0, column=0, padx=12, pady=(10, 4), sticky="w")
        self.yt_title_entry = entry(meta, font=F(12), corner_radius=6)
        self.yt_title_entry.grid(row=0, column=1, padx=(0, 12), pady=(10, 4), sticky="ew")
        self.yt_title_entry.insert(0, self.clip.get("yt_title", self.clip["title"]))
        self.yt_title_entry.bind("<KeyRelease>", self._on_meta_changed)
        label(meta, "Описание + хэштеги:", F(12, True)).grid(row=1, column=0, padx=12, pady=(4, 10), sticky="nw")
        self.yt_desc_box = ctk.CTkTextbox(meta, height=62, font=F(12), fg_color=MD3["surface_high"], corner_radius=10)
        self.yt_desc_box.grid(row=1, column=1, padx=(0, 12), pady=(4, 10), sticky="ew")
        self.yt_desc_box.insert("1.0", self.clip.get("yt_description", ""))
        self.yt_desc_box.bind("<KeyRelease>", self._on_meta_changed)

        label(self, "Субтитры клипа (формат: [сек_начала - сек_конца] (Персонаж №1) Текст):", F(13, True),
              anchor="w").grid(row=1, column=0, padx=16, pady=(4, 2), sticky="ew")
        self.sub_textbox = ctk.CTkTextbox(self, font=("Consolas", 13), fg_color=MD3["surface_container"],
                                          text_color=MD3["on_surface"], corner_radius=14, border_width=1,
                                          border_color=MD3["outline"])
        self.sub_textbox.grid(row=2, column=0, padx=16, pady=4, sticky="nsew")
        self.sub_textbox.insert("1.0", self.orig_subs_text)
        self.sub_textbox.bind("<KeyRelease>", self._on_text_modified)

        size_bar = ctk.CTkFrame(self, fg_color=MD3["surface_container"], corner_radius=12)
        size_bar.grid(row=3, column=0, padx=16, pady=4, sticky="ew")
        self.size_lbl = label(size_bar, f"Размер субтитров: {self.font_size} px", F(13, True), width=195, anchor="w")
        self.size_lbl.pack(side="left", padx=(14, 10), pady=8)
        slider(size_bar, 24, 128, min(128, max(24, self.font_size)), 300, self._on_size_slider).pack(side="left", padx=(0, 12), pady=8)

        adv = ctk.CTkFrame(self, fg_color=MD3["surface_container"], corner_radius=12)
        adv.grid(row=4, column=0, padx=16, pady=4, sticky="ew")
        adv.grid_columnconfigure(0, weight=1)
        self.adv_btn = button(adv, f"▶ {self.ADV_TEXT}", self._toggle_advanced, "ghost", anchor="w",
                              hover_color=MD3["surface_high"], text_color=MD3["primary"], font=F(13, True))
        self.adv_btn.grid(row=0, column=0, padx=6, pady=4, sticky="ew")
        self.adv_body = ctk.CTkFrame(adv, fg_color=MD3["surface_high"], corner_radius=10)

        flags = ctk.CTkFrame(self.adv_body, fg_color="transparent")
        flags.pack(fill="x", padx=12, pady=(8, 4))
        self.mirror_var = ctk.BooleanVar(value=self.mirror)
        checkbox(flags, "Отзеркалить видео", self.mirror_var, self._on_mirror_toggle, F(12, True)).pack(side="left", padx=(0, 24))
        self.wbw_var = ctk.BooleanVar(value=self.word_by_word)
        checkbox(flags, "Окраска по слову", self.wbw_var, self._on_wbw_toggle, F(12, True)).pack(side="left")

        self.color_buttons, self.mode_combos = {}, {}
        for sp in range(max(1, int(self.clip.get("speakers_count", 1)))):
            st = self.styles.get(str(sp), {})
            hex_col = st.get("color", speaker_hex(sp))
            mode = st.get("mode", "bg" if self.clip.get("default_bg", False) else "text")
            row = ctk.CTkFrame(self.adv_body, fg_color="transparent")
            row.pack(fill="x", padx=12, pady=5)
            label(row, f"Персонаж №{sp + 1}", F(13, True), width=110, anchor="w").pack(side="left", padx=(4, 6))
            fem_var = ctk.BooleanVar(value=bool(st.get("is_female")))
            checkbox(row, "Жен.", fem_var, lambda i=sp, v=fem_var: self._on_gender_toggle(i, v.get()),
                     F(12)).pack(side="left", padx=(0, 12))
            cb = tk.Button(row, bg=hex_col, activebackground=hex_col, width=4, height=1, relief="solid", bd=1,
                           cursor="hand2", command=lambda i=sp: self._pick_speaker_color(i))
            cb.pack(side="left", padx=(0, 14))
            self.color_buttons[sp] = cb
            label(row, "Окрашивать:").pack(side="left", padx=(0, 8))
            mc = combo(row, ["Субтитры", "Задний фон"], "Задний фон" if mode == "bg" else "Субтитры", 155,
                       fg_color=MD3["surface_container"], command=lambda ch, i=sp: self._on_speaker_mode_change(i, ch))
            if self.word_by_word:
                mc.configure(state="disabled")
            mc.pack(side="left", padx=(0, 8))
            self.mode_combos[sp] = mc

        bottom = ctk.CTkFrame(self, fg_color="transparent")
        bottom.grid(row=5, column=0, padx=16, pady=(6, 14), sticky="ew")
        bottom.grid_columnconfigure(0, weight=1)
        self.save_btn = button(bottom, "Сохранить и перерендерить", self._save_and_rerender, "primary", height=44,
                               corner_radius=22, font=F(14, True))
        self.save_btn.configure(**DISABLED_BTN)
        self.save_btn.grid(row=0, column=0, sticky="ew")

    def _on_meta_changed(self, _e=None):
        self.clip["yt_title"] = self.yt_title_entry.get().strip()
        self.clip["yt_description"] = self.yt_desc_box.get("1.0", tk.END).strip()
        self.app._save_gallery_db()

    def _on_size_slider(self, val):
        sz = int(round(val))
        self.size_lbl.configure(text=f"Размер субтитров: {sz} px")
        if sz != int(self.clip.get("font_size", 70)):
            self.font_size = sz
            self._mark_dirty()

    def _on_mirror_toggle(self):
        self.mirror = bool(self.mirror_var.get())
        self._mark_dirty()

    def _on_wbw_toggle(self):
        self.word_by_word = bool(self.wbw_var.get())
        for sp, mc in self.mode_combos.items():
            if self.word_by_word:
                mc.set("Субтитры")
            mc.configure(state="disabled" if self.word_by_word else "normal")
            if str(sp) in self.styles:
                self.styles[str(sp)]["mode"] = "word" if self.word_by_word else "text"
        self._mark_dirty()

    def _toggle_advanced(self):
        self.adv_expanded = not self.adv_expanded
        self.adv_btn.configure(text=f"{'▼' if self.adv_expanded else '▶'} {self.ADV_TEXT}")
        if self.adv_expanded:
            self.adv_body.grid(row=1, column=0, padx=8, pady=(2, 8), sticky="ew")
        else:
            self.adv_body.grid_remove()

    def _mark_dirty(self):
        self.is_dirty = True
        self.save_btn.configure(state="normal", **BTN_STYLES["primary"])

    def _on_text_modified(self, _e=None):
        if self.sub_textbox.get("1.0", tk.END).strip() != self.orig_subs_text.strip():
            self._mark_dirty()
        elif not self.is_dirty:
            self.save_btn.configure(**DISABLED_BTN)

    def _pick_speaker_color(self, sp: int):
        cur = self.styles.get(str(sp), {}).get("color", speaker_hex(sp))
        chosen = colorchooser.askcolor(color=cur, title=f"Выберите цвет для Персонажа №{sp + 1}", parent=self)
        if chosen and chosen[1]:
            self._set_speaker_color(sp, chosen[1])
            self._mark_dirty()

    def _set_speaker_color(self, sp: int, hex_col: str):
        self.styles.setdefault(str(sp), {})["color"] = hex_col
        self.color_buttons[sp].configure(bg=hex_col, activebackground=hex_col)

    def _on_gender_toggle(self, sp: int, is_female: bool):
        """Ручная правка пола: персонаж перекрашивается в женскую/мужскую палитру."""
        st = self.styles.setdefault(str(sp), {"color": speaker_hex(sp), "mode": "word" if self.word_by_word else "text"})
        st["is_female"] = bool(is_female)
        fem_before = sum(1 for k, v in self.styles.items() if v.get("is_female") and int(k) < sp)
        self._set_speaker_color(sp, FEMALE_SPEAKER_HEX[fem_before % len(FEMALE_SPEAKER_HEX)] if is_female else speaker_hex(sp))
        self._mark_dirty()

    def _on_speaker_mode_change(self, sp: int, choice: str):
        if self.word_by_word:
            return
        self.styles.setdefault(str(sp), {"color": speaker_hex(sp)})["mode"] = "bg" if choice == "Задний фон" else "text"
        self._mark_dirty()

    def _save_and_rerender(self):
        if self.app.is_running:
            messagebox.showwarning("Процесс в работе", "Дождитесь окончания текущей обработки или остановите её.", parent=self)
            return
        self._on_meta_changed()
        subs = self._parse_text_to_subs(self.sub_textbox.get("1.0", tk.END))
        count = max([int(self.clip.get("speakers_count", 1))] + [s["speaker_id"] + 1 for s in subs])
        default_mode = "word" if self.word_by_word else ("bg" if self.clip.get("default_bg") else "text")
        for sp in range(count):  # новые «Персонаж №N», вписанные вручную, получают свой цвет
            self.styles.setdefault(str(sp), {"color": speaker_hex(sp), "mode": default_mode, "is_female": False})
        self.clip.update(subs=subs, speaker_styles=self.styles, speakers_count=count, font_size=self.font_size,
                         word_by_word=self.word_by_word, mirror=self.mirror)
        self.app._save_gallery_db()
        self.save_btn.configure(text="Идет перерендер видео...", **DISABLED_BTN)
        self.app.rerender_single_clip(self.clip, on_done=self._on_rerender_finished)

    def _on_rerender_finished(self, ok: bool):
        if not self.winfo_exists():
            return
        self.save_btn.configure(text="Сохранить и перерендерить")
        if ok:
            self.orig_subs_text = self._format_subs_to_text(self.clip.get("subs", []), self.clip["start"])
            self.is_dirty = False
            self.save_btn.configure(**DISABLED_BTN)
            messagebox.showinfo("Готово", f"Видео «{self.clip['title']}» успешно обновлено!", parent=self)
        else:
            self._mark_dirty()


# ---------------------------- ГЛАВНОЕ ОКНО ----------------------------
class ClipsStudioSK(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title(f"Clips Studio AI — Material Design 3 Edition (v{APP_VERSION} Fast & Optimized)")
        self.geometry("1180x980")
        self.minsize(980, 840)
        self.configure(fg_color=MD3["bg"])

        self.config_data = self.load_config()
        self.is_running = self.cancel_requested = False
        self._active_subprocesses = []
        self._balance_gen = 0

        self.current_transcript_text = ""
        self.transcript_popup = None
        self.speaker_tracker = ActiveSpeakerTracker()  # Ленивый: не грузит XML при старте

        hidden = read_json(HIDDEN_CLIPS_FILE, [])
        self.hidden_clip_paths = {str(Path(p).resolve()) for p in (hidden if isinstance(hidden, list) else [])}
        self.created_clips = []
        self.clips_section_shown_once = self.clips_user_collapsed = False
        self.logs_user_collapsed = self.clip_time_expanded = False
        self._current_grid_cols = 0
        self._resize_after_id = None
        self._thumb_refs = []

        self.selected_clip_paths = set()
        self.tile_widgets_map = {}
        self._lasso_start_root = self._lasso_popup = None
        self._lasso_moved = False

        self.drive = GoogleDrive()
        self.updater = Updater(lambda: self.after(0, self._on_update_state))
        self.settings = SettingsOverlay(self)
        self.updates_overlay = UpdateOverlay(self)
        self.overlays = (self.settings, self.updates_overlay)
        self.yt_state = self._load_yt_accounts()
        self.yt_menu_popup = self.platform_picker_popup = None
        self._yt_avatar_refs = []

        self.protocol("WM_DELETE_WINDOW", self._on_close_window_request)
        self._enable_russian_clipboard()
        self._build_ui()

        self.after(150, self._load_existing_clips_async)  # галерея — в фоне, после отрисовки окна
        self.after(STARTUP_BALANCE_DELAY_MS, self._startup_balance_check)  # баланс — через ~4 сек после старта
        self.after(UPDATE_FIRST_CHECK_MS, self._auto_check_updates)         # обновления — через 10 сек, затем раз в 15 мин
        self.bind("<Configure>", self._on_window_resize)
        self.after(180000, self._periodic_folder_sync)

    # --- СОСТОЯНИЕ «ИДЁТ РАБОТА», КНОПКА СТОП И ЗАЩИТА ОТ ЗАКРЫТИЯ ---
    def _register_subproc(self, proc):
        self._active_subprocesses = [p for p in self._active_subprocesses if p.poll() is None] + [proc]

    def _terminate_active_subprocesses(self):
        for p in self._active_subprocesses:
            with suppress(Exception):
                if p and p.poll() is None:
                    p.terminate()
                    p.kill()
        self._active_subprocesses.clear()

    def _check_cancel(self):
        if self.cancel_requested:
            raise Cancelled()

    def _cancellable(self, fn, *args, **kwargs):
        """Выполняет блокирующий вызов в отдельном потоке, чтобы «Остановить» срабатывало сразу."""
        box = {}

        def _w():
            try:
                box["r"] = fn(*args, **kwargs)
            except BaseException as e:
                box["e"] = e

        t = threading.Thread(target=_w, daemon=True)
        t.start()
        while t.is_alive():
            t.join(0.2)
            self._check_cancel()
        if "e" in box:
            raise box["e"]
        return box.get("r")

    def _sleep_cancellable(self, sec: float):
        for _ in range(int(sec / 0.2)):
            self._check_cancel()
            time.sleep(0.2)

    def _begin_job(self, busy_text: str):
        self.is_running, self.cancel_requested = True, False
        self.start_btn.configure(state="disabled", text=busy_text)
        self.stop_btn.configure(state="normal", text="■  ОСТАНОВИТЬ")
        self.stop_btn.grid()

    def _end_job(self):
        """Вызывается из рабочего потока по завершении задачи."""
        self.is_running = False

        def _ui():
            self.start_btn.configure(state="normal", text="ЗАПУСТИТЬ НАРЕЗКУ КЛИПОВ")
            self.stop_btn.grid_remove()
        self.after(0, _ui)

    def _confirm_abort(self, closing: bool) -> bool:
        if closing:
            return ask_yes_no(self, "Процесс в работе",
                              "Сейчас идёт обработка или рендер видео!\n\nЗакрытие программы остановит текущий процесс, "
                              "и весь прогресс будет утерян.\n\nВы действительно хотите закрыть программу?")
        return ask_yes_no(self, "Остановить процесс?",
                          "Сейчас идёт обработка или рендер видео!\n\nПри отмене весь текущий прогресс будет утерян "
                          "(незавершённый клип не сохранится).\n\nВы действительно хотите остановить процесс?")

    def _on_stop_request(self):
        if not self.is_running or self.cancel_requested:
            return
        if self._confirm_abort(closing=False) and self.is_running:
            self.cancel_requested = True
            self.stop_btn.configure(state="disabled", text="Остановка...")
            self._terminate_active_subprocesses()
            self.log("[!] Остановка процесса по запросу пользователя...")

    def _on_close_window_request(self):
        if self.is_running:
            if not self._confirm_abort(closing=True):
                return
            self.cancel_requested = True
            self._terminate_active_subprocesses()
        self.save_config()
        self.destroy()
        os._exit(0)

    def _enable_russian_clipboard(self):
        events = {86: "<<Paste>>", 67: "<<Copy>>", 88: "<<Cut>>", 65: "<<SelectAll>>"}

        def _on_key(event):
            if event.state & 0x4 and event.keycode in events:
                event.widget.event_generate(events[event.keycode])
                return "break"
        self.bind_all("<Key>", _on_key, "+")

    # --- КОНФИГ И ДАННЫЕ ---
    def load_config(self):
        d = read_json(CONFIG_FILE, None)
        if not isinstance(d, dict):
            return dict(DEFAULT_CONFIG)
        if d.get("sub_size") == 46:
            d["sub_size"] = 70
        return {**DEFAULT_CONFIG, **d}

    def save_config(self):
        with suppress(Exception):
            self.config_data.update({
                "api_key": self.api_key_entry.get().strip(), "base_url": self.base_url_entry.get().strip(),
                "model": self.model_combo.get().strip(), "whisper_size": self.whisper_combo.get(),
                "max_clips": self.clips_count_entry.get().strip(), "boost_audio": self.boost_audio_var.get(),
                "face_track": self.face_track_var.get(), "subtitles": self.subtitles_var.get(),
                "sub_advanced": self.sub_advanced_var.get(), "sub_font": self.sub_font_combo.get(),
                "sub_size": int(round(self.sub_size_slider.get())), "sub_bg": self.sub_bg_var.get(),
                "sub_word_by_word": self.sub_wbw_var.get(), "sub_mirror": self.sub_mirror_var.get(),
                "sub_female_colors": self.sub_female_var.get(), "min_clip_sec": int(round(self.min_clip_slider.get())),
                "last_tokens_balance": self.tokens_balance_var.get(),
            })
        write_json(CONFIG_FILE, self.config_data)

    # --- ХРАНИЛИЩЕ КЛИПОВ (локально / Google Drive) ---
    def local_root(self) -> Path:
        return Path(self.config_data.get("local_dir") or Path.home() / "Desktop")

    def cloud_mode(self) -> bool:
        return self.config_data.get("storage_mode") == "cloud" and self.drive.connected

    def set_storage_mode(self, mode: str):
        mode = "cloud" if mode == "cloud" and self.drive.connected else "local"
        if self.config_data.get("storage_mode") != mode:
            self.config_data["storage_mode"] = mode
            self.log("[*] Хранилище клипов: " + (f"Google Drive (/{self.config_data.get('gdrive_folder', 'Клипы')})"
                                                  if mode == "cloud" else f"локально ({self.local_root()})"))
        self.save_config()

    def _output_roots(self) -> list:
        roots = []
        for r in (Path.home() / "Desktop", self.local_root(), CLOUD_CACHE_DIR):
            with suppress(Exception):
                if r.exists() and r.resolve() not in [x.resolve() for x in roots]:
                    roots.append(r)
        return roots

    def _drive_owns(self, clip: dict) -> bool:
        """Копия клипа на Drive принадлежит подключённому сейчас аккаунту (иначе её не изменить)."""
        g = clip.get("gdrive") or {}
        return bool(g.get("id")) and self.drive.connected and g.get("account", "") in ("", self.drive.user.get("email", ""))

    def _drive_upload_clip(self, clip: dict, replace=False, progress=None, cancelled=None) -> bool:
        """Сохраняет клип на Google Drive. replace=True — обновить уже загруженный файл (после перерендера)."""
        path = Path(clip["file_path"])
        old = clip.get("gdrive") or {}
        folder = old.get("folder") if replace and old else self.config_data.get("gdrive_folder", "Клипы")
        try:
            try:
                res = self.drive.upload(path, path.name, folder, old.get("id") if replace and self._drive_owns(clip) else None,
                                        progress, cancelled)
            except DriveError as e:
                if not (replace and e.status == 404):
                    raise
                res = self.drive.upload(path, path.name, folder, None, progress, cancelled)  # файл удалён с Drive — заново
            clip["gdrive"] = {"id": res["id"], "link": res["link"], "folder": folder, "account": self.drive.user.get("email", "")}
            self._save_gallery_db()
            return True
        except Cancelled:
            raise
        except Exception as e:
            self.log(f"[-] Google Drive: не удалось сохранить «{clip['title']}» ({e}). Клип сохранён на ПК.")
            return False

    def _drive_upload_from_menu(self, clip: dict):
        if not self._require_file(clip):
            return
        self.log(f"[*] Сохранение «{clip['title']}» на Google Drive...")

        def _w():
            if self._drive_upload_clip(clip):
                self.log(f"[+] «{clip['title']}» сохранён на Google Drive: /{clip['gdrive']['folder']}")
        run_bg(_w)

    def _drive_trash_clips(self, items: list):
        """«Удалить полностью»: копии на Google Drive — в корзину Drive (в фоне)."""
        cloud = [c for c in items if (c.get("gdrive") or {}).get("id")]
        if not cloud:
            return
        foreign = [c for c in cloud if not self._drive_owns(c)]
        if foreign:
            why = "Google Drive не подключён" if not self.drive.connected else "клипы сохранены другим аккаунтом Google"
            self.log(f"[!] Не удалось удалить с Google Drive {len(foreign)} шт.: {why}. Удалите их вручную на drive.google.com.")
            messagebox.showwarning("Google Drive", f"Клипы удалены с ПК, но {len(foreign)} шт. не удалось удалить с Google Drive: "
                                                   f"{why}.\n\nУдалите их вручную на drive.google.com.", parent=self)
        own = [c for c in cloud if c not in foreign]

        def _w():
            ok = 0
            for c in own:
                try:
                    self.drive.trash(c["gdrive"]["id"])
                    ok += 1
                except Exception as e:
                    self.log(f"[-] Google Drive: не удалось удалить «{c['title']}»: {e}")
            if own:
                self.log(f"[*] Удалено с Google Drive (перемещено в корзину Drive): {ok} из {len(own)} шт.")
        run_bg(_w)

    def _save_hidden_clips(self):
        write_json(HIDDEN_CLIPS_FILE, list(self.hidden_clip_paths))

    def _save_gallery_db(self):
        write_json(GALLERY_DB_FILE, [{k: v for k, v in c.items() if k != "thumb_pil"} for c in self.created_clips])

    @staticmethod
    def _clip_from_file(mp4: Path) -> dict:
        stem = strip_num_prefix(mp4.stem)
        return {
            "title": stem, "yt_title": f"{stem} #Shorts", "yt_description": "#Shorts #рек #тренды",
            "file_path": str(mp4), "source_video": str(mp4), "start": 0.0, "end": get_video_duration_sec(mp4),
            "subs": [], "speakers_count": 1,
            "speaker_styles": {"0": {"color": DEFAULT_SPEAKER_HEX[0], "mode": "text", "is_female": False}},
            "font_name": "Arial", "font_size": 70, "default_bg": False, "word_by_word": False, "mirror": False,
            "female_colors": False, "num_tracks": 1, "boost_audio": True, "vertical": True, "use_tracker": True,
        }

    def _load_existing_clips_async(self):
        """Фоновая загрузка галереи и миниатюр — окно открывается мгновенно."""
        def _bg():
            loaded, known = [], set()

            def _accept(fp: Path) -> bool:
                r = str(fp.resolve())
                if r in self.hidden_clip_paths or r in known:
                    return False
                known.add(r)
                return True

            saved = read_json(GALLERY_DB_FILE, [])
            for item in saved if isinstance(saved, list) else []:
                with suppress(Exception):
                    fp = Path(item.get("file_path", ""))
                    if fp.exists() and _accept(fp):
                        item["title"] = strip_num_prefix(item.get("title", fp.stem))
                        loaded.append(item)

            mtime = lambda p: p.stat().st_mtime if p.exists() else 0
            out_dirs = (d for root in self._output_roots() for d in root.glob("Clips_Output_*") if d.is_dir())
            for odir in sorted(out_dirs, key=mtime, reverse=True):
                for mp4 in sorted(odir.glob("*.mp4"), key=mtime, reverse=True):
                    if mp4.name != "source_video.mp4" and not mp4.name.startswith(".tmp_") and _accept(mp4):
                        loaded.append(self._clip_from_file(mp4))
            for item in loaded:
                item["thumb_pil"] = get_cached_thumbnail(Path(item["file_path"]))

            if loaded:
                def _apply():
                    self.created_clips = loaded
                    self._save_gallery_db()
                    self._show_clips_section_after_job()
                    self.log(f"[*] Галерея загружена в фоне: готовых клипов — {len(loaded)} шт.")
                self.after(0, _apply)
        run_bg(_bg)

    # --- МЕНЕДЖЕР АККАУНТОВ (YOUTUBE + TIKTOK) ---
    def _load_yt_accounts(self) -> dict:
        YT_PROFILES_ROOT.mkdir(parents=True, exist_ok=True)
        d = read_json(YT_ACCOUNTS_FILE, None)
        if isinstance(d, dict) and isinstance(d.get("accounts"), list):
            for a in d["accounts"]:
                a.setdefault("platform", "youtube")
            return d
        return {"accounts": [], "active_id": None}

    def _save_yt_accounts(self):
        write_json(YT_ACCOUNTS_FILE, self.yt_state)

    def _get_active_account(self):
        accs = self.yt_state.get("accounts", [])
        if not accs:
            return None
        found = next((a for a in accs if a.get("id") == self.yt_state.get("active_id")), None)
        if found is None:
            self.yt_state["active_id"] = accs[0]["id"]
        return found or accs[0]

    @staticmethod
    def _plat_title(platform) -> str:
        return "TikTok" if platform == "tiktok" else "YouTube"

    def _avatar(self, path, platform, size):
        img = ctk_image(make_avatar_with_platform_badge(path, platform, size=size), (size, size))
        self._yt_avatar_refs.append(img)
        return img

    def _close_account_popups(self):
        for attr in ("yt_menu_popup", "platform_picker_popup"):
            pop = getattr(self, attr, None)
            if pop is not None and pop.winfo_exists():
                pop.destroy()
            setattr(self, attr, None)

    def _new_popup(self, attr: str):
        pop = ctk.CTkToplevel(self)
        pop.wm_overrideredirect(True)
        pop.attributes("-topmost", True)
        pop.configure(fg_color=MD3["bg"])
        setattr(self, attr, pop)
        outer = ctk.CTkFrame(pop, fg_color=MD3["surface_high"], corner_radius=12, border_width=1, border_color=MD3["outline"])
        outer.pack(fill="both", expand=True, padx=2, pady=2)
        return pop, outer

    def _show_popup_under(self, pop, anchor):
        pop.update_idletasks()
        pw, ph = pop.winfo_reqwidth(), pop.winfo_reqheight()
        x = max(10, anchor.winfo_rootx() + anchor.winfo_width() - pw)
        pop.geometry(f"{pw}x{ph}+{x}+{anchor.winfo_rooty() + anchor.winfo_height() + 4}")
        pop.bind("<FocusOut>", lambda _e: self.after(150, self._close_account_popups))
        pop.focus_set()

    def _render_account_top_right(self):
        self._close_account_popups()
        for w in self.yt_container.winfo_children():
            w.destroy()
        self._yt_avatar_refs.clear()
        acc = self._get_active_account()
        style = dict(corner_radius=16, font=F(12, True), height=34)
        if not acc:
            self.yt_prof_btn = button(self.yt_container, "👤  Менеджер аккаунтов  ▾",
                                      lambda: self._open_platform_choice_popup(self.yt_prof_btn), "surface", width=205, **style)
        else:
            self.yt_prof_btn = button(self.yt_container, f"  {acc.get('name', 'Аккаунт')}  ▾", self._toggle_accounts_dropdown,
                                      "surface", image=self._avatar(acc.get("avatar_path", ""), acc.get("platform", "youtube"), 28),
                                      compound="left", **style)
        self.yt_prof_btn.pack(side="top", anchor="e")

    def _open_platform_choice_popup(self, anchor):
        self._close_account_popups()
        pop, outer = self._new_popup("platform_picker_popup")
        label(outer, "Выберите платформу:", F(11, True), "on_surface_var", anchor="w").pack(fill="x", padx=12, pady=(8, 4))
        for plat, pady in (("youtube", (2, 2)), ("tiktok", (2, 8))):
            button(outer, f"  {self._plat_title(plat)}", lambda p=plat: self._start_platform_login(p), "ghost",
                   image=self._avatar("", plat, 22), compound="left", anchor="w", corner_radius=8, font=F(12, True),
                   height=34, width=195).pack(fill="x", padx=8, pady=pady)
        self._show_popup_under(pop, anchor)

    def _toggle_accounts_dropdown(self):
        if self.yt_menu_popup is not None and self.yt_menu_popup.winfo_exists():
            self._close_account_popups()
            return
        acc = self._get_active_account()
        if not acc:
            return
        others = [a for a in self.yt_state.get("accounts", []) if a.get("id") != acc.get("id")]
        pop, outer = self._new_popup("yt_menu_popup")
        bw = max(255, self.yt_prof_btn.winfo_width())

        button(outer, "➕  Добавить новый аккаунт", lambda: self._open_platform_choice_popup(self.yt_prof_btn), anchor="w",
               corner_radius=8, font=F(12, True), height=34, width=bw - 16).pack(fill="x", padx=8, pady=(8, 4))
        if others:
            label(outer, "Переключить аккаунт:", F(11), "on_surface_var", anchor="w").pack(fill="x", padx=12, pady=(4, 2))
            lst = (ctk.CTkScrollableFrame(outer, width=bw - 24, height=5 * 38, fg_color=MD3["surface"], corner_radius=8)
                   if len(others) > 5 else ctk.CTkFrame(outer, fg_color=MD3["surface"], corner_radius=8))
            lst.pack(fill="x", padx=8, pady=4)
            for a in others:
                button(lst, f"  {a.get('name', 'Аккаунт')}", lambda aid=a["id"]: self._switch_account(aid), "ghost",
                       image=self._avatar(a.get("avatar_path", ""), a.get("platform", "youtube"), 24), compound="left",
                       anchor="w", corner_radius=6, font=F(12), height=34).pack(fill="x", padx=4, pady=2)
        button(outer, "Выйти", self._logout_current_account, "danger", corner_radius=8, font=F(12, True), height=32,
               width=bw - 16).pack(fill="x", padx=8, pady=(6, 8))
        self._show_popup_under(pop, self.yt_prof_btn)

    def _switch_account(self, account_id: str):
        self._close_account_popups()
        self.yt_state["active_id"] = account_id
        self._save_yt_accounts()
        acc = self._get_active_account()
        self._render_account_top_right()
        if acc:
            self.log(f"[*] Рабочий аккаунт переключен на: {acc.get('name')} ({self._plat_title(acc.get('platform'))})")

    def _logout_current_account(self):
        self._close_account_popups()
        acc = self._get_active_account()
        if not acc:
            return
        remaining = [a for a in self.yt_state.get("accounts", []) if a.get("id") != acc.get("id")]
        self.yt_state.update(accounts=remaining, active_id=remaining[0]["id"] if remaining else None)
        self._save_yt_accounts()
        if acc.get("profile_dir"):
            shutil.rmtree(acc["profile_dir"], ignore_errors=True)
        self._render_account_top_right()
        self.log(f"[*] Вы вышли из аккаунта «{acc.get('name', 'Аккаунт')}».")

    def _start_platform_login(self, platform: str):
        self._close_account_popups()
        self.log(f"[*] Открытие окна браузера для авторизации в {self._plat_title(platform)}...")
        run_bg(self._platform_login_worker, platform)

    @staticmethod
    def _login_youtube(page, ctx):
        page.goto("https://accounts.google.com/ServiceLogin?service=youtube&continue=https://www.youtube.com/")
        for _ in range(360):
            if page.is_closed():
                break
            url = page.url
            if "youtube.com" in url and "accounts.google.com" not in url:
                with suppress(Exception):
                    av_btn = page.locator("button#avatar-btn, ytd-topbar-menu-button-renderer button#avatar-btn").first
                    if av_btn.count() > 0:
                        img = av_btn.locator("img").first
                        avatar = img.get_attribute("src") if img.count() > 0 else None
                        av_btn.click()
                        page.wait_for_timeout(1200)
                        name_loc = page.locator("yt-formatted-string#account-name, #channel-title").first
                        name = name_loc.inner_text().strip() if name_loc.count() > 0 else None
                        if name:
                            return name, avatar
            page.wait_for_timeout(1000)
        return None, None

    @staticmethod
    def _login_tiktok(page, ctx):
        page.goto("https://www.tiktok.com/login")
        for _ in range(360):
            if page.is_closed():
                break
            with suppress(Exception):
                logged = any(c.get("name") in ("sessionid", "sid_tt", "uid_tt") and c.get("value") for c in ctx.cookies())
                if logged and "/login" not in page.url:
                    page.wait_for_timeout(1800)
                    av = page.locator("[data-e2e='profile-icon'] img, header img[alt*='avatar'], header img").first
                    avatar = av.get_attribute("src") if av.count() > 0 else None
                    page.goto("https://www.tiktok.com/tiktokstudio/upload", wait_until="domcontentloaded", timeout=15000)
                    page.wait_for_timeout(2000)
                    nl = page.locator("[data-e2e='user-title'], [data-e2e='user-subtitle'], header span").first
                    name = nl.inner_text().strip() if nl.count() > 0 else ""
                    return name or "TikTok Аккаунт", avatar
            page.wait_for_timeout(1000)
        return None, None

    def _platform_login_worker(self, platform: str):
        acc_id = f"{platform}_{int(time.time())}_{uuid.uuid4().hex[:6]}"
        prof_dir = YT_PROFILES_ROOT / acc_id
        prof_dir.mkdir(parents=True, exist_ok=True)
        try:
            from playwright.sync_api import sync_playwright
            with sync_playwright() as p:
                ctx = launch_browser_context(p, str(prof_dir), headless=False, width=540, height=700)
                page = ctx.pages[0] if ctx.pages else ctx.new_page()
                name, avatar_url = (self._login_tiktok if platform == "tiktok" else self._login_youtube)(page, ctx)
                ctx.close()
            if not name:
                shutil.rmtree(prof_dir, ignore_errors=True)
                self.log("[!] Окно авторизации закрыто без завершения входа.")
                return
            av_local = prof_dir / "avatar.png"
            if avatar_url and avatar_url.startswith("http"):
                with suppress(Exception):
                    import requests
                    r = requests.get(avatar_url, timeout=8)
                    if r.status_code == 200:
                        Image.open(BytesIO(r.content)).convert("RGBA").save(av_local)
            self.yt_state.setdefault("accounts", []).append({
                "id": acc_id, "platform": platform, "name": name,
                "avatar_path": str(av_local) if av_local.exists() else "", "profile_dir": str(prof_dir),
            })
            self.yt_state["active_id"] = acc_id
            self._save_yt_accounts()
            self.log(f"[+] Аккаунт {self._plat_title(platform)} «{name}» успешно добавлен и выбран активным!")
            self.after(0, self._render_account_top_right)
        except Exception as e:
            shutil.rmtree(prof_dir, ignore_errors=True)
            self.log(f"[-] Ошибка окна авторизации: {e}")

    # --- ЗАГРУЗКА КЛИПОВ НА ПЛАТФОРМЫ ---
    @staticmethod
    def _fill_youtube(page, title, desc):
        boxes = page.locator("ytcp-social-suggestions-textbox #textbox, #textbox[contenteditable='true']")
        boxes.first.wait_for(state="visible", timeout=15000)
        for i, text, limit in ((0, title, 100), (1, desc, 4900)):
            if i == 1 and (not desc or boxes.count() < 2):
                break
            if i:
                page.wait_for_timeout(400)
            boxes.nth(i).click()
            page.keyboard.press("Control+A")
            page.keyboard.insert_text(text[:limit])

    @staticmethod
    def _fill_tiktok(page, caption):
        box = page.locator("div[contenteditable='true'], .public-DraftEditor-content").first
        box.wait_for(state="visible", timeout=15000)
        box.click()
        page.keyboard.press("Control+A")
        page.keyboard.press("Backspace")
        page.keyboard.insert_text(caption[:2100])

    def _wait_upload_done(self, page, tiktok: bool):
        dialog_seen = False
        while not page.is_closed():
            with suppress(Exception):
                if tiktok:
                    done = page.locator("div:has-text('Ваше видео загружается'), div:has-text('Видео опубликовано'), "
                                        "div:has-text('Your video is being uploaded'), div:has-text('Manage your posts')")
                    if "/tiktokstudio/content" in page.url or (done.count() > 0 and done.first.is_visible()):
                        self.log("[+] Видео успешно отправлено в TikTok! Закрываем окно браузера...")
                        page.wait_for_timeout(2500)
                        return
                else:
                    dlg_count = page.locator("ytcp-uploads-dialog").count()
                    dialog_seen = dialog_seen or dlg_count > 0
                    share = page.locator("ytcp-video-share-dialog, ytcp-uploads-still-processing-dialog, "
                                         "tp-yt-paper-dialog:has-text('Видео опубликовано'), "
                                         "tp-yt-paper-dialog:has-text('Video published')")
                    if share.count() > 0 and share.first.is_visible():
                        self.log("[+] Видео опубликовано на YouTube! Закрываем окно браузера...")
                        page.wait_for_timeout(2200)
                        return
                    if dialog_seen and dlg_count == 0:
                        self.log("[+] Загрузка на YouTube завершена! Закрываем окно браузера...")
                        page.wait_for_timeout(1500)
                        return
            page.wait_for_timeout(1000)

    def _upload_clip_to_active_platform(self, clip: dict):
        acc = self._get_active_account()
        if not acc:
            messagebox.showwarning("Нет авторизации", "Сначала войдите в аккаунт через «Менеджер аккаунтов» в правом верхнем углу.")
            return
        fpath = self._require_file(clip, resolve=True)
        if not fpath:
            return
        tiktok = acc.get("platform", "youtube") == "tiktok"
        plat = self._plat_title(acc.get("platform"))
        name = acc.get("name", plat)
        if tiktok:
            title = strip_num_prefix(clip.get("title", ""))
            caption = f"{title}\n{clip.get('yt_description', '#fyp #рек #тренды').strip()}".strip()
            self.log(f"[*] Загрузка клипа «{title}» в TikTok («{name}»)...")
            url, size, timeout, settle = "https://www.tiktok.com/tiktokstudio/upload", (920, 780), 35000, 4000
            fill = lambda pg: self._fill_tiktok(pg, caption)
            ok_msg = f"[+] Видео, название, описание и хэштеги автоматически подставлены в TikTok Studio («{name}»)!"
        else:
            title = with_shorts(clip.get("yt_title") or strip_num_prefix(clip.get("title", "Shorts")) + " #Shorts")
            desc = clip.get("yt_description", "").strip()
            self.log(f"[*] Загрузка клипа «{title}» на YouTube-канал «{name}»...")
            url, size, timeout, settle = "https://www.youtube.com/upload", (880, 760), 30000, 3500
            fill = lambda pg: self._fill_youtube(pg, title, desc)
            ok_msg = f"[+] Видео, название и описание с хэштегами подставлены в YouTube Studio для «{name}»!"

        def _worker():
            try:
                from playwright.sync_api import sync_playwright
                with sync_playwright() as p:
                    ctx = launch_browser_context(p, str(acc["profile_dir"]), False, *size)
                    page = ctx.pages[0] if ctx.pages else ctx.new_page()
                    page.goto(url)
                    fi = page.locator("input[type='file']").first
                    fi.wait_for(state="attached", timeout=timeout)
                    fi.set_input_files(str(fpath))
                    page.wait_for_timeout(settle)
                    with suppress(Exception):
                        fill(page)
                    self.log(ok_msg)
                    self._wait_upload_done(page, tiktok)
                    ctx.close()
            except Exception as e:
                self.log(f"[-] Ошибка загрузчика {plat}: {e}")
        run_bg(_worker)

    # --- ПОСТРОЕНИЕ ИНТЕРФЕЙСА ---
    def _build_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(5, weight=1)
        cfg = self.config_data
        pill = dict(height=28, corner_radius=14)
        section = lambda parent, text: label(parent, text, F(15, True), "primary")

        # 1. Подключение нейросети
        api = card(self)
        api.grid(row=0, column=0, padx=16, pady=(10, 4), sticky="ew")
        api.grid_columnconfigure(1, weight=1)
        api_head = ctk.CTkFrame(api, fg_color="transparent")
        api_head.grid(row=0, column=0, columnspan=2, padx=14, pady=(8, 4), sticky="w")
        self.update_btn = button(api_head, "", self.updates_overlay.open, "ghost", width=32, height=32, corner_radius=16,
                                 image=ctk_image(make_download_icon(44), (22, 22)), hover_color=MD3["secondary_container"])
        self.api_title = section(api_head, "1. Подключение нейросети")
        self.api_title.pack(side="left")
        self.yt_container = ctk.CTkFrame(api, fg_color="transparent")
        self.yt_container.grid(row=0, column=1, columnspan=4, padx=14, pady=(10, 4), sticky="ne")
        self._render_account_top_right()

        label(api, "API Ключ:").grid(row=1, column=0, padx=14, pady=3, sticky="w")
        self.api_key_entry = entry(api, placeholder_text="Вставьте ваш ключ sk-...")
        self.api_key_entry.grid(row=1, column=1, padx=8, pady=3, sticky="ew")
        self.api_key_entry.insert(0, cfg["api_key"])
        last_bal = str(cfg.get("last_tokens_balance", "—"))
        self.tokens_balance_var = tk.StringVar(value=last_bal if last_bal.startswith("Токены:") else f"Токены: {last_bal}")
        self.tokens_badge = button(api, self.tokens_balance_var.get(), lambda: self.refresh_token_balance_async(silent=False, allow_browser=True),
                                   "success", textvariable=self.tokens_balance_var, width=165, font=F(12, True), **pill)
        self.tokens_badge.grid(row=1, column=2, padx=4, pady=3)
        button(api, "Вставить", self._paste_key, width=82, **pill).grid(row=1, column=3, padx=4, pady=3)
        self.show_key_btn = button(api, "Скрыть", self._toggle_key, width=82, **pill)
        self.show_key_btn.grid(row=1, column=4, padx=(4, 14), pady=3)

        label(api, "Сервер (Base URL):").grid(row=2, column=0, padx=14, pady=3, sticky="w")
        self.base_url_entry = entry(api)
        self.base_url_entry.grid(row=2, column=1, columnspan=4, padx=(8, 14), pady=3, sticky="ew")
        self.base_url_entry.insert(0, cfg["base_url"])
        label(api, "Модель ИИ:").grid(row=3, column=0, padx=14, pady=(3, 8), sticky="w")
        self.model_combo = combo(api, TOKIFY_MODELS, cfg["model"], corner_radius=10)
        self.model_combo.grid(row=3, column=1, columnspan=2, padx=8, pady=(3, 8), sticky="ew")
        self.test_btn = button(api, "Проверить ключ", self.test_api, "primary", width=168, height=30, corner_radius=15,
                               font=F(12, True))
        self.test_btn.grid(row=3, column=3, columnspan=2, padx=(4, 14), pady=(3, 8), sticky="ew")

        # 2. Источник видео
        src = card(self)
        src.grid(row=1, column=0, padx=16, pady=4, sticky="ew")
        src.grid_columnconfigure(1, weight=1)
        section(src, "2. Источник видео").grid(row=0, column=0, columnspan=3, padx=14, pady=(8, 3), sticky="w")
        label(src, "Файл или ссылка:").grid(row=1, column=0, padx=14, pady=(3, 8), sticky="w")
        self.source_entry = entry(src, placeholder_text="Путь к локальному .mp4 или ссылка YouTube / Twitch")
        self.source_entry.grid(row=1, column=1, padx=8, pady=(3, 8), sticky="ew")
        button(src, "Выбрать файл...", self.pick_file, width=135, height=30, corner_radius=15,
               font=F(12, True)).grid(row=1, column=2, padx=14, pady=(3, 8))

        # 3. Параметры видео
        params = card(self)
        params.grid(row=2, column=0, padx=16, pady=4, sticky="ew")
        params.grid_columnconfigure(0, weight=1)
        section(params, "3. Параметры видео").grid(row=0, column=0, padx=14, pady=(8, 3), sticky="w")

        row1 = ctk.CTkFrame(params, fg_color="transparent")
        row1.grid(row=1, column=0, padx=14, pady=2, sticky="ew")
        label(row1, "Модель Whisper:").pack(side="left", padx=(0, 6))
        self.whisper_combo = combo(row1, ["tiny", "base", "small", "medium"], cfg["whisper_size"], 95, corner_radius=8)
        self.whisper_combo.pack(side="left", padx=(0, 14))
        label(row1, "Макс. клипов:").pack(side="left", padx=(0, 6))
        self.clips_count_entry = entry(row1, width=52, corner_radius=8)
        self.clips_count_entry.insert(0, cfg["max_clips"])
        self.clips_count_entry.pack(side="left", padx=(0, 14))
        self.crop_var = ctk.BooleanVar(value=True)
        self.boost_audio_var = ctk.BooleanVar(value=cfg["boost_audio"])
        self.face_track_var = ctk.BooleanVar(value=cfg["face_track"])
        for text, var, font, padx in (("9:16 (Shorts)", self.crop_var, None, (0, 14)),
                                      ("Усиление звука", self.boost_audio_var, None, (0, 14)),
                                      ("Умный трекер", self.face_track_var, F(12, True), 0)):
            checkbox(row1, text, var, font=font).pack(side="left", padx=padx)
        button(row1, "Окно расшифровки текста ↗", self.open_transcript_window, width=190, **pill).pack(side="right")

        sub_row = ctk.CTkFrame(params, fg_color="transparent")
        sub_row.grid(row=2, column=0, padx=14, pady=(2, 4), sticky="ew")
        self.subtitles_var = ctk.BooleanVar(value=cfg["subtitles"])
        checkbox(sub_row, "Субтитры", self.subtitles_var, self._update_subtitles_visibility, F(12, True)).pack(side="left", padx=(0, 20))
        self.sub_advanced_var = ctk.BooleanVar(value=cfg["sub_advanced"])
        self.sub_advanced_cb = checkbox(sub_row, "Расширенные", self.sub_advanced_var, self._update_subtitles_visibility, F(12))

        self.sub_adv_panel = ctk.CTkFrame(params, fg_color=MD3["surface_high"], corner_radius=12)
        pk = dict(side="left", pady=6)
        label(self.sub_adv_panel, "Шрифт:").pack(padx=(10, 4), **pk)
        self.sub_font_combo = combo(self.sub_adv_panel, list(FONT_MAP), cfg["sub_font"], 115, fg_color=MD3["surface_container"])
        self.sub_font_combo.pack(padx=(0, 8), **pk)
        init_size = min(128, max(24, int(cfg["sub_size"])))
        self.sub_size_label = label(self.sub_adv_panel, f"Размер: {init_size} px", width=88)
        self.sub_size_label.pack(padx=(0, 4), **pk)
        self.sub_size_slider = slider(self.sub_adv_panel, 24, 128, init_size, 110,
                                      lambda v: self.sub_size_label.configure(text=f"Размер: {int(round(v))} px"))
        self.sub_size_slider.pack(padx=(0, 10), **pk)
        self.sub_bg_var = ctk.BooleanVar(value=cfg["sub_bg"])
        self.sub_wbw_var = ctk.BooleanVar(value=cfg["sub_word_by_word"])
        self.sub_mirror_var = ctk.BooleanVar(value=cfg["sub_mirror"])
        self.sub_female_var = ctk.BooleanVar(value=cfg["sub_female_colors"])
        self.sub_bg_cb = checkbox(self.sub_adv_panel, "Задний фон", self.sub_bg_var, self._on_bg_or_wbw_toggle)
        self.sub_wbw_cb = checkbox(self.sub_adv_panel, "Окраска по слову", self.sub_wbw_var, self._on_bg_or_wbw_toggle)
        for cb in (self.sub_bg_cb, self.sub_wbw_cb, checkbox(self.sub_adv_panel, "Отзеркалить", self.sub_mirror_var),
                   checkbox(self.sub_adv_panel, "Женские персонажи", self.sub_female_var)):
            cb.pack(padx=(0, 10), **pk)
        self._on_bg_or_wbw_toggle()
        self._update_subtitles_visibility()

        time_row = ctk.CTkFrame(params, fg_color="transparent")
        time_row.grid(row=4, column=0, padx=12, pady=(0, 6), sticky="ew")
        init_min = max(5, min(60, int(cfg["min_clip_sec"])))
        self.clip_time_toggle_btn = button(time_row, f"▶ Время клипа (минимум: {init_min} сек)", self._toggle_clip_time_section,
                                           "surface", border_width=0, text_color=MD3["primary"], anchor="w", width=260,
                                           height=26, corner_radius=13, font=F(12, True))
        self.clip_time_toggle_btn.pack(side="left", padx=2)
        self.clip_time_panel = ctk.CTkFrame(params, fg_color=MD3["surface_high"], corner_radius=12)
        label(self.clip_time_panel, "Минимальное время клипа (от 5 до 60 сек):", F(12, True)).pack(side="left", padx=(12, 10), pady=6)
        self.min_clip_slider = slider(self.clip_time_panel, 5, 60, init_min, 260, self._on_min_clip_sec_change)
        self.min_clip_slider.pack(side="left", padx=(0, 12), pady=6)
        self.min_clip_val_label = label(self.clip_time_panel, "", F(12), "primary")
        self.min_clip_val_label.pack(side="left", padx=(0, 12), pady=6)
        self._on_min_clip_sec_change(init_min)

        # Прогресс
        prog = card(self)
        prog.grid(row=3, column=0, padx=16, pady=3, sticky="ew")
        prog.grid_columnconfigure(0, weight=1)
        self.status_label = label(prog, "Ожидание запуска... (0%)", F(13, True), anchor="w")
        self.status_label.grid(row=0, column=0, padx=14, pady=(5, 2), sticky="ew")
        self.progress_bar = ctk.CTkProgressBar(prog, height=12, corner_radius=6, fg_color=MD3["surface_high"],
                                               progress_color=MD3["primary"])
        self.progress_bar.grid(row=1, column=0, padx=14, pady=(0, 6), sticky="ew")
        self.progress_bar.set(0.0)

        # Кнопки запуска / остановки
        ctrl = ctk.CTkFrame(self, fg_color="transparent")
        ctrl.grid(row=4, column=0, padx=16, pady=3, sticky="ew")
        ctrl.grid_columnconfigure(0, weight=1)
        big = dict(height=42, corner_radius=21, font=F(15, True))
        self.start_btn = button(ctrl, "ЗАПУСТИТЬ НАРЕЗКУ КЛИПОВ", self.start_pipeline, "primary", **big)
        self.start_btn.grid(row=0, column=0, sticky="ew")
        self.stop_btn = button(ctrl, "■  ОСТАНОВИТЬ", self._on_stop_request, "danger", width=210, **big)
        self.stop_btn.grid(row=0, column=1, padx=(10, 0))
        self.stop_btn.grid_remove()

        # Галерея клипов
        self.clips_outer_frame = card(self)
        self.clips_outer_frame.grid_columnconfigure(0, weight=1)
        self.clips_outer_frame.grid_rowconfigure(1, weight=1)
        head = ctk.CTkFrame(self.clips_outer_frame, fg_color="transparent")
        head.grid(row=0, column=0, padx=14, pady=(6, 4), sticky="ew")
        head.grid_columnconfigure(0, weight=1)
        self.clips_title_lbl = label(head, "Готовые клипы (0)", F(14, True), "primary", anchor="w")
        self.clips_title_lbl.grid(row=0, column=0, sticky="w")
        self.clips_collapse_btn = button(head, "Свернуть ▲", self._toggle_clips_section_manual, width=115, height=26, corner_radius=13)
        self.clips_collapse_btn.grid(row=0, column=1, sticky="e")
        self.clips_scroll = ctk.CTkScrollableFrame(self.clips_outer_frame, height=235, fg_color=MD3["surface"], corner_radius=12)
        self.clips_scroll.grid(row=1, column=0, padx=10, pady=(0, 8), sticky="nsew")
        self._bind_lasso_events(self.clips_scroll)
        if hasattr(self.clips_scroll, "_parent_canvas"):
            self._bind_lasso_events(self.clips_scroll._parent_canvas)

        # Журнал
        logs = card(self)
        logs.grid(row=6, column=0, padx=16, pady=(2, 4), sticky="ew")
        footer = ctk.CTkFrame(self, fg_color="transparent")
        footer.grid(row=7, column=0, padx=16, pady=(0, 8), sticky="ew")
        button(footer, "⚙", self.settings.open, "surface", width=38, height=38, corner_radius=19,
               font=("Segoe UI Symbol", 18)).pack(side="left")
        logs.grid_columnconfigure(0, weight=1)
        lhead = ctk.CTkFrame(logs, fg_color="transparent")
        lhead.grid(row=0, column=0, padx=14, pady=(5, 3), sticky="ew")
        lhead.grid_columnconfigure(0, weight=1)
        label(lhead, "Журнал работы и расшифровка", F(13, True), "on_surface_var", anchor="w").grid(row=0, column=0, sticky="w")
        self.logs_collapse_btn = button(lhead, "Свернуть ▲", self._toggle_logs_section_manual, width=115, height=24, corner_radius=12)
        self.logs_collapse_btn.grid(row=0, column=1, sticky="e")
        self.tabs = ctk.CTkTabview(logs, height=115, fg_color=MD3["surface"], segmented_button_fg_color=MD3["surface_high"],
                                   segmented_button_selected_color=MD3["secondary_container"],
                                   segmented_button_selected_hover_color=MD3["surface_highest"],
                                   segmented_button_unselected_color=MD3["surface_high"], text_color=MD3["on_surface"],
                                   corner_radius=12)
        self.tabs.grid(row=1, column=0, padx=10, pady=(0, 8), sticky="ew")
        boxes = []
        for name in ("Журнал работы", "Расшифровка текста (Таймкоды)"):
            tab = self.tabs.add(name)
            tab.grid_columnconfigure(0, weight=1)
            tab.grid_rowconfigure(0, weight=1)
            tb = ctk.CTkTextbox(tab, font=("Consolas", 12), height=80, fg_color=MD3["surface"], text_color=MD3["on_surface"])
            tb.grid(row=0, column=0, sticky="nsew")
            boxes.append(tb)
        self.log_box, self.transcript_box = boxes

        self.log(f"Clips Studio v{APP_VERSION}. Список изменений — в окне обновления (значок слева вверху) и в настройках ⚙.")

    def _toggle_logs_section_manual(self):
        self.logs_user_collapsed = not self.logs_user_collapsed
        if self.logs_user_collapsed:
            self.tabs.grid_remove()
        else:
            self.tabs.grid(row=1, column=0, padx=10, pady=(0, 8), sticky="ew")
        self.logs_collapse_btn.configure(text="Развернуть ▼" if self.logs_user_collapsed else "Свернуть ▲")

    def _show_clips_section_after_job(self):
        if not self.clips_section_shown_once:
            self.clips_section_shown_once = True
            self.clips_outer_frame.grid(row=5, column=0, padx=16, pady=(2, 4), sticky="nsew")
        self._refresh_clips_list_ui()

    def _toggle_clips_section_manual(self):
        self.clips_user_collapsed = not self.clips_user_collapsed
        if self.clips_user_collapsed:
            self.clips_scroll.grid_remove()
        else:
            self.clips_scroll.grid(row=1, column=0, padx=10, pady=(0, 8), sticky="nsew")
        self.clips_collapse_btn.configure(text="Развернуть ▼" if self.clips_user_collapsed else "Свернуть ▲")

    # --- ВЫДЕЛЕНИЕ ЛАССО ---
    def _bind_lasso_events(self, widget, clip_path: str = None):
        widget.bind("<ButtonPress-1>", lambda e: self._on_gallery_lmb_press(e, clip_path), add="+")
        widget.bind("<B1-Motion>", self._on_gallery_lmb_drag, add="+")
        widget.bind("<ButtonRelease-1>", lambda e: self._on_gallery_lmb_release(e, clip_path), add="+")

    def _on_gallery_lmb_press(self, event, clip_path=None):
        self._lasso_start_root, self._lasso_moved = (event.x_root, event.y_root), False
        if clip_path is None and not event.state & 0x4:
            self.selected_clip_paths.clear()
            self._update_tiles_selection_visuals()

    def _on_gallery_lmb_drag(self, event):
        if self._lasso_start_root is None:
            return
        sx, sy = self._lasso_start_root
        cx, cy = event.x_root, event.y_root
        if abs(cx - sx) < 8 and abs(cy - sy) < 8 and not self._lasso_moved:
            return
        self._lasso_moved = True
        x1, x2, y1, y2 = min(sx, cx), max(sx, cx), min(sy, cy), max(sy, cy)
        if self._lasso_popup is None or not self._lasso_popup.winfo_exists():
            pop = tk.Toplevel(self)
            pop.wm_overrideredirect(True)
            pop.attributes("-topmost", True)
            pop.attributes("-alpha", 0.28)
            pop.configure(bg=MD3["primary"], highlightbackground="#FFFFFF", highlightthickness=1)
            self._lasso_popup = pop
        self._lasso_popup.geometry(f"{max(2, x2 - x1)}x{max(2, y2 - y1)}+{x1}+{y1}")
        sel = set()
        for fp, tile in self.tile_widgets_map.items():
            if tile.winfo_exists():
                tx1, ty1 = tile.winfo_rootx(), tile.winfo_rooty()
                if not (tx1 + tile.winfo_width() < x1 or tx1 > x2 or ty1 + tile.winfo_height() < y1 or ty1 > y2):
                    sel.add(fp)
        if sel != self.selected_clip_paths:
            self.selected_clip_paths = sel
            self._update_tiles_selection_visuals()

    def _on_gallery_lmb_release(self, event, clip_path=None):
        if self._lasso_popup is not None and self._lasso_popup.winfo_exists():
            self._lasso_popup.destroy()
        self._lasso_popup = None
        if not self._lasso_moved and clip_path is not None:
            if event.state & 0x4:
                self.selected_clip_paths ^= {clip_path}
            else:
                self.selected_clip_paths = {clip_path}
            self._update_tiles_selection_visuals()
        self._lasso_start_root, self._lasso_moved = None, False

    def _tile_style(self, tile, path, hover=False):
        if path in self.selected_clip_paths:
            tile.configure(fg_color=MD3["selected_card"], border_color=MD3["selected_border"], border_width=2)
        elif hover:
            tile.configure(fg_color=MD3["surface_highest"], border_color=MD3["primary"])
        else:
            tile.configure(fg_color=MD3["surface_high"], border_color=MD3["outline"], border_width=1)

    def _update_tiles_selection_visuals(self):
        for fp, tile in self.tile_widgets_map.items():
            if tile.winfo_exists():
                self._tile_style(tile, fp)
        n = len(self.selected_clip_paths)
        self.clips_title_lbl.configure(text=f"Готовые клипы ({len(self.created_clips)}){f' · Выделено: {n}' if n else ''}"
                                            " — зажмите ЛКМ для выделения нескольких, ПКМ для меню")

    # --- ПАРАМЕТРЫ ---
    def _on_bg_or_wbw_toggle(self):
        if self.sub_wbw_var.get():
            self.sub_bg_var.set(False)
        elif self.sub_bg_var.get():
            self.sub_wbw_var.set(False)
        self.sub_bg_cb.configure(state="disabled" if self.sub_wbw_var.get() else "normal")
        self.sub_wbw_cb.configure(state="disabled" if self.sub_bg_var.get() else "normal")

    def _update_subtitles_visibility(self):
        if not self.subtitles_var.get():
            self.sub_advanced_var.set(False)
            self.sub_advanced_cb.pack_forget()
        else:
            self.sub_advanced_cb.pack(side="left", padx=(0, 10))
        if self.subtitles_var.get() and self.sub_advanced_var.get():
            self.sub_adv_panel.grid(row=3, column=0, padx=14, pady=(0, 6), sticky="ew")
        else:
            self.sub_adv_panel.grid_remove()

    def _toggle_clip_time_section(self):
        self.clip_time_expanded = not self.clip_time_expanded
        self._on_min_clip_sec_change(self.min_clip_slider.get())
        if self.clip_time_expanded:
            self.clip_time_panel.grid(row=5, column=0, padx=14, pady=(0, 8), sticky="ew")
        else:
            self.clip_time_panel.grid_remove()

    def _on_min_clip_sec_change(self, val):
        sec = int(round(val))
        self.clip_time_toggle_btn.configure(text=f"{'▼' if self.clip_time_expanded else '▶'} Время клипа (минимум: {sec} сек)")
        self.min_clip_val_label.configure(text=f"{sec} сек (клипы короче {sec} с не сохраняются)")

    # --- ОБНОВЛЕНИЯ ---
    def _auto_check_updates(self):
        u = self.updater
        if u.enabled and u.state in ("idle", "error") and not u.checking:
            run_bg(u.check)
        self.after(UPDATE_INTERVAL_MS, self._auto_check_updates)

    def _on_update_state(self):
        u = self.updater
        show = u.available
        if show != getattr(self, "_update_btn_shown", False):
            self._update_btn_shown = show
            if show:
                self.update_btn.pack(side="left", padx=(0, 8), before=self.api_title)
                self.log(f"[*] Доступна новая версия {u.new_version} — нажмите значок загрузки слева вверху.")
            else:
                self.update_btn.pack_forget()
        sig = (u.checking, u.last_check, u.available, u.new_version)
        if sig != getattr(self, "_update_sig", None):  # настройки — только при смене статуса, не на каждый % загрузки
            self._update_sig = sig
            if self.settings.is_open and not self.settings.editing_folder and not self.settings.login_busy:
                self.settings.render()
        self.updates_overlay.refresh()

    def install_update(self):
        if self.is_running:
            if not ask_yes_no(self, "Процесс в работе", "Сейчас идёт обработка или рендер видео!\n\nПерезапуск для обновления "
                                                        "остановит процесс, и текущий прогресс будет утерян.\n\nОбновить сейчас?"):
                return
            self.cancel_requested = True
            self._terminate_active_subprocesses()
        self.save_config()
        if self.updater.install():
            self.destroy()
            os._exit(0)

    # --- БАЛАНС ТОКЕНОВ ---
    def _startup_balance_check(self):
        if self.api_key_entry.get().strip():
            self.log("[*] Автопроверка лимитов ключа...")
            self.refresh_token_balance_async(silent=False, allow_browser=True)

    def refresh_token_balance_async(self, silent: bool = False, allow_browser: bool = True):
        api_key, base_url = self.api_key_entry.get().strip(), self.base_url_entry.get().strip()
        if not api_key:
            return
        self._balance_gen += 1
        gen = self._balance_gen
        if not silent:
            self.tokens_balance_var.set("Токены: проверка...")

        def _worker():
            txt = f"Токены: {TokifyBalanceChecker.fetch_remaining_tokens(api_key, base_url, allow_browser=allow_browser)}"

            def _apply():
                if gen != self._balance_gen:  # уже запущена более свежая проверка
                    return
                self.tokens_balance_var.set(txt)
                self.save_config()
                if not silent:
                    self.log(f"[*] Баланс ключа (https://tokify.sale/#dashboard): {txt}")
            self.after(0, _apply)
        run_bg(_worker)

    # --- СЕТКА ГАЛЕРЕИ ---
    def _calc_columns_count(self) -> int:
        return max(1, min(6, ((self.winfo_width() or 1160) - 60) // 230))

    def _on_window_resize(self, event):
        if event.widget is self:
            for ov in self.overlays:
                ov.on_resize()
        if event.widget is self and self.clips_section_shown_once and self.created_clips:
            if self._resize_after_id is not None:
                self.after_cancel(self._resize_after_id)
            self._resize_after_id = self.after(120, self._check_and_rearrange_grid)

    def _check_and_rearrange_grid(self):
        self._resize_after_id = None
        if self._calc_columns_count() != self._current_grid_cols:
            self._layout_tiles(self.clips_scroll.winfo_children())

    def _layout_tiles(self, tiles):
        cols = self._current_grid_cols = self._calc_columns_count()
        for c in range(6):
            self.clips_scroll.grid_columnconfigure(c, weight=1 if c < cols else 0)
        for i, tile in enumerate(tiles):
            tile.grid(row=i // cols, column=i % cols, padx=8, pady=8, sticky="n")

    def _periodic_folder_sync(self):
        with suppress(Exception):
            before = len(self.created_clips)
            self.created_clips = [c for c in self.created_clips if Path(c["file_path"]).exists()]
            if len(self.created_clips) != before:
                self._save_gallery_db()
                self._refresh_clips_list_ui()
        self.after(180000, self._periodic_folder_sync)

    # --- ПЕРЕИМЕНОВАНИЕ ---
    def _start_inline_rename(self, tile, clip: dict):
        ent = entry(tile, width=195, height=24, font=F(12, True), fg_color=MD3["surface_highest"],
                    border_color=MD3["primary"], corner_radius=6)
        ent.place(x=10, y=135)
        ent.insert(0, clip["title"])
        ent.select_range(0, tk.END)
        ent.focus_set()
        done = [False]

        def _finish(commit):
            if done[0]:
                return
            done[0] = True
            val = ent.get().strip()
            ent.destroy()
            if commit and val and val != clip["title"]:
                self._apply_clip_new_name(clip, val)
        ent.bind("<Return>", lambda _e: _finish(True))
        ent.bind("<FocusOut>", lambda _e: _finish(True))
        ent.bind("<Escape>", lambda _e: _finish(False))

    def _apply_clip_new_name(self, clip: dict, new_title: str):
        fpath = self._require_file(clip)
        if not fpath:
            return
        title = strip_num_prefix(safe_filename(new_title))
        if not title:
            return
        new_path = fpath.with_name(f"{title}{fpath.suffix}")
        try:
            if new_path != fpath:
                fpath.rename(new_path)
            if str(fpath) in self.selected_clip_paths:
                self.selected_clip_paths = (self.selected_clip_paths - {str(fpath)}) | {str(new_path)}
            clip.update(title=title, yt_title=with_shorts(title), file_path=str(new_path))
            self._save_gallery_db()
            self.log(f"[*] Клип переименован в: {new_path.name}")
            if self._drive_owns(clip):  # то же имя и на Google Drive
                fid = clip["gdrive"]["id"]

                def _w():
                    try:
                        self.drive.rename(fid, new_path.name)
                    except Exception as e:
                        self.log(f"[-] Google Drive: не удалось переименовать копию клипа: {e}")
                run_bg(_w)
            self._refresh_clips_list_ui()
        except Exception as e:
            messagebox.showerror("Ошибка переименования", f"Не удалось переименовать файл:\n{e}")

    def _rename_clip(self, clip: dict):
        val = ctk.CTkInputDialog(text=f"Введите новое название для клипа «{clip['title']}»:", title="Переименовать клип").get_input()
        if val and val.strip():
            self._apply_clip_new_name(clip, val.strip())

    # --- ПЛИТКИ ГАЛЕРЕИ ---
    def _refresh_clips_list_ui(self):
        self.created_clips = [c for c in self.created_clips if Path(c["file_path"]).exists()]
        self.selected_clip_paths &= {c["file_path"] for c in self.created_clips}
        for child in self.clips_scroll.winfo_children():
            child.destroy()
        self._thumb_refs.clear()
        self.tile_widgets_map.clear()
        tiles = [self._make_tile(c) for c in self.created_clips]
        self._layout_tiles(tiles)
        self._update_tiles_selection_visuals()

    def _make_tile(self, clip: dict):
        path = clip["file_path"]
        tile = ctk.CTkFrame(self.clips_scroll, corner_radius=14, width=215, height=195)
        tile.grid_propagate(False)
        self._tile_style(tile, path)
        self.tile_widgets_map[path] = tile

        if clip.get("thumb_pil") is None:
            clip["thumb_pil"] = get_cached_thumbnail(Path(path))
        thumb = ctk_image(clip["thumb_pil"], THUMB_SIZE)
        self._thumb_refs.append(thumb)
        img_lbl = ctk.CTkLabel(tile, text="", image=thumb, corner_radius=10)
        img_lbl.place(x=8, y=8)

        clip["title"] = strip_num_prefix(clip["title"])
        short = clip["title"] if len(clip["title"]) <= 24 else clip["title"][:22] + "…"
        title_lbl = label(tile, short, F(12, True), anchor="w", width=195, cursor="xterm")
        title_lbl.place(x=10, y=136)
        title_lbl.bind("<Button-1>", lambda _e: self._start_inline_rename(tile, clip))
        dur = max(1.0, float(clip["end"]) - float(clip["start"]))
        info = f"{dur:.1f} сек · Персонажей: {clip.get('speakers_count', 1)}{' · ⇄' if clip.get('mirror') else ''}"
        sub_lbl = label(tile, info, F(11), "on_surface_var", anchor="w", width=195)
        sub_lbl.place(x=10, y=160)
        dots = button(tile, "⋮", lambda: self._show_clip_context_menu(clip, tile), "ghost", width=28, height=26,
                      corner_radius=8, font=F(15, True), fg_color=MD3["surface_container"], hover_color=MD3["primary"])
        widgets = (tile, img_lbl, title_lbl, sub_lbl)

        def _enter(_e):
            self._tile_style(tile, path, hover=True)
            dots.place(x=174, y=12)

        def _leave(_e):
            under = tile.winfo_containing(*tile.winfo_pointerxy())
            if under not in widgets and under is not dots:
                self._tile_style(tile, path)
                dots.place_forget()

        for w in (tile, img_lbl, sub_lbl):
            self._bind_lasso_events(w, clip_path=path)
            w.bind("<Double-Button-1>", lambda _e: self._play_clip(clip))
        for w in widgets + (dots,):
            w.bind("<Enter>", _enter)
            w.bind("<Leave>", _leave)
            w.bind("<Button-3>", lambda e: self._build_context_menu(clip).tk_popup(e.x_root, e.y_root))
        return tile

    # --- КОНТЕКСТНОЕ МЕНЮ ---
    def _menu(self, parent=None, danger=False):
        return tk.Menu(parent or self, tearoff=0, bg=MD3["surface_high"], fg="#ff4d4d" if danger else MD3["on_surface"],
                       activebackground=MD3["error_container"] if danger else MD3["secondary_container"],
                       activeforeground="#ffffff" if danger else MD3["on_secondary"], font=("Segoe UI", 10), bd=1)

    def _add_delete_cascade(self, menu, items, text):
        sub = self._menu(menu, danger=True)
        on_drive = sum(1 for c in items if (c.get("gdrive") or {}).get("id"))
        if on_drive:  # пометка видна в любом режиме хранилища, даже после выхода из Google Drive
            sub.add_command(label="☁  Клип сохранён на Google Drive" if len(items) == 1 else
                            f"☁  На Google Drive: {on_drive} из {len(items)}", state="disabled")
            sub.add_separator()
        sub.add_command(label="Удалить из галереи", foreground="#ff4d4d", activeforeground="#ffffff",
                        command=lambda: self._batch_remove_from_gallery(items))
        sub.add_command(label="Удалить полностью (с ПК и Google Drive)" if on_drive else "Удалить полностью",
                        foreground="#ff4d4d", activeforeground="#ffffff", command=lambda: self._batch_delete_completely(items))
        menu.add_cascade(label=text, menu=sub, foreground="#ff4d4d", activeforeground="#ff6666")

    def _build_context_menu(self, clip: dict) -> tk.Menu:
        path = clip["file_path"]
        menu = self._menu()
        if path in self.selected_clip_paths and len(self.selected_clip_paths) > 1:
            items = [c for c in self.created_clips if c["file_path"] in self.selected_clip_paths]
            self._add_delete_cascade(menu, items, f"🗑  Удалить (выбрано: {len(items)})")
            return menu
        self.selected_clip_paths = {path}
        self._update_tiles_selection_visuals()
        menu.add_command(label="▶  Воспроизвести", command=lambda: self._play_clip(clip))
        acc = self._get_active_account()
        if acc is not None:
            target = "в TikTok" if acc.get("platform") == "tiktok" else "на YouTube"
            menu.add_command(label=f"📤  Загрузить {target}", command=lambda: self._upload_clip_to_active_platform(clip))
        menu.add_command(label="📂  Открыть в папке", command=lambda: self._open_clip_in_folder(clip))
        link = (clip.get("gdrive") or {}).get("link")
        if link:
            menu.add_command(label="☁  Открыть на Google Drive", command=lambda: __import__("webbrowser").open(link))
        elif self.drive.connected:
            menu.add_command(label="☁  Сохранить на Google Drive", command=lambda: self._drive_upload_from_menu(clip))
        menu.add_command(label="✏  Переименовать", command=lambda: self._rename_clip(clip))
        menu.add_command(label="🎬  Редактировать видео", command=lambda: self._edit_clip_video(clip))
        menu.add_separator()
        self._add_delete_cascade(menu, [clip], "🗑  Удалить")
        return menu

    def _show_clip_context_menu(self, clip: dict, anchor):
        self._build_context_menu(clip).tk_popup(anchor.winfo_rootx() + anchor.winfo_width() - 35, anchor.winfo_rooty() + 38)

    def _require_file(self, clip: dict, resolve=False):
        p = Path(clip["file_path"])
        p = p.resolve() if resolve else p
        if p.exists():
            return p
        messagebox.showwarning(*NOT_FOUND_MSG)
        self._refresh_clips_list_ui()
        return None

    def _play_clip(self, clip: dict):
        p = self._require_file(clip)
        if p:
            os.startfile(str(p))

    def _open_clip_in_folder(self, clip: dict):
        p = self._require_file(clip, resolve=True)
        if p:
            subprocess.Popen(["explorer.exe", f"/select,{p}"])

    def _edit_clip_video(self, clip: dict):
        if self._require_file(clip):
            VideoEditorWindow(self, clip)

    def _forget_clips(self, items):
        for c in items:
            if c in self.created_clips:
                self.created_clips.remove(c)
            self.selected_clip_paths.discard(c["file_path"])

    def _batch_remove_from_gallery(self, items: list):
        for c in items:
            with suppress(Exception):
                self.hidden_clip_paths.add(str(Path(c["file_path"]).resolve()))
        self._forget_clips(items)
        self._save_hidden_clips()
        self._save_gallery_db()
        self.log(f"[*] Удалено из галереи клипов: {len(items)} шт. (файлы в папке сохранены).")
        self._refresh_clips_list_ui()

    def _batch_delete_completely(self, items: list):
        self._forget_clips(items)
        deleted = 0
        for c in items:
            try:
                Path(c["file_path"]).unlink(missing_ok=True)
                deleted += 1
            except Exception as e:
                self.log(f"[!] Не удалось удалить файл {Path(c['file_path']).name}: {e}")
        self._save_gallery_db()
        self.log(f"[*] Полностью удалено клипов (из галереи и с диска): {deleted} шт.")
        self._refresh_clips_list_ui()
        self._drive_trash_clips(items)

    # --- ПЕРЕРЕНДЕР ОДНОГО КЛИПА ---
    def rerender_single_clip(self, clip: dict, on_done=None):
        if self.is_running:
            return
        self._begin_job("ИДЕТ ПЕРЕРЕНДЕР...")

        def _worker():
            ok = False
            try:
                out_file = Path(clip["file_path"])
                src = Path(clip["source_video"])
                src = src if src.exists() else out_file
                start_t = float(clip["start"])
                self.log(f"\n[*] Перерендер видео «{clip['title']}» с пользовательскими настройками...")
                self.set_progress(0.35, f"Перерендер видео: {clip['title']}...")
                renderer = SubtitleRenderer(
                    font_name=clip.get("font_name", "Arial"), font_size=int(clip.get("font_size", 70)),
                    bg_box=bool(clip.get("default_bg", False)), word_by_word=bool(clip.get("word_by_word", False)),
                    enable_female_colors=bool(clip.get("female_colors", False)), speaker_styles=clip.get("speaker_styles", {}))
                subs, sp_count, _ = self.speaker_tracker.render_clip(
                    video_path=src, start_t=start_t, duration=max(5.0, float(clip["end"]) - start_t), out_file=out_file,
                    num_tracks=int(clip.get("num_tracks", 1)), boost_audio=bool(clip.get("boost_audio", True)),
                    vertical=bool(clip.get("vertical", True)), use_tracker=bool(clip.get("use_tracker", True)),
                    mirror_video=bool(clip.get("mirror", False)), enable_female_colors=bool(clip.get("female_colors", False)),
                    sub_segments=clip.get("subs", []), sub_renderer=renderer, keep_speakers=True,
                    cancel_check=lambda: self.cancel_requested, register_proc=self._register_subproc)
                clip["subs"] = subs
                clip["speakers_count"] = max(int(clip.get("speakers_count", 1)), sp_count)
                clip["thumb_pil"] = get_cached_thumbnail(out_file, force_refresh=True)
                self._save_gallery_db()
                if (clip.get("gdrive") or {}).get("id"):
                    if self._drive_owns(clip):
                        if self._drive_upload_clip(clip, replace=True,
                                                   progress=lambda f: self.set_progress(0.9 + f * 0.1, f"Обновление копии на Google Drive ({int(f * 100)}%)")):
                            self.log("    [+] Копия на Google Drive обновлена.")
                    else:
                        self.log("[!] Копия клипа на Google Drive не обновлена: подключите тот же аккаунт Google.")
                self.set_progress(1.0, f"Видео «{clip['title']}» успешно обновлено!")
                self.log(f"[+] Перерендер завершен! Файл перезаписан: {out_file.name}")
                self.after(0, self._refresh_clips_list_ui)
                ok = True
            except Cancelled:
                self.set_progress(0.0, "Перерендер остановлен пользователем")
                self.log("[!] Перерендер остановлен. Исходный файл клипа не изменён.")
            except Exception as e:
                self.log(f"[-] Ошибка перерендера клипа: {e}")
            finally:
                self._end_job()
                if on_done:
                    self.after(0, lambda: on_done(ok))
        run_bg(_worker)

    # --- ОКНО РАСШИФРОВКИ, ЛОГ, ПРОГРЕСС ---
    def open_transcript_window(self):
        if self.transcript_popup is not None and self.transcript_popup.winfo_exists():
            self.transcript_popup.focus()
            return
        self.transcript_popup = ctk.CTkToplevel(self)
        self.transcript_popup.title("Расшифровка текста видео (Живой просмотр)")
        self.transcript_popup.geometry("680x520")
        self.transcript_popup.configure(fg_color=MD3["bg"])
        self.popup_textbox = ctk.CTkTextbox(self.transcript_popup, font=("Consolas", 12), fg_color=MD3["surface_container"],
                                            text_color=MD3["on_surface"])
        self.popup_textbox.pack(fill="both", expand=True, padx=12, pady=12)
        if self.current_transcript_text:
            self.popup_textbox.insert(tk.END, self.current_transcript_text)
            self.popup_textbox.see(tk.END)

    def _transcript_boxes(self):
        popup_alive = self.transcript_popup is not None and self.transcript_popup.winfo_exists()
        return [self.transcript_box] + ([self.popup_textbox] if popup_alive else [])

    def append_transcript_line(self, line: str):
        self.current_transcript_text += line + "\n"

        def _upd():
            for box in self._transcript_boxes():
                box.insert(tk.END, f"{line}\n")
                box.see(tk.END)
        self.after(0, _upd)

    def clear_transcript(self):
        self.current_transcript_text = ""
        self.after(0, lambda: [box.delete("1.0", tk.END) for box in self._transcript_boxes()])

    def set_progress(self, fraction: float, status_text: str):
        fraction = max(0.0, min(1.0, fraction))

        def _upd():
            self.progress_bar.set(fraction)
            self.status_label.configure(text=f"[{int(fraction * 100)}%] {status_text}")
        self.after(0, _upd)

    def log(self, msg: str):
        def _append():
            self.log_box.insert(tk.END, f"{msg}\n")
            self.log_box.see(tk.END)
        self.after(0, _append)

    def _paste_key(self):
        try:
            key = clean_api_key(self.clipboard_get())
            self.api_key_entry.delete(0, tk.END)
            self.api_key_entry.insert(0, key)
            self.log(f"[*] Ключ вставлен (длина: {len(key)} симв.).")
            self.refresh_token_balance_async(silent=False)
        except Exception as e:
            self.log(f"[!] Буфер обмена пуст: {e}")

    def _toggle_key(self):
        hidden = self.api_key_entry.cget("show") == "*"
        self.api_key_entry.configure(show="" if hidden else "*")
        self.show_key_btn.configure(text="Скрыть" if hidden else "Показать")

    def pick_file(self):
        path = filedialog.askopenfilename(title="Выберите видеофайл", filetypes=[
            ("Video files", "*.mp4 *.mkv *.mov *.avi *.webm"), ("All files", "*.*")])
        if path:
            self.source_entry.delete(0, tk.END)
            self.source_entry.insert(0, path)

    # --- НЕЙРОСЕТЬ ---
    def _get_llm_client(self):
        from openai import OpenAI  # ленивый импорт для быстрого старта окна
        key = clean_api_key(self.api_key_entry.get())
        if not key:
            raise ValueError("Поле API Ключ пустое!")
        return OpenAI(api_key=key, base_url=self.base_url_entry.get().strip().rstrip("/"), timeout=180.0,
                      default_headers={"User-Agent": f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) ClipsStudio/{APP_VERSION}"})

    def _call_llm(self, messages, temperature=0.2, max_tokens=None) -> str:
        client = self._get_llm_client()
        kwargs = {"model": self.model_combo.get().strip(), "messages": messages, "temperature": temperature}
        if max_tokens:
            kwargs["max_tokens"] = max_tokens
        with suppress(Exception):
            parts = [ch.choices[0].delta.content for ch in client.chat.completions.create(stream=True, **kwargs)
                     if ch.choices and ch.choices[0].delta and ch.choices[0].delta.content]
            result = "".join(parts).strip()
            if result:
                return result
        resp = client.chat.completions.create(stream=False, **kwargs)
        return (resp.choices[0].message.content or "").strip()

    def test_api(self):
        self.save_config()

        def _worker():
            try:
                self.log(f"[*] Проверка ключа (длина {len(self.api_key_entry.get().strip())} симв.)...")
                ans = self._call_llm([{"role": "user", "content": "Ответь одним словом: Работает!"}], max_tokens=20)
                self.log(f"[+] УСПЕШНО! Профиль '{self.model_combo.get().strip()}' ответил: {ans}")
                self.after(0, lambda: self.refresh_token_balance_async(silent=False))
            except Exception as e:
                self.log(f"[-] ОШИБКА API: {e}")
        run_bg(_worker)

    @staticmethod
    def _clean_json(raw: str):
        cleaned = re.sub(r"<think>.*?</think>", "", raw, flags=re.DOTALL).strip()
        m = re.search(r"```(?:json)?\s*([\s\S]*?)```", cleaned)
        if m:
            cleaned = m.group(1).strip()
        s, e = cleaned.find("["), cleaned.rfind("]")
        if s != -1 and e > s:
            cleaned = cleaned[s:e + 1]
        return json.loads(cleaned)

    # --- КОНВЕЙЕР ОБРАБОТКИ ---
    def _run_proc(self, cmd) -> int:
        proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NO_WINDOW_FLAG)
        self._register_subproc(proc)
        proc.wait()
        self._check_cancel()
        return proc.returncode

    @staticmethod
    def _probe_audio_streams(video_path) -> int:
        try:
            res = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=index",
                                  "-of", "csv=p=0", str(video_path)], capture_output=True, text=True, check=False,
                                 creationflags=NO_WINDOW_FLAG)
            return max(1, len([ln for ln in res.stdout.splitlines() if ln.strip()]))
        except Exception:
            return 1

    def _extract_clean_wav(self, video_path: Path, wav_path: Path, num_tracks: int):
        self.log(f"[*] Фоновое извлечение и усиление аудиодорожки (дорожек: {num_tracks})...")
        if num_tracks > 1:
            a_in = "".join(f"[0:a:{i}]" for i in range(num_tracks))
            af = ["-filter_complex", f"{a_in}amix=inputs={num_tracks}:duration=longest:dropout_transition=0,dynaudnorm=f=150:g=15"]
        else:
            af = ["-af", "dynaudnorm=f=150:g=15"]
        cmd = ["ffmpeg", "-y", "-i", str(video_path), *af, "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", str(wav_path)]
        if self._run_proc(cmd) != 0:
            raise RuntimeError("Ошибка при извлечении аудиодорожки FFmpeg.")

    def _transcribe_with_progress(self, wav_path: Path, w_size: str):
        from faster_whisper import WhisperModel  # ленивый импорт при запуске задачи
        for dev in ("cuda", "cpu"):
            try:
                self.log(f" -> Инициализация Whisper '{w_size}' ({dev.upper()})...")
                model = WhisperModel(whisper_model(w_size), device=dev, compute_type="int8", cpu_threads=max(2, (os.cpu_count() or 4) - 1))
                self._check_cancel()
                segments, info = model.transcribe(load_wav_for_whisper(wav_path), vad_filter=True, vad_parameters=dict(min_silence_duration_ms=400),
                                                  beam_size=2, word_timestamps=True)
                total = max(1.0, float(info.duration or 1.0))
                self.log(f" -> Длительность аудио: {total / 60:.1f} мин ({total:.0f} сек). Расшифровка началась...")
                lines, chunks, t0, last_pct = [], [], time.time(), -10
                for seg_no, seg in enumerate(segments):
                    self._check_cancel()
                    text = seg.text.strip()
                    if not text:
                        continue
                    line = f"[{seg.start:.1f} - {seg.end:.1f}] {text}"
                    lines.append(line)
                    self.append_transcript_line(line)
                    chunks += self._split_segment_words(seg, text, seg_no)

                    ratio = min(1.0, seg.end / total)
                    pct = int(ratio * 100)
                    eta = int((time.time() - t0) / max(0.01, ratio) * (1.0 - ratio)) if ratio > 0.03 else 0
                    self.set_progress(0.10 + ratio * 0.55, f"Распознавание речи: {pct}% ({seg.end:.0f}с из {total:.0f}с)"
                                                           f"{f' | Осталось ~{eta} сек' if eta > 0 else ''}")
                    if pct - last_pct >= 15:
                        last_pct = pct
                        self.log(f"   [Прогресс речи: {pct}%] распознано фраз: {len(lines)}")
                return lines, chunks
            except Exception as e:
                if self.cancel_requested or isinstance(e, Cancelled) or dev == "cpu":
                    raise
                self.log(f" [i] Переключение с CUDA на процессор CPU ({e})...")

    @staticmethod
    def _split_segment_words(seg, text: str, seg_no: int = 0) -> list:
        """Нарезает сегмент Whisper на короткие субтитры (до 6 слов или до знака препинания).
        Каждый кусок помечается номером фразы «phrase»: персонаж определяется для фразы целиком.
        Новая фраза начинается после паузы > 0.6 с или после конца предложения с паузой > 0.25 с."""
        if not getattr(seg, "words", None):
            return [{"start": float(seg.start), "end": float(seg.end), "text": text, "phrase": f"{seg_no}:0"}]
        chunks, buf, phrase, prev = [], [], 0, None

        def _flush(end_t):
            if buf:
                chunks.append({"start": buf[0]["start"], "end": end_t, "text": " ".join(b["word"] for b in buf),
                               "words": list(buf), "phrase": f"{seg_no}:{phrase}"})
                buf.clear()

        for w in seg.words:
            wt = w.word.strip()
            if not wt:
                continue
            if prev is not None:
                gap = float(w.start) - prev["end"]
                if gap > 0.6 or (gap > 0.25 and prev["word"].endswith((".", "!", "?", "…"))):
                    _flush(prev["end"])
                    phrase += 1
            prev = {"word": wt, "start": float(w.start), "end": float(w.end)}
            buf.append(prev)
            if len(buf) >= 6 or wt.endswith((".", "!", "?", ",")):
                _flush(prev["end"])
        _flush(float(seg.end))
        return chunks

    def start_pipeline(self):
        if self.is_running:
            return
        self.save_config()
        source = self.source_entry.get().strip()
        if not source:
            messagebox.showwarning("Внимание", "Укажите путь к видеофайлу или ссылку!")
            return
        self._active_subprocesses.clear()
        self.clear_transcript()
        self._begin_job("ИДЕТ ОБРАБОТКА...")
        self.set_progress(0.02, "Подготовка...")
        run_bg(self._run_pipeline, source)

    def _sub_settings(self) -> dict:
        if self.sub_advanced_var.get() and self.subtitles_var.get():
            wbw = bool(self.sub_wbw_var.get())
            return dict(font=self.sub_font_combo.get(), size=int(round(self.sub_size_slider.get())), wbw=wbw,
                        bg=False if wbw else bool(self.sub_bg_var.get()), mirror=bool(self.sub_mirror_var.get()),
                        female=bool(self.sub_female_var.get()))
        return dict(font="Arial", size=70, wbw=False, bg=False, mirror=False, female=False)

    def _ask_llm_for_clips(self, transcript: str, max_clips: int, min_sec: int) -> list:
        max_sec = max(60, min_sec + 30)
        prompt = (
            f"Проанализируй транскрипцию видео с таймкодами в секундах и выбери до {max_clips} самых интересных, "
            f"динамичных или смешных моментов для вертикальных Shorts/Reels длительностью не менее {min_sec} секунд "
            f"(оптимально от {min_sec} до {max_sec} секунд каждый).\n"
            f"Для каждого клипа придумай цепляющее название (title, без номеров в начале), краткое вовлекающее описание (description) "
            f"и 5-7 релевантных хэштегов через пробел (hashtags, обязательно включая #shorts).\n"
            f"Верни СТРОГО JSON-массив без лишнего текста в формате:\n"
            f'[{{"start": 12.5, "end": 45.0, "title": "Цепляющее название", "description": "Краткое описание момента", "hashtags": "#shorts #тренды #рек"}}]\n\n'
            f"Транскрипция:\n{transcript[:65000]}"
        )
        messages = [{"role": "system", "content": "Ты профессиональный монтажёр вирусных Shorts/Reels. Отвечай только валидным JSON."},
                    {"role": "user", "content": prompt}]
        for attempt in range(1, 4):
            self._check_cancel()
            try:
                return self._clean_json(self._cancellable(self._call_llm, messages=messages, temperature=0.2)) or []
            except Cancelled:
                raise
            except Exception as e:
                self.log(f"[!] Попытка {attempt}/3 не удалась ({e}). Повтор через 4 сек...")
                if attempt == 3:
                    raise
                self._sleep_cancellable(4)
        return []

    def _run_pipeline(self, source: str):
        temp_wav, out_dir, rendered, uploaded = None, None, 0, 0
        try:
            cloud = self.cloud_mode()
            folder = self.config_data.get("gdrive_folder", "Клипы")
            out_dir = (CLOUD_CACHE_DIR if cloud else self.local_root()) / f"Clips_Output_{int(time.time())}"
            try:
                out_dir.mkdir(parents=True, exist_ok=True)
            except OSError as e:
                out_dir = Path.home() / "Desktop" / out_dir.name
                self.log(f"[!] Папка хранилища недоступна ({e}) — клипы будут сохранены на Рабочий стол.")
                out_dir.mkdir(parents=True, exist_ok=True)
            self.log("\n=== ЗАПУСК ОБРАБОТКИ ===\n" + (f"Клипы сохраняются на Google Drive: /{folder}" if cloud
                                                       else f"Папка для готовых клипов: {out_dir}"))

            if source.startswith(("http://", "https://")):
                self.set_progress(0.04, "Скачивание видео по ссылке в фоне...")
                self.log("[1/4] Скачивание видео через yt-dlp (без окон)...")
                video_path = out_dir / "source_video.mp4"
                if self._run_proc(["yt-dlp", "-f", "bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best",
                                   "-o", str(video_path), source]) != 0:
                    raise RuntimeError("Не удалось скачать видео по ссылке.")
            else:
                video_path = Path(source)
                if not video_path.exists():
                    raise FileNotFoundError(f"Файл не найден: {video_path}")
                self.log(f"[1/4] Открыт локальный файл: {video_path.name}")

            self.set_progress(0.07, "Извлечение и микширование аудиодорожек...")
            num_tracks = self._probe_audio_streams(video_path)
            temp_wav = Path(os.environ.get("TEMP", str(DATA_ROOT))) / f"temp_clip_audio_{int(time.time())}.wav"
            self._extract_clean_wav(video_path, temp_wav, num_tracks)

            w_size = self.whisper_combo.get()
            self.set_progress(0.10, f"Запуск распознавания речи Whisper ({w_size})...")
            self.log("[2/4] Распознавание речи и таймкодов слов...")
            lines, sub_chunks = self._cancellable(self._transcribe_with_progress, temp_wav, w_size)
            if not lines:
                raise RuntimeError("В видео не обнаружена речь для анализа.")
            self.log(f"[+] Транскрипция завершена на 100% (фраз: {len(lines)}, субтитров: {len(sub_chunks)}).")

            max_clips = int(self.clips_count_entry.get().strip() or 5)
            min_sec = int(round(self.min_clip_slider.get()))
            model_name = self.model_combo.get().strip()
            self.set_progress(0.68, f"Нейросеть {model_name} выбирает моменты, генерирует названия, описания и хэштеги...")
            self.log(f"[3/4] Анализ текста моделью {model_name} (поиск топ-{max_clips} клипов, мин. длительность: {min_sec} сек)...")
            raw_clips = self._ask_llm_for_clips("\n".join(lines), max_clips, min_sec)
            clips_data = []
            for c in raw_clips:
                dur = float(c.get("end", 0.0)) - float(c.get("start", 0.0))
                if dur + 0.05 < min_sec:
                    self.log(f" [Пропуск] Клип «{c.get('title', 'Без названия')}» ({dur:.1f} сек) короче заданного минимума "
                             f"({min_sec} сек) — не сохраняется.")
                else:
                    clips_data.append(c)
            total = len(clips_data)
            self.log(f"[+] Подходящих по времени клипов: {total} (отсеяно слишком коротких: {len(raw_clips) - total}).")
            if total == 0:
                self.set_progress(1.0, "Нет клипов подходящей длительности")
                self.log(f"[!] Все найденные моделью клипы оказались короче {min_sec} сек. "
                         f"Попробуйте уменьшить порог в разделе 'Время клипа'.")
                return

            vertical, boost, use_tracker = self.crop_var.get(), self.boost_audio_var.get(), self.face_track_var.get()
            enable_subs = self.subtitles_var.get()
            s = self._sub_settings()
            mode = "word" if s["wbw"] else ("bg" if s["bg"] else "text")
            self.log("[4/4] Рендер видеоклипов (статичные планы + Cut после остановки персонажа)...")

            for idx, clip in enumerate(clips_data, 1):
                self._check_cancel()
                start_t, end_t = float(clip["start"]), float(clip["end"])
                base = safe_filename(strip_num_prefix(clip.get("title", f"Клип {idx}").strip()))[:55] or f"Клип_{int(time.time())}"
                out_file, dup = out_dir / f"{base}.mp4", 2
                while out_file.exists():
                    out_file, dup = out_dir / f"{base} ({dup}).mp4", dup + 1
                title = out_file.stem
                desc = str(clip.get("description", "")).strip()
                tags = str(clip.get("hashtags", "#shorts #viral #рекомендации")).strip()
                tags = tags if "#shorts" in tags.lower() else f"#Shorts {tags}".strip()

                self.set_progress(0.72 + idx / total * 0.28, f"Рендер клипа {idx} из {total}: {title}...")
                self.log(f" -> [{idx}/{total}] Рендер: {title} ({start_t:.1f}с - {end_t:.1f}с, длина: {end_t - start_t:.1f}с)...")
                renderer = SubtitleRenderer(s["font"], s["size"], s["bg"], s["wbw"], s["female"]) if enable_subs else None
                subs, sp_count, genders = self.speaker_tracker.render_clip(
                    video_path=video_path, start_t=start_t, duration=end_t - start_t, out_file=out_file,
                    num_tracks=num_tracks, boost_audio=boost, vertical=vertical, use_tracker=use_tracker,
                    mirror_video=s["mirror"], enable_female_colors=s["female"],
                    sub_segments=[dict(x) for x in sub_chunks if x["end"] >= start_t and x["start"] <= end_t],
                    sub_renderer=renderer, voice_wav=temp_wav,
                    cancel_check=lambda: self.cancel_requested, register_proc=self._register_subproc)
                rendered += 1
                self.created_clips.insert(0, {
                    "title": title, "yt_title": with_shorts(title), "yt_description": f"{desc}\n\n{tags}".strip() if desc else tags,
                    "file_path": str(out_file), "source_video": str(video_path), "start": start_t, "end": end_t,
                    "subs": subs, "speakers_count": sp_count,
                    "speaker_styles": assign_speaker_colors(sp_count, genders, mode, enable_female_colors=s["female"]),
                    "font_name": s["font"], "font_size": s["size"], "default_bg": s["bg"], "word_by_word": s["wbw"],
                    "mirror": s["mirror"], "female_colors": s["female"], "num_tracks": num_tracks, "boost_audio": boost,
                    "vertical": vertical, "use_tracker": use_tracker,
                    "thumb_pil": get_cached_thumbnail(out_file, force_refresh=True),
                })
                self._save_gallery_db()
                self.after(0, self._show_clips_section_after_job)
                if cloud:
                    status = f"Загрузка на Google Drive {idx} из {total}: {title}"
                    if self._drive_upload_clip(self.created_clips[0], cancelled=lambda: self.cancel_requested,
                                               progress=lambda f, st=status, i=idx: self.set_progress(
                                                   0.72 + (i - 1 + f) / total * 0.28, f"{st} ({int(f * 100)}%)")):
                        uploaded += 1
                        self.log(f"    [+] Сохранено на Google Drive: /{folder}/{out_file.name}")

            self.set_progress(1.0, f"Готово! Сделано клипов: {total}")
            where = (f"на Google Drive в папку /{folder} ({uploaded} из {total} шт.), рабочие копии на ПК:" if cloud
                     else "в папку:")
            self.log(f"\n[100% ГОТОВО!] Все подходящие клипы сохранены {where}\n{out_dir}")
        except Cancelled:
            self.set_progress(0.0, "Остановлено пользователем")
            kept = f" Уже готовые клипы ({rendered} шт.) сохранены." if rendered else ""
            self.log(f"[!] Процесс остановлен пользователем. Прогресс текущей обработки утерян.{kept}")
            if out_dir and rendered == 0:
                shutil.rmtree(out_dir, ignore_errors=True)
        except Exception as e:
            self.set_progress(0.0, "Ошибка при выполнении")
            self.log(f"\n[КРИТИЧЕСКАЯ ОШИБКА]: {e}")
        finally:
            self._active_subprocesses.clear()
            if temp_wav:
                with suppress(Exception):
                    temp_wav.unlink(missing_ok=True)
            was_cancelled = self.cancel_requested
            self._end_job()
            if not was_cancelled:
                self.after(0, lambda: self.refresh_token_balance_async(silent=False, allow_browser=True))


def main():
    migrate_legacy_data()
    ClipsStudioSK().mainloop()


if __name__ == "__main__":
    main()
